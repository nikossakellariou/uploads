"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthType = exports.API_AUTH_LOGOUT = exports.API_AUTH_LOGIN = exports.SELECT_TENANT_PAGE_URI = exports.LOGIN_PAGE_URI = exports.API_ENDPOINT_AUTHINFO = exports.CONFIGURATION_API_PREFIX = exports.API_PREFIX = exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
exports.PLUGIN_ID = 'opendistroSecurity';
exports.PLUGIN_NAME = 'opendistro_security';
exports.API_PREFIX = '/api/v1';
exports.CONFIGURATION_API_PREFIX = 'configuration';
exports.API_ENDPOINT_AUTHINFO = exports.API_PREFIX + '/auth/authinfo';
exports.LOGIN_PAGE_URI = '/app/login';
exports.SELECT_TENANT_PAGE_URI = '/app/select_tenant';
exports.API_AUTH_LOGIN = '/auth/login';
exports.API_AUTH_LOGOUT = '/auth/logout';
var AuthType;
(function (AuthType) {
    AuthType["BASIC"] = "basicauth";
    AuthType["OPEN_ID"] = "openid";
    AuthType["JWT"] = "jwt";
    AuthType["SAML"] = "saml";
    AuthType["PROXY"] = "proxy";
})(AuthType = exports.AuthType || (exports.AuthType = {}));
