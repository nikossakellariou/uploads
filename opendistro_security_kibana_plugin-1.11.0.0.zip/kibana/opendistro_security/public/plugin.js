"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OpendistroSecurityPlugin = void 0;
const rxjs_1 = require("rxjs");
const public_1 = require("../../../src/core/public");
const common_1 = require("../common");
const constants_1 = require("./apps/configuration/constants");
const account_app_1 = require("./apps/account/account-app");
const utils_1 = require("./apps/account/utils");
const constants_2 = require("./apps/configuration/panels/audit-logging/constants");
async function hasApiPermission(core) {
    try {
        const permissions = await core.http.get(constants_1.API_ENDPOINT_PERMISSIONS_INFO);
        return permissions.has_api_access || false;
    }
    catch (e) {
        console.error(e);
        // ignore exceptions and default to no security related access.
        return false;
    }
}
const DEFAULT_READONLY_ROLES = ['kibana_read_only'];
class OpendistroSecurityPlugin {
    // @ts-ignore : initializerContext not used
    constructor(initializerContext) {
        this.initializerContext = initializerContext;
    }
    async setup(core) {
        const apiPermission = await hasApiPermission(core);
        const config = this.initializerContext.config.get();
        const accountInfo = (await utils_1.fetchAccountInfoSafe(core.http))?.data;
        const isReadonly = accountInfo?.roles.some((role) => (config.readonly_mode?.roles || DEFAULT_READONLY_ROLES).includes(role));
        if (apiPermission) {
            core.application.register({
                id: common_1.PLUGIN_NAME,
                title: 'Security',
                order: 9050,
                mount: async (params) => {
                    const { renderApp } = await Promise.resolve().then(() => __importStar(require('./apps/configuration/configuration-app')));
                    const [coreStart, depsStart] = await core.getStartServices();
                    // merge Kibana yml configuration
                    constants_1.includeClusterPermissions(config.clusterPermissions.include);
                    constants_1.includeIndexPermissions(config.indexPermissions.include);
                    constants_2.excludeFromDisabledTransportCategories(config.disabledTransportCategories.exclude);
                    constants_2.excludeFromDisabledRestCategories(config.disabledRestCategories.exclude);
                    return renderApp(coreStart, depsStart, params, config);
                },
                category: public_1.DEFAULT_APP_CATEGORIES.management,
            });
        }
        core.application.register({
            id: 'login',
            title: 'Security',
            chromeless: true,
            appRoute: common_1.LOGIN_PAGE_URI,
            mount: async (params) => {
                const { renderApp } = await Promise.resolve().then(() => __importStar(require('./apps/login/login-app')));
                // @ts-ignore depsStart not used.
                const [coreStart, depsStart] = await core.getStartServices();
                return renderApp(coreStart, params, config.ui.basicauth.login);
            },
        });
        core.application.register({
            id: 'multitenancy',
            title: 'Security',
            chromeless: true,
            appRoute: common_1.SELECT_TENANT_PAGE_URI,
            mount: async (params) => {
                const { renderPage } = await Promise.resolve().then(() => __importStar(require('./apps/account/tenant-selection-page')));
                const [coreStart] = await core.getStartServices();
                return renderPage(coreStart, params, config, apiPermission);
            },
        });
        core.application.registerAppUpdater(new rxjs_1.BehaviorSubject((app) => {
            if (!apiPermission && isReadonly && app.id !== 'dashboards' && app.id !== 'home') {
                return {
                    status: public_1.AppStatus.inaccessible,
                };
            }
        }));
        // Return methods that should be available to other plugins
        return {};
    }
    start(core) {
        const config = this.initializerContext.config.get();
        account_app_1.setupTopNavButton(core, config);
        return {};
    }
    stop() { }
}
exports.OpendistroSecurityPlugin = OpendistroSecurityPlugin;
