"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateNewPassword = exports.validateCurrentPassword = exports.logout = exports.fetchAccountInfoSafe = exports.fetchAccountInfo = void 0;
const common_1 = require("../../../common");
const constants_1 = require("./constants");
const request_utils_1 = require("../configuration/utils/request-utils");
function fetchAccountInfo(http) {
    return http.get(constants_1.API_ENDPOINT_ACCOUNT_INFO);
}
exports.fetchAccountInfo = fetchAccountInfo;
async function fetchAccountInfoSafe(http) {
    return request_utils_1.getWithIgnores(http, constants_1.API_ENDPOINT_ACCOUNT_INFO, [401]);
}
exports.fetchAccountInfoSafe = fetchAccountInfoSafe;
async function logout(http, logoutUrl) {
    await http.post(common_1.API_AUTH_LOGOUT);
    window.location.href = logoutUrl || http.basePath.serverBasePath;
}
exports.logout = logout;
async function validateCurrentPassword(http, userName, currentPassword) {
    await http.post('/auth/login', {
        body: JSON.stringify({
            username: userName,
            password: currentPassword,
        }),
    });
}
exports.validateCurrentPassword = validateCurrentPassword;
async function updateNewPassword(http, newPassword, currentPassword) {
    await http.post(`${constants_1.API_ENDPOINT_ACCOUNT_INFO}`, {
        body: JSON.stringify({
            password: newPassword,
            current_password: currentPassword,
        }),
    });
}
exports.updateNewPassword = updateNewPassword;
