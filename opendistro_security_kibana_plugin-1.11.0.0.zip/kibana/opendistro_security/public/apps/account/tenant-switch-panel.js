"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantSwitchPanel = exports.CUSTOM_TENANT_RADIO_ID = exports.PRIVATE_TENANT_RADIO_ID = exports.GLOBAL_TENANT_RADIO_ID = void 0;
const tslib_1 = require("tslib");
const eui_1 = require("@elastic/eui");
const lodash_1 = require("lodash");
const react_1 = tslib_1.__importDefault(require("react"));
const tenant_utils_1 = require("../configuration/utils/tenant-utils");
const utils_1 = require("./utils");
const error_utils_1 = require("../error-utils");
const GLOBAL_TENANT_KEY_NAME = 'global_tenant';
exports.GLOBAL_TENANT_RADIO_ID = 'global';
exports.PRIVATE_TENANT_RADIO_ID = 'private';
exports.CUSTOM_TENANT_RADIO_ID = 'custom';
function TenantSwitchPanel(props) {
    const [tenants, setTenants] = react_1.default.useState([]);
    const [username, setUsername] = react_1.default.useState('');
    const [errorCallOut, setErrorCallOut] = react_1.default.useState('');
    const setCurrentTenant = (currentRawTenantName, currentUserName) => {
        const resolvedTenantName = tenant_utils_1.resolveTenantName(currentRawTenantName, currentUserName);
        if (resolvedTenantName === tenant_utils_1.RESOLVED_GLOBAL_TENANT) {
            setTenantSwitchRadioIdSelected(exports.GLOBAL_TENANT_RADIO_ID);
        }
        else if (resolvedTenantName === tenant_utils_1.RESOLVED_PRIVATE_TENANT) {
            setTenantSwitchRadioIdSelected(exports.PRIVATE_TENANT_RADIO_ID);
        }
        else {
            setTenantSwitchRadioIdSelected(exports.CUSTOM_TENANT_RADIO_ID);
            setSelectedCustomTenantOption(resolvedTenantName);
        }
    };
    react_1.default.useEffect(() => {
        const fetchData = async () => {
            try {
                const accountInfo = await utils_1.fetchAccountInfo(props.coreStart.http);
                const tenantsInfo = accountInfo.data.tenants || {};
                setTenants(lodash_1.keys(tenantsInfo));
                const currentUserName = accountInfo.data.user_name;
                setUsername(currentUserName);
                // @ts-ignore
                const currentRawTenantName = accountInfo.data.user_requested_tenant;
                setCurrentTenant(currentRawTenantName || '', currentUserName);
            }
            catch (e) {
                // TODO: switch to better error display.
                console.error(e);
            }
        };
        fetchData();
    }, [props.coreStart.http]);
    // Custom tenant super select related.
    const [selectedCustomTenantOption, setSelectedCustomTenantOption] = react_1.default.useState('');
    const onCustomTenantChange = (selectedOption) => {
        setSelectedCustomTenantOption(selectedOption);
        setTenantSwitchRadioIdSelected(exports.CUSTOM_TENANT_RADIO_ID);
        setErrorCallOut('');
    };
    const customTenantOptions = tenants.filter((tenant) => {
        return tenant !== GLOBAL_TENANT_KEY_NAME && tenant !== username;
    });
    const isMultiTenancyEnabled = props.config.multitenancy.enabled;
    const isGlobalEnabled = props.config.multitenancy.tenants.enable_global;
    const isPrivateEnabled = props.config.multitenancy.tenants.enable_private;
    const shouldDisableGlobal = !isGlobalEnabled || !tenants.includes(GLOBAL_TENANT_KEY_NAME);
    const getGlobalDisabledInstruction = () => {
        if (!isGlobalEnabled) {
            return 'Contact the administrator to enable global tenant.';
        }
        if (!tenants.includes(GLOBAL_TENANT_KEY_NAME)) {
            return 'Contact the administrator to get access to global tenant.';
        }
    };
    // The key for private tenant is the user name.
    const shouldDisablePrivate = !isPrivateEnabled || !tenants.includes(username);
    const getPrivateDisabledInstruction = () => {
        if (!isPrivateEnabled) {
            return 'Contact the administrator to enable private tenant.';
        }
        if (!tenants.includes(username)) {
            return 'Contact the administrator to get access to private tenant.';
        }
    };
    // Tenant switch radios related.
    const tenantSwitchRadios = [
        {
            id: exports.GLOBAL_TENANT_RADIO_ID,
            label: (react_1.default.createElement(react_1.default.Fragment, null,
                "Global",
                react_1.default.createElement(eui_1.EuiText, { size: "s" }, "The global tenant is shared between every Kibana user."),
                shouldDisableGlobal && react_1.default.createElement("i", null, getGlobalDisabledInstruction()),
                react_1.default.createElement(eui_1.EuiSpacer, null))),
            disabled: shouldDisableGlobal,
        },
        {
            id: exports.PRIVATE_TENANT_RADIO_ID,
            label: (react_1.default.createElement(react_1.default.Fragment, null,
                "Private",
                react_1.default.createElement(eui_1.EuiText, { size: "s" }, "The private tenant is exclusive to each user and can't be shared. You might use the private tenant for exploratory work."),
                shouldDisablePrivate && react_1.default.createElement("i", null, getPrivateDisabledInstruction()),
                react_1.default.createElement(eui_1.EuiSpacer, null))),
            disabled: shouldDisablePrivate,
        },
        {
            id: exports.CUSTOM_TENANT_RADIO_ID,
            label: (react_1.default.createElement(react_1.default.Fragment, null,
                "Choose from custom",
                react_1.default.createElement(eui_1.EuiSuperSelect, { options: customTenantOptions.map((option) => ({
                        value: option,
                        inputDisplay: option,
                    })), valueOfSelected: selectedCustomTenantOption, onChange: onCustomTenantChange, style: { width: 400 } }))),
            disabled: customTenantOptions.length === 0,
        },
    ];
    const [tenantSwitchRadioIdSelected, setTenantSwitchRadioIdSelected] = react_1.default.useState();
    const onTenantSwitchRadioChange = (radioId) => {
        setTenantSwitchRadioIdSelected(radioId);
        setErrorCallOut('');
    };
    const changeTenant = async (tenantName) => {
        await tenant_utils_1.selectTenant(props.coreStart.http, {
            tenant: tenantName,
            username,
        });
    };
    const handleTenantConfirmation = async function () {
        let tenantName;
        if (tenantSwitchRadioIdSelected === exports.GLOBAL_TENANT_RADIO_ID) {
            tenantName = '';
        }
        else if (tenantSwitchRadioIdSelected === exports.PRIVATE_TENANT_RADIO_ID) {
            tenantName = '__user__';
        }
        else if (tenantSwitchRadioIdSelected === exports.CUSTOM_TENANT_RADIO_ID) {
            if (selectedCustomTenantOption) {
                tenantName = selectedCustomTenantOption;
            }
        }
        // check tenant name before calling backend
        if (tenantName === undefined) {
            setErrorCallOut('No target tenant is specified!');
        }
        else {
            try {
                await changeTenant(tenantName);
                props.handleSwitchAndClose();
            }
            catch (e) {
                setErrorCallOut(error_utils_1.constructErrorMessageAndLog(e, 'Failed to switch tenant.'));
            }
        }
    };
    let content;
    if (isMultiTenancyEnabled) {
        content = (react_1.default.createElement(react_1.default.Fragment, null,
            react_1.default.createElement(eui_1.EuiRadioGroup, { "data-test-subj": "tenant-switch-radios", options: tenantSwitchRadios, idSelected: tenantSwitchRadioIdSelected, onChange: (radioId) => onTenantSwitchRadioChange(radioId), name: "tenantSwitchRadios" }),
            react_1.default.createElement(eui_1.EuiSpacer, null),
            errorCallOut && (react_1.default.createElement(eui_1.EuiCallOut, { color: "danger", iconType: "alert" }, errorCallOut))));
    }
    else {
        content = react_1.default.createElement(react_1.default.Fragment, null, "Contact the administrator to enable multi tenancy.");
    }
    return (react_1.default.createElement(eui_1.EuiOverlayMask, null,
        react_1.default.createElement(eui_1.EuiModal, { "data-test-subj": "tenant-switch-modal", onClose: props.handleClose },
            react_1.default.createElement(eui_1.EuiSpacer, null),
            react_1.default.createElement(eui_1.EuiModalBody, null,
                react_1.default.createElement(eui_1.EuiTitle, null,
                    react_1.default.createElement("h4", null, "Select your tenant")),
                react_1.default.createElement(eui_1.EuiSpacer, null),
                react_1.default.createElement(eui_1.EuiText, { size: "s", color: "subdued" }, "Tenants are useful for safely sharing your work with other Kibana users. You can switch your tenant anytime by clicking the user avatar on top right."),
                react_1.default.createElement(eui_1.EuiSpacer, null),
                content),
            react_1.default.createElement(eui_1.EuiModalFooter, null,
                react_1.default.createElement(eui_1.EuiButtonEmpty, { onClick: props.handleClose }, "Cancel"),
                react_1.default.createElement(eui_1.EuiButton, { "data-test-subj": "confirm", fill: true, disabled: !isMultiTenancyEnabled, onClick: handleTenantConfirmation }, "Confirm")))));
}
exports.TenantSwitchPanel = TenantSwitchPanel;
