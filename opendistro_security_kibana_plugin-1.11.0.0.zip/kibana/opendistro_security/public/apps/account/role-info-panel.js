"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RoleInfoPanel = void 0;
const tslib_1 = require("tslib");
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
const eui_1 = require("@elastic/eui");
const react_1 = tslib_1.__importStar(require("react"));
const utils_1 = require("./utils");
function RoleInfoPanel(props) {
    const [roles, setRoles] = react_1.default.useState([]);
    const [backendRoles, setBackendRoles] = react_1.default.useState([]);
    const fetchData = react_1.useCallback(async () => {
        try {
            const accountInfo = await utils_1.fetchAccountInfo(props.coreStart.http);
            setRoles(accountInfo?.data.roles || []);
            setBackendRoles(accountInfo?.data.backend_roles || []);
        }
        catch (e) {
            console.log(e);
        }
    }, [props.coreStart.http]);
    react_1.default.useEffect(() => {
        fetchData();
    }, [props.coreStart.http, fetchData]);
    return (react_1.default.createElement(eui_1.EuiOverlayMask, null,
        react_1.default.createElement(eui_1.EuiModal, { "data-test-subj": "role-info-modal", onClose: props.handleClose },
            react_1.default.createElement(eui_1.EuiSpacer, null),
            react_1.default.createElement(eui_1.EuiModalBody, null,
                react_1.default.createElement(eui_1.EuiTitle, null,
                    react_1.default.createElement("h4", null,
                        "Roles (",
                        roles.length,
                        ")")),
                react_1.default.createElement(eui_1.EuiText, { color: "subdued" }, "Roles you are currently mapped to by your administrator."),
                react_1.default.createElement(eui_1.EuiSpacer, null),
                roles.map((item) => (react_1.default.createElement(eui_1.EuiText, { key: item },
                    item,
                    react_1.default.createElement("br", null)))),
                react_1.default.createElement(eui_1.EuiHorizontalRule, null),
                react_1.default.createElement(eui_1.EuiTitle, null,
                    react_1.default.createElement("h4", null,
                        "External identities (",
                        backendRoles.length,
                        ")")),
                react_1.default.createElement(eui_1.EuiText, { color: "subdued" }, "External identities you are currently mapped to by your administrator."),
                react_1.default.createElement(eui_1.EuiSpacer, null),
                backendRoles.map((item) => (react_1.default.createElement(eui_1.EuiText, { key: item },
                    item,
                    react_1.default.createElement("br", null))))))));
}
exports.RoleInfoPanel = RoleInfoPanel;
