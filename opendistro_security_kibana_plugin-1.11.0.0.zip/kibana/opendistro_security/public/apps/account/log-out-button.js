"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogoutButton = void 0;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importDefault(require("react"));
const eui_1 = require("@elastic/eui");
const utils_1 = require("./utils");
function LogoutButton(props) {
    if (props.authType === 'openid' || props.authType === 'saml') {
        return (react_1.default.createElement("div", null,
            props.divider,
            react_1.default.createElement(eui_1.EuiButtonEmpty, { "data-test-subj": "log-out-1", color: "danger", size: "xs", href: `${props.http.basePath.serverBasePath}/auth/logout` }, "Log out")));
    }
    else if (props.authType === 'proxy') {
        return react_1.default.createElement("div", null);
    }
    else {
        return (react_1.default.createElement("div", null,
            props.divider,
            react_1.default.createElement(eui_1.EuiButtonEmpty, { "data-test-subj": "log-out-2", color: "danger", size: "xs", onClick: () => utils_1.logout(props.http, props.logoutUrl) }, "Log out")));
    }
}
exports.LogoutButton = LogoutButton;
