"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PasswordResetPanel = void 0;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importDefault(require("react"));
const eui_1 = require("@elastic/eui");
const form_row_1 = require("../configuration/utils/form-row");
const utils_1 = require("./utils");
const apps_constants_1 = require("../apps-constants");
const error_utils_1 = require("../error-utils");
function PasswordResetPanel(props) {
    const [currentPassword, setCurrentPassword] = react_1.default.useState('');
    // reply on backend response of login call to verify
    const [isCurrentPasswordInvalid, setIsCurrentPasswordInvalid] = react_1.default.useState(false);
    const [currentPasswordError, setCurrentPasswordError] = react_1.default.useState([]);
    const [newPassword, setNewPassword] = react_1.default.useState('');
    // reply on backend response of user update call to verify
    const [isNewPasswordInvalid, setIsNewPasswordInvalid] = react_1.default.useState(false);
    const [repeatNewPassword, setRepeatNewPassword] = react_1.default.useState('');
    const [isRepeatNewPasswordInvalid, setIsRepeatNewPasswordInvalid] = react_1.default.useState(false);
    const [errorCallOut, setErrorCallOut] = react_1.default.useState('');
    const handleReset = async () => {
        const http = props.coreStart.http;
        // validate the current password
        try {
            await utils_1.validateCurrentPassword(http, props.username, currentPassword);
        }
        catch (e) {
            setIsCurrentPasswordInvalid(true);
            setCurrentPasswordError([error_utils_1.constructErrorMessageAndLog(e, 'Invalid current password.')]);
        }
        // update new password
        try {
            await utils_1.updateNewPassword(http, newPassword, currentPassword);
            await utils_1.logout(http, props.logoutUrl);
        }
        catch (e) {
            setErrorCallOut(error_utils_1.constructErrorMessageAndLog(e, 'Failed to reset password.'));
        }
    };
    // TODO: replace the instruction message for new password once UX provides it.
    return (react_1.default.createElement(eui_1.EuiOverlayMask, null,
        react_1.default.createElement(eui_1.EuiModal, { "data-test-subj": "reset-password-modal", onClose: props.handleClose },
            react_1.default.createElement(eui_1.EuiSpacer, null),
            react_1.default.createElement(eui_1.EuiModalBody, null,
                react_1.default.createElement(eui_1.EuiTitle, null,
                    react_1.default.createElement("h4", null,
                        "Reset password for \"",
                        props.username,
                        "\"")),
                react_1.default.createElement(eui_1.EuiSpacer, null),
                react_1.default.createElement(form_row_1.FormRow, { headerText: "Current password", helpText: "Verify your account by entering your current password.", isInvalid: isCurrentPasswordInvalid, error: currentPasswordError },
                    react_1.default.createElement(eui_1.EuiFieldPassword, { "data-test-subj": "current-password", onChange: function (e) {
                            setCurrentPassword(e.target.value);
                            setIsCurrentPasswordInvalid(false);
                        }, isInvalid: isCurrentPasswordInvalid })),
                react_1.default.createElement(form_row_1.FormRow, { headerText: "New password", helpText: apps_constants_1.PASSWORD_INSTRUCTION, isInvalid: isNewPasswordInvalid },
                    react_1.default.createElement(eui_1.EuiFieldPassword, { "data-test-subj": "new-password", onChange: function (e) {
                            setNewPassword(e.target.value);
                            setIsNewPasswordInvalid(false);
                            setIsRepeatNewPasswordInvalid(repeatNewPassword !== newPassword);
                        }, isInvalid: isNewPasswordInvalid })),
                react_1.default.createElement(form_row_1.FormRow, { headerText: "Re-enter new password", helpText: "The password must be identical to what you entered above." },
                    react_1.default.createElement(eui_1.EuiFieldPassword, { "data-test-subj": "reenter-new-password", isInvalid: isRepeatNewPasswordInvalid, onChange: function (e) {
                            const value = e.target.value;
                            setRepeatNewPassword(value);
                            setIsRepeatNewPasswordInvalid(value !== newPassword);
                        } })),
                react_1.default.createElement(eui_1.EuiSpacer, null),
                errorCallOut && (react_1.default.createElement(eui_1.EuiCallOut, { color: "danger", iconType: "alert" }, errorCallOut))),
            react_1.default.createElement(eui_1.EuiModalFooter, null,
                react_1.default.createElement(eui_1.EuiButtonEmpty, { "data-test-subj": "cancel", onClick: props.handleClose }, "Cancel"),
                react_1.default.createElement(eui_1.EuiButton, { "data-test-subj": "reset", fill: true, disabled: isRepeatNewPasswordInvalid, onClick: handleReset }, "Reset")))));
}
exports.PasswordResetPanel = PasswordResetPanel;
