"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderPage = void 0;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importDefault(require("react"));
const react_dom_1 = tslib_1.__importDefault(require("react-dom"));
const tenant_switch_panel_1 = require("./tenant-switch-panel");
function redirect(serverBasePath) {
    // navigate to nextUrl
    const urlParams = new URLSearchParams(window.location.search);
    let nextUrl = urlParams.get('nextUrl');
    if (!nextUrl || nextUrl.toLowerCase().includes('//')) {
        nextUrl = serverBasePath;
    }
    window.location.href = nextUrl;
}
async function renderPage(coreStart, params, config, hasApiPermission) {
    const serverBasePath = coreStart.http.basePath.serverBasePath;
    const handleModalClose = () => redirect(serverBasePath);
    // Skip either:
    // 1. multitenancy is disabled
    // 2. security manager (user with api permission)
    if (!config.multitenancy.enabled || hasApiPermission) {
        handleModalClose();
        return () => { };
    }
    else {
        react_dom_1.default.render(react_1.default.createElement(tenant_switch_panel_1.TenantSwitchPanel, { coreStart: coreStart, config: config, handleClose: handleModalClose, handleSwitchAndClose: handleModalClose }), params.element);
        return () => react_dom_1.default.unmountComponentAtNode(params.element);
    }
}
exports.renderPage = renderPage;
