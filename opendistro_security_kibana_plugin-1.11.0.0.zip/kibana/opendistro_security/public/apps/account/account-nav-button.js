"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AccountNavButton = void 0;
const tslib_1 = require("tslib");
const eui_1 = require("@elastic/eui");
const react_1 = tslib_1.__importStar(require("react"));
const role_info_panel_1 = require("./role-info-panel");
const password_reset_panel_1 = require("./password-reset-panel");
const tenant_switch_panel_1 = require("./tenant-switch-panel");
const log_out_button_1 = require("./log-out-button");
const tenant_utils_1 = require("../configuration/utils/tenant-utils");
function AccountNavButton(props) {
    const [isPopoverOpen, setPopoverOpen] = react_1.useState(false);
    const [modal, setModal] = react_1.useState(null);
    const horizontalRule = react_1.default.createElement(eui_1.EuiHorizontalRule, { margin: "xs" });
    const username = props.username;
    const contextMenuPanel = (react_1.default.createElement("div", { style: { maxWidth: '256px' } },
        react_1.default.createElement(eui_1.EuiFlexGroup, { gutterSize: "s" },
            react_1.default.createElement(eui_1.EuiFlexItem, { grow: null },
                react_1.default.createElement(eui_1.EuiAvatar, { name: username })),
            react_1.default.createElement(eui_1.EuiFlexItem, null,
                react_1.default.createElement(eui_1.EuiListGroup, { gutterSize: "none" },
                    react_1.default.createElement(eui_1.EuiListGroupItem, { key: "username", wrapText: true, label: react_1.default.createElement(eui_1.EuiText, { size: "s" },
                            react_1.default.createElement("h5", null, username)) })),
                react_1.default.createElement(eui_1.EuiListGroupItem, { color: "subdued", key: "tenant", label: react_1.default.createElement(eui_1.EuiText, { size: "xs" }, tenant_utils_1.resolveTenantName(props.tenant || '', username)) }))),
        horizontalRule,
        react_1.default.createElement(eui_1.EuiButtonEmpty, { size: "xs", onClick: () => setModal(react_1.default.createElement(role_info_panel_1.RoleInfoPanel, Object.assign({}, props, { handleClose: () => setModal(null) }))) }, "View roles and identities"),
        horizontalRule,
        react_1.default.createElement(eui_1.EuiButtonEmpty, { size: "xs", onClick: () => setModal(react_1.default.createElement(tenant_switch_panel_1.TenantSwitchPanel, { coreStart: props.coreStart, config: props.config, handleClose: () => setModal(null), handleSwitchAndClose: () => {
                    setModal(null);
                    window.location.reload();
                } })) }, "Switch tenants"),
        props.isInternalUser && (react_1.default.createElement(react_1.default.Fragment, null,
            horizontalRule,
            react_1.default.createElement(eui_1.EuiButtonEmpty, { size: "xs", onClick: () => setModal(react_1.default.createElement(password_reset_panel_1.PasswordResetPanel, { coreStart: props.coreStart, username: props.username, handleClose: () => setModal(null), logoutUrl: props.config.auth.logout_url })) }, "Reset password"))),
        react_1.default.createElement(log_out_button_1.LogoutButton, { authType: props.config.auth.type, http: props.coreStart.http, divider: horizontalRule, logoutUrl: props.config.auth.logout_url })));
    return (react_1.default.createElement(eui_1.EuiHeaderSectionItemButton, { onClick: () => {
            setPopoverOpen((prevState) => !prevState);
        } },
        react_1.default.createElement(eui_1.EuiPopover, { id: "actionsMenu", button: react_1.default.createElement(eui_1.EuiAvatar, { name: username }), isOpen: isPopoverOpen, closePopover: () => {
                setPopoverOpen(false);
            }, panelPaddingSize: "s" },
            react_1.default.createElement(eui_1.EuiContextMenuPanel, null, contextMenuPanel)),
        modal));
}
exports.AccountNavButton = AccountNavButton;
