"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantPermissionType = exports.PageId = exports.SubAction = exports.Action = exports.ResourceType = void 0;
var ResourceType;
(function (ResourceType) {
    ResourceType["roles"] = "roles";
    ResourceType["users"] = "users";
    ResourceType["permissions"] = "permissions";
    ResourceType["tenants"] = "tenants";
    ResourceType["auth"] = "auth";
    ResourceType["auditLogging"] = "auditLogging";
})(ResourceType = exports.ResourceType || (exports.ResourceType = {}));
var Action;
(function (Action) {
    Action["view"] = "view";
    Action["create"] = "create";
    Action["edit"] = "edit";
    Action["duplicate"] = "duplicate";
})(Action = exports.Action || (exports.Action = {}));
var SubAction;
(function (SubAction) {
    SubAction["mapuser"] = "mapuser";
})(SubAction = exports.SubAction || (exports.SubAction = {}));
var PageId;
(function (PageId) {
    PageId["dashboardId"] = "dashboards";
    PageId["visualizationId"] = "visualize";
})(PageId = exports.PageId || (exports.PageId = {}));
var TenantPermissionType;
(function (TenantPermissionType) {
    TenantPermissionType["None"] = "";
    TenantPermissionType["Read"] = "Read only";
    TenantPermissionType["Write"] = "Write only";
    TenantPermissionType["Full"] = "Read and Write";
})(TenantPermissionType = exports.TenantPermissionType || (exports.TenantPermissionType = {}));
