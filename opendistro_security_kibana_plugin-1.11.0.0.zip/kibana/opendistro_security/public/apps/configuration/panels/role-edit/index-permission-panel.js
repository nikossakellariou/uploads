"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.IndexPermissionPanel = exports.generateIndexPermissionPanels = exports.AnonymizationRow = exports.FieldLevelSecurityRow = exports.DocLevelSecurityRow = exports.IndexPermissionRow = exports.IndexPatternRow = exports.unbuildIndexPermissionState = exports.buildIndexPermissionState = exports.getEmptyIndexPermission = void 0;
const tslib_1 = require("tslib");
require("./_index.scss");
const eui_1 = require("@elastic/eui");
const react_1 = tslib_1.__importStar(require("react"));
const lodash_1 = require("lodash");
const types_1 = require("../../types");
const array_state_utils_1 = require("../../utils/array-state-utils");
const combo_box_utils_1 = require("../../utils/combo-box-utils");
const form_row_1 = require("../../utils/form-row");
const panel_with_header_1 = require("../../utils/panel-with-header");
const index_permission_utils_1 = require("../../utils/index-permission-utils");
const constant_1 = require("./constant");
const url_builder_1 = require("../../utils/url-builder");
const display_utils_1 = require("../../utils/display-utils");
const constants_1 = require("../../constants");
function getEmptyIndexPermission() {
    return {
        indexPatterns: [],
        allowedActions: [],
        docLevelSecurity: '',
        fieldLevelSecurityMethod: 'exclude',
        fieldLevelSecurityFields: [],
        maskedFields: [],
    };
}
exports.getEmptyIndexPermission = getEmptyIndexPermission;
/**
 * Remove the leading ~ which indicates exclude and convert to combo box option.
 * @param fieldLevelSecurityRawFields fields fetched from backend
 * ["~field1", "~field2"] => ["field1", "field2"]
 * ["field1", "field2"] => ["field1", "field2"]
 */
function getFieldLevelSecurityFields(fieldLevelSecurityRawFields) {
    return fieldLevelSecurityRawFields
        .map((s) => s.replace(/^~/, ''))
        .map(combo_box_utils_1.stringToComboBoxOption);
}
function packFieldLevelSecurity(method, fieldOptions) {
    const fields = fieldOptions.map(combo_box_utils_1.comboBoxOptionToString);
    if (method === 'include') {
        return fields;
    }
    return fields.map((field) => '~' + field);
}
function buildIndexPermissionState(indexPerm) {
    return indexPerm.map((perm) => ({
        indexPatterns: perm.index_patterns.map(combo_box_utils_1.stringToComboBoxOption),
        allowedActions: perm.allowed_actions.map(combo_box_utils_1.stringToComboBoxOption),
        docLevelSecurity: perm.dls,
        fieldLevelSecurityMethod: index_permission_utils_1.getFieldLevelSecurityMethod(perm.fls),
        fieldLevelSecurityFields: getFieldLevelSecurityFields(perm.fls),
        maskedFields: perm.masked_fields.map(combo_box_utils_1.stringToComboBoxOption),
    }));
}
exports.buildIndexPermissionState = buildIndexPermissionState;
function unbuildIndexPermissionState(indexPerm) {
    return indexPerm.map((perm) => ({
        index_patterns: perm.indexPatterns.map(combo_box_utils_1.comboBoxOptionToString),
        dls: perm.docLevelSecurity,
        fls: packFieldLevelSecurity(perm.fieldLevelSecurityMethod, perm.fieldLevelSecurityFields),
        masked_fields: perm.maskedFields.map(combo_box_utils_1.comboBoxOptionToString),
        allowed_actions: perm.allowedActions.map(combo_box_utils_1.comboBoxOptionToString),
    }));
}
exports.unbuildIndexPermissionState = unbuildIndexPermissionState;
const FIELD_LEVEL_SECURITY_PLACEHOLDER = `{
    "bool": {
        "must": {
            "match": {
                "genres": "Comedy"
            }
        }
    }
}`;
function IndexPatternRow(props) {
    return (react_1.default.createElement(form_row_1.FormRow, { headerText: "Index", helpText: "Specify index pattern using *" },
        react_1.default.createElement(eui_1.EuiComboBox, { noSuggestions: true, placeholder: "Search for index name or type in index pattern", selectedOptions: props.value, onChange: props.onChangeHandler, onCreateOption: props.onCreateHandler })));
}
exports.IndexPatternRow = IndexPatternRow;
function IndexPermissionRow(props) {
    return (react_1.default.createElement(form_row_1.FormRow, { headerText: "Index permissions", headerSubText: "You can specify permissions using both action groups or single permissions. \n        A permission group is a list of single permissions.\n        You can often achieve your desired security posture using some combination of the default permission groups. \n        You can also create your own reusable permission groups." },
        react_1.default.createElement(eui_1.EuiFlexGroup, null,
            react_1.default.createElement(eui_1.EuiFlexItem, { className: constant_1.LIMIT_WIDTH_INPUT_CLASS },
                react_1.default.createElement(eui_1.EuiComboBox, { placeholder: "Search for action group name or permission name", options: props.permisionOptionsSet, selectedOptions: props.value, onChange: props.onChangeHandler })),
            react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                react_1.default.createElement(display_utils_1.ExternalLinkButton, { href: url_builder_1.buildHashUrl(types_1.ResourceType.permissions), text: "Create new permission group" })))));
}
exports.IndexPermissionRow = IndexPermissionRow;
function DocLevelSecurityRow(props) {
    return (react_1.default.createElement(form_row_1.FormRow, { headerText: "Document level security", headerSubText: "You can restrict a role to a subset of documents in an index.", helpLink: constants_1.DocLinks.DocumentLevelSecurityDoc, optional: true },
        react_1.default.createElement(eui_1.EuiTextArea, { placeholder: FIELD_LEVEL_SECURITY_PLACEHOLDER, value: props.value, onChange: props.onChangeHandler })));
}
exports.DocLevelSecurityRow = DocLevelSecurityRow;
function FieldLevelSecurityRow(props) {
    return (react_1.default.createElement(form_row_1.FormRow, { headerText: "Field level security", headerSubText: "You can restrict what document fields a user can see. If you use field-level security in conjunction with document-level security, make sure you don't restrict access to the field that document-level security uses.", optional: true },
        react_1.default.createElement(eui_1.EuiFlexGroup, null,
            react_1.default.createElement(eui_1.EuiFlexItem, { grow: 1 },
                react_1.default.createElement(eui_1.EuiSuperSelect, { valueOfSelected: props.method, options: [
                        { inputDisplay: 'Include', value: 'include' },
                        { inputDisplay: 'Exclude', value: 'exclude' },
                    ], onChange: props.onMethodChangeHandler })),
            react_1.default.createElement(eui_1.EuiFlexItem, { grow: 9 },
                react_1.default.createElement(eui_1.EuiComboBox, { noSuggestions: true, placeholder: "Type in field name", selectedOptions: props.fields, onChange: props.onFieldChangeHandler, onCreateOption: props.onFieldCreateHandler })))));
}
exports.FieldLevelSecurityRow = FieldLevelSecurityRow;
function AnonymizationRow(props) {
    return (react_1.default.createElement(form_row_1.FormRow, { headerText: "Anonymization", headerSubText: "Masks any sensitive fields with a random value to protect your data security.", optional: true },
        react_1.default.createElement(eui_1.EuiComboBox, { noSuggestions: true, placeholder: "Type in field name", selectedOptions: props.value, onChange: props.onChangeHandler, onCreateOption: props.onCreateHandler })));
}
exports.AnonymizationRow = AnonymizationRow;
function generateIndexPermissionPanels(indexPermissions, permisionOptionsSet, setRoleIndexPermission) {
    const panels = indexPermissions.map((permission, arrayIndex) => {
        const onValueChangeHandler = (attributeToUpdate) => array_state_utils_1.updateElementInArrayHandler(setRoleIndexPermission, [arrayIndex, attributeToUpdate]);
        const onCreateOptionHandler = (attributeToUpdate) => combo_box_utils_1.appendOptionToComboBoxHandler(setRoleIndexPermission, [arrayIndex, attributeToUpdate]);
        return (react_1.default.createElement(react_1.Fragment, { key: `index-permission-${arrayIndex}` },
            react_1.default.createElement(eui_1.EuiAccordion, { id: `index-permission-${arrayIndex}`, initialIsOpen: arrayIndex === 0, buttonContent: permission.indexPatterns.map(combo_box_utils_1.comboBoxOptionToString).join(', ') ||
                    'Add index permission', extraAction: react_1.default.createElement(eui_1.EuiButton, { color: "danger", onClick: () => array_state_utils_1.removeElementFromArray(setRoleIndexPermission, [], arrayIndex) }, "Remove") },
                react_1.default.createElement(IndexPatternRow, { value: permission.indexPatterns, onChangeHandler: onValueChangeHandler('indexPatterns'), onCreateHandler: onCreateOptionHandler('indexPatterns') }),
                react_1.default.createElement(IndexPermissionRow, { value: permission.allowedActions, permisionOptionsSet: permisionOptionsSet, onChangeHandler: onValueChangeHandler('allowedActions') }),
                react_1.default.createElement(DocLevelSecurityRow, { value: permission.docLevelSecurity, onChangeHandler: (e) => onValueChangeHandler('docLevelSecurity')(e.target.value) }),
                react_1.default.createElement(FieldLevelSecurityRow, { method: permission.fieldLevelSecurityMethod, fields: permission.fieldLevelSecurityFields, onMethodChangeHandler: onValueChangeHandler('fieldLevelSecurityMethod'), onFieldChangeHandler: onValueChangeHandler('fieldLevelSecurityFields'), onFieldCreateHandler: onCreateOptionHandler('fieldLevelSecurityFields') }),
                react_1.default.createElement(AnonymizationRow, { value: permission.maskedFields, onChangeHandler: onValueChangeHandler('maskedFields'), onCreateHandler: onCreateOptionHandler('maskedFields') })),
            react_1.default.createElement(eui_1.EuiHorizontalRule, null)));
    });
    return react_1.default.createElement(react_1.default.Fragment, null, panels);
}
exports.generateIndexPermissionPanels = generateIndexPermissionPanels;
function IndexPermissionPanel(props) {
    const { state, optionUniverse, setState } = props;
    // Show one empty row if there is no data.
    if (lodash_1.isEmpty(state)) {
        setState([getEmptyIndexPermission()]);
    }
    return (react_1.default.createElement(panel_with_header_1.PanelWithHeader, { headerText: "Index permissions", headerSubText: "Index permissions allow you to specify how users in this role can access the specific indices. By default, no index permission is granted.", helpLink: constants_1.DocLinks.IndexPermissionsDoc },
        generateIndexPermissionPanels(state, optionUniverse, setState),
        react_1.default.createElement(eui_1.EuiButton, { onClick: () => {
                array_state_utils_1.appendElementToArray(setState, [], getEmptyIndexPermission());
            } }, "Add another index permission")));
}
exports.IndexPermissionPanel = IndexPermissionPanel;
