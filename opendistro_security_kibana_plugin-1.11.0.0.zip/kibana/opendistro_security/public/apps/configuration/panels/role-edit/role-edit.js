"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.RoleEdit = void 0;
const tslib_1 = require("tslib");
const eui_1 = require("@elastic/eui");
const react_1 = tslib_1.__importStar(require("react"));
const lodash_1 = require("lodash");
const constants_1 = require("../../constants");
const action_groups_utils_1 = require("../../utils/action-groups-utils");
const combo_box_utils_1 = require("../../utils/combo-box-utils");
const panel_with_header_1 = require("../../utils/panel-with-header");
const role_detail_utils_1 = require("../../utils/role-detail-utils");
const tenant_utils_1 = require("../../utils/tenant-utils");
const cluster_permission_panel_1 = require("./cluster-permission-panel");
const index_permission_panel_1 = require("./index-permission-panel");
const tenant_panel_1 = require("./tenant-panel");
const url_builder_1 = require("../../utils/url-builder");
const types_1 = require("../../types");
const toast_utils_1 = require("../../utils/toast-utils");
const storage_utils_1 = require("../../utils/storage-utils");
const display_utils_1 = require("../../utils/display-utils");
const resource_utils_1 = require("../../utils/resource-utils");
const name_row_1 = require("../../utils/name-row");
const TITLE_TEXT_DICT = {
    create: 'Create Role',
    edit: 'Edit Role',
    duplicate: 'Duplicate Role',
};
function RoleEdit(props) {
    const [roleName, setRoleName] = react_1.default.useState('');
    const [roleClusterPermission, setRoleClusterPermission] = react_1.useState([]);
    const [roleIndexPermission, setRoleIndexPermission] = react_1.useState([]);
    const [roleTenantPermission, setRoleTenantPermission] = react_1.useState([]);
    const [toasts, addToast, removeToast] = toast_utils_1.useToastState();
    const [isFormValid, setIsFormValid] = react_1.useState(true);
    react_1.default.useEffect(() => {
        const action = props.action;
        if (action === 'edit' || action === 'duplicate') {
            const fetchData = async () => {
                try {
                    const roleData = await role_detail_utils_1.getRoleDetail(props.coreStart.http, props.sourceRoleName);
                    setRoleClusterPermission(roleData.cluster_permissions.map(combo_box_utils_1.stringToComboBoxOption));
                    setRoleIndexPermission(index_permission_panel_1.buildIndexPermissionState(roleData.index_permissions));
                    setRoleTenantPermission(tenant_panel_1.buildTenantPermissionState(roleData.tenant_permissions));
                    setRoleName(resource_utils_1.generateResourceName(action, props.sourceRoleName));
                }
                catch (e) {
                    addToast(toast_utils_1.createUnknownErrorToast('fetchRole', 'load data'));
                    console.error(e);
                }
            };
            fetchData();
        }
    }, [addToast, props.action, props.coreStart.http, props.sourceRoleName]);
    const [actionGroups, setActionGroups] = react_1.useState([]);
    react_1.default.useEffect(() => {
        const fetchActionGroupNames = async () => {
            try {
                const actionGroupsObject = await action_groups_utils_1.fetchActionGroups(props.coreStart.http);
                setActionGroups(Object.keys(actionGroupsObject));
            }
            catch (e) {
                addToast(toast_utils_1.createUnknownErrorToast('actionGroup', 'load data'));
                console.error(e);
            }
        };
        fetchActionGroupNames();
    }, [addToast, props.coreStart.http]);
    const [tenantNames, setTenantNames] = react_1.default.useState([]);
    react_1.default.useEffect(() => {
        const fetchTenantNames = async () => {
            try {
                setTenantNames(await tenant_utils_1.fetchTenantNameList(props.coreStart.http));
            }
            catch (e) {
                addToast(toast_utils_1.createUnknownErrorToast('tenant', 'load data'));
                console.error(e);
            }
        };
        fetchTenantNames();
    }, [addToast, props.coreStart.http]);
    const updateRoleHandler = async () => {
        try {
            // Remove index/tenant permissions with empty patterns.
            const validIndexPermission = roleIndexPermission.filter((v) => !lodash_1.isEmpty(v.indexPatterns));
            const validTenantPermission = roleTenantPermission.filter((v) => !lodash_1.isEmpty(v.tenantPatterns));
            await role_detail_utils_1.updateRole(props.coreStart.http, roleName, {
                cluster_permissions: roleClusterPermission.map(combo_box_utils_1.comboBoxOptionToString),
                index_permissions: index_permission_panel_1.unbuildIndexPermissionState(validIndexPermission),
                tenant_permissions: tenant_panel_1.unbuildTenantPermissionState(validTenantPermission),
            });
            storage_utils_1.setCrossPageToast(url_builder_1.buildUrl(types_1.ResourceType.roles, types_1.Action.view, roleName), {
                id: 'updateRoleSucceeded',
                color: 'success',
                title: toast_utils_1.getSuccessToastMessage('Role', props.action, roleName),
            });
            // Redirect to role view
            window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.roles, types_1.Action.view, roleName);
        }
        catch (e) {
            addToast(toast_utils_1.createUnknownErrorToast('updateRole', `${props.action} role`));
            console.error(e);
        }
    };
    const clusterWisePermissionOptions = [
        {
            label: 'Permission groups',
            options: actionGroups.map(combo_box_utils_1.stringToComboBoxOption),
        },
        {
            label: 'Cluster permissions',
            options: constants_1.CLUSTER_PERMISSIONS.map(combo_box_utils_1.stringToComboBoxOption),
        },
        {
            label: 'Index permissions',
            options: constants_1.INDEX_PERMISSIONS.map(combo_box_utils_1.stringToComboBoxOption),
        },
    ];
    const tenantOptions = tenantNames.map(combo_box_utils_1.stringToComboBoxOption);
    return (react_1.default.createElement(react_1.default.Fragment, null,
        props.buildBreadcrumbs(TITLE_TEXT_DICT[props.action]),
        react_1.default.createElement(eui_1.EuiPageHeader, null,
            react_1.default.createElement(eui_1.EuiText, { size: "xs", color: "subdued", className: "panel-header-subtext" },
                react_1.default.createElement(eui_1.EuiTitle, { size: "m" },
                    react_1.default.createElement("h1", null, TITLE_TEXT_DICT[props.action])),
                "Roles are the core way of controlling access to your cluster. Roles contain any combination of cluster-wide permission, index-specific permissions, document- and field-level security, and tenants. Once you've created the role, you can map users to the roles so that users gain those permissions.",
                ' ',
                react_1.default.createElement(display_utils_1.ExternalLink, { href: constants_1.DocLinks.UsersAndRolesDoc }))),
        react_1.default.createElement(panel_with_header_1.PanelWithHeader, { headerText: "Name" },
            react_1.default.createElement(eui_1.EuiForm, null,
                react_1.default.createElement(name_row_1.NameRow, { headerText: "Name", headerSubText: "Specify a descriptive and unique role name. You cannot edit the name once the role is created.", resourceName: roleName, resourceType: "role", action: props.action, setNameState: setRoleName, setIsFormValid: setIsFormValid }))),
        react_1.default.createElement(eui_1.EuiSpacer, { size: "m" }),
        react_1.default.createElement(cluster_permission_panel_1.ClusterPermissionPanel, { state: roleClusterPermission, setState: setRoleClusterPermission, optionUniverse: clusterWisePermissionOptions }),
        react_1.default.createElement(eui_1.EuiSpacer, { size: "m" }),
        react_1.default.createElement(index_permission_panel_1.IndexPermissionPanel, { state: roleIndexPermission, setState: setRoleIndexPermission, optionUniverse: clusterWisePermissionOptions }),
        react_1.default.createElement(eui_1.EuiSpacer, { size: "m" }),
        react_1.default.createElement(tenant_panel_1.TenantPanel, { state: roleTenantPermission, setState: setRoleTenantPermission, optionUniverse: tenantOptions }),
        react_1.default.createElement(eui_1.EuiSpacer, { size: "m" }),
        react_1.default.createElement(eui_1.EuiFlexGroup, { justifyContent: "flexEnd" },
            react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                react_1.default.createElement(eui_1.EuiButton, { onClick: () => {
                        window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.roles);
                    } }, "Cancel")),
            react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                react_1.default.createElement(eui_1.EuiButton, { fill: true, onClick: updateRoleHandler, disabled: !isFormValid }, props.action === 'edit' ? 'Update' : 'Create'))),
        react_1.default.createElement(eui_1.EuiGlobalToastList, { toasts: toasts, toastLifeTimeMs: 10000, dismissToast: removeToast })));
}
exports.RoleEdit = RoleEdit;
