"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantPanel = exports.unbuildTenantPermissionState = exports.buildTenantPermissionState = void 0;
const tslib_1 = require("tslib");
const eui_1 = require("@elastic/eui");
const react_1 = tslib_1.__importStar(require("react"));
const lodash_1 = require("lodash");
const types_1 = require("../../types");
const array_state_utils_1 = require("../../utils/array-state-utils");
const combo_box_utils_1 = require("../../utils/combo-box-utils");
const form_row_1 = require("../../utils/form-row");
const panel_with_header_1 = require("../../utils/panel-with-header");
const constants_1 = require("../../constants");
const tenant_utils_1 = require("../../utils/tenant-utils");
function buildTenantPermissionState(permissions) {
    return permissions.map((permission) => {
        const permissionType = tenant_utils_1.getTenantPermissionType(permission.allowed_actions);
        return {
            tenantPatterns: permission.tenant_patterns.map(combo_box_utils_1.stringToComboBoxOption),
            permissionType,
        };
    });
}
exports.buildTenantPermissionState = buildTenantPermissionState;
const TENANT_PERMISSION_TYPE_DICT = {
    [types_1.TenantPermissionType.Full]: [constants_1.TENANT_READ_PERMISSION, constants_1.TENANT_WRITE_PERMISSION],
    [types_1.TenantPermissionType.Read]: [constants_1.TENANT_READ_PERMISSION],
    [types_1.TenantPermissionType.Write]: [constants_1.TENANT_WRITE_PERMISSION],
    [types_1.TenantPermissionType.None]: [],
};
function unbuildTenantPermissionState(permissions) {
    return permissions.map((permission) => {
        return {
            tenant_patterns: permission.tenantPatterns.map(combo_box_utils_1.comboBoxOptionToString),
            allowed_actions: TENANT_PERMISSION_TYPE_DICT[permission.permissionType],
        };
    });
}
exports.unbuildTenantPermissionState = unbuildTenantPermissionState;
function getEmptyTenantPermission() {
    return {
        tenantPatterns: [],
        permissionType: types_1.TenantPermissionType.Full,
    };
}
function generateTenantPermissionPanels(tenantPermissions, permisionOptionsSet, setPermissions) {
    const panels = tenantPermissions.map((tenantPermission, arrayIndex) => {
        const onValueChangeHandler = (attributeToUpdate) => array_state_utils_1.updateElementInArrayHandler(setPermissions, [arrayIndex, attributeToUpdate]);
        const onCreateOptionHandler = (attributeToUpdate) => combo_box_utils_1.appendOptionToComboBoxHandler(setPermissions, [arrayIndex, attributeToUpdate]);
        return (react_1.default.createElement(react_1.Fragment, { key: `tenant-permission-${arrayIndex}` },
            react_1.default.createElement(eui_1.EuiFlexGroup, null,
                react_1.default.createElement(eui_1.EuiFlexItem, { style: { maxWidth: '400px' } },
                    react_1.default.createElement(eui_1.EuiComboBox, { placeholder: "Search tenant name or add a tenant pattern", selectedOptions: tenantPermission.tenantPatterns, onChange: onValueChangeHandler('tenantPatterns'), onCreateOption: onCreateOptionHandler('tenantPatterns'), options: permisionOptionsSet })),
                react_1.default.createElement(eui_1.EuiFlexItem, { style: { maxWidth: '170px' } },
                    react_1.default.createElement(eui_1.EuiSuperSelect, { valueOfSelected: tenantPermission.permissionType, onChange: onValueChangeHandler('permissionType'), options: [
                            { inputDisplay: types_1.TenantPermissionType.Read, value: types_1.TenantPermissionType.Read },
                            { inputDisplay: types_1.TenantPermissionType.Write, value: types_1.TenantPermissionType.Write },
                            { inputDisplay: types_1.TenantPermissionType.Full, value: types_1.TenantPermissionType.Full },
                        ] })),
                react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                    react_1.default.createElement(eui_1.EuiButton, { color: "danger", onClick: () => array_state_utils_1.removeElementFromArray(setPermissions, [], arrayIndex) }, "Remove")))));
    });
    return react_1.default.createElement(react_1.default.Fragment, null, panels);
}
function TenantPanel(props) {
    const { state, optionUniverse, setState } = props;
    // Show one empty row if there is no data.
    if (lodash_1.isEmpty(state)) {
        setState([getEmptyTenantPermission()]);
    }
    return (react_1.default.createElement(panel_with_header_1.PanelWithHeader, { headerText: "Tenant permissions", headerSubText: "Tenants are useful for safely sharing your work with other Kibana users. You can control which roles have access to a tenant and whether those roles have read and/or write access.", helpLink: constants_1.DocLinks.TenantPermissionsDoc },
        react_1.default.createElement(form_row_1.FormRow, { headerText: "Tenant" }, generateTenantPermissionPanels(state, optionUniverse, setState)),
        react_1.default.createElement(eui_1.EuiButton, { onClick: () => {
                array_state_utils_1.appendElementToArray(setState, [], getEmptyTenantPermission());
            } }, "Add another tenant permission")));
}
exports.TenantPanel = TenantPanel;
