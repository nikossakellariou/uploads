"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClusterPermissionPanel = void 0;
const tslib_1 = require("tslib");
require("./_index.scss");
const react_1 = tslib_1.__importDefault(require("react"));
const eui_1 = require("@elastic/eui");
const types_1 = require("../../types");
const panel_with_header_1 = require("../../utils/panel-with-header");
const form_row_1 = require("../../utils/form-row");
const constant_1 = require("./constant");
const display_utils_1 = require("../../utils/display-utils");
const url_builder_1 = require("../../utils/url-builder");
const constants_1 = require("../../constants");
function ClusterPermissionPanel(props) {
    const { state, optionUniverse, setState } = props;
    return (react_1.default.createElement(panel_with_header_1.PanelWithHeader, { headerText: "Cluster permissions", headerSubText: "Specify how users in this role can access the cluster. By default, no cluster permission is granted.", helpLink: constants_1.DocLinks.ClusterPermissionsDoc },
        react_1.default.createElement(eui_1.EuiForm, null,
            react_1.default.createElement(form_row_1.FormRow, { headerText: "Cluster Permissions", headerSubText: "Specify permissions using either action groups or single permissions. An action group is a list of single permissions.\n        You can often achieve your desired security posture using some combination of the default permission groups. You can\n        also create your own reusable permission groups." },
                react_1.default.createElement(eui_1.EuiFlexGroup, null,
                    react_1.default.createElement(eui_1.EuiFlexItem, { className: constant_1.LIMIT_WIDTH_INPUT_CLASS },
                        react_1.default.createElement(eui_1.EuiComboBox, { placeholder: "Search for action group name or permission name", options: optionUniverse, selectedOptions: state, onChange: setState })),
                    react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                        react_1.default.createElement(display_utils_1.ExternalLinkButton, { href: url_builder_1.buildHashUrl(types_1.ResourceType.permissions), text: "Create new permission group" })))))));
}
exports.ClusterPermissionPanel = ClusterPermissionPanel;
