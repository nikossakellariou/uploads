"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.RoleView = void 0;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importStar(require("react"));
const eui_1 = require("@elastic/eui");
const lodash_1 = require("lodash");
const url_builder_1 = require("../../utils/url-builder");
const types_1 = require("../../types");
const role_mapping_utils_1 = require("../../utils/role-mapping-utils");
const toast_utils_1 = require("../../utils/toast-utils");
const action_groups_utils_1 = require("../../utils/action-groups-utils");
const role_detail_utils_1 = require("../../utils/role-detail-utils");
const cluster_permission_panel_1 = require("../role-view/cluster-permission-panel");
const index_permission_panel_1 = require("./index-permission-panel");
const tenants_panel_1 = require("./tenants-panel");
const index_permission_utils_1 = require("../../utils/index-permission-utils");
const tenant_utils_1 = require("../../utils/tenant-utils");
const constants_1 = require("../../constants");
const delete_confirm_modal_utils_1 = require("../../utils/delete-confirm-modal-utils");
const display_utils_1 = require("../../utils/display-utils");
const loading_spinner_utils_1 = require("../../utils/loading-spinner-utils");
const context_menu_1 = require("../../utils/context-menu");
const role_list_utils_1 = require("../../utils/role-list-utils");
const storage_utils_1 = require("../../utils/storage-utils");
const mappedUserColumns = [
    {
        field: 'userType',
        name: 'User type',
        sortable: true,
    },
    {
        field: 'userName',
        name: 'User',
        sortable: true,
        truncateText: true,
    },
];
function RoleView(props) {
    const duplicateRoleLink = url_builder_1.buildHashUrl(types_1.ResourceType.roles, types_1.Action.duplicate, props.roleName);
    const [mappedUsers, setMappedUsers] = react_1.default.useState([]);
    const [errorFlag, setErrorFlag] = react_1.default.useState(false);
    const [selection, setSelection] = react_1.useState([]);
    const [hosts, setHosts] = react_1.default.useState([]);
    const [actionGroupDict, setActionGroupDict] = react_1.default.useState({});
    const [roleClusterPermission, setRoleClusterPermission] = react_1.useState([]);
    const [roleIndexPermission, setRoleIndexPermission] = react_1.default.useState([]);
    const [roleTenantPermission, setRoleTenantPermission] = react_1.default.useState([]);
    const [toasts, addToast, removeToast] = toast_utils_1.useToastState();
    const [isReserved, setIsReserved] = react_1.default.useState(false);
    const [loading, setLoading] = react_1.default.useState(false);
    const PERMISSIONS_TAB_INDEX = 0;
    const MAP_USER_TAB_INDEX = 1;
    react_1.default.useEffect(() => {
        const fetchData = async () => {
            try {
                setLoading(true);
                const originalRoleMapData = await role_mapping_utils_1.getRoleMappingData(props.coreStart.http, props.roleName);
                if (originalRoleMapData) {
                    setMappedUsers(role_mapping_utils_1.transformRoleMappingData(originalRoleMapData));
                    setHosts(originalRoleMapData.hosts);
                }
                const actionGroups = await action_groups_utils_1.fetchActionGroups(props.coreStart.http);
                setActionGroupDict(actionGroups);
                const roleData = await role_detail_utils_1.getRoleDetail(props.coreStart.http, props.roleName);
                setIsReserved(roleData.reserved);
                setRoleClusterPermission(roleData.cluster_permissions);
                setRoleIndexPermission(index_permission_utils_1.transformRoleIndexPermissions(roleData.index_permissions));
                setRoleTenantPermission(tenant_utils_1.transformRoleTenantPermissions(roleData.tenant_permissions));
            }
            catch (e) {
                addToast(toast_utils_1.createUnknownErrorToast('fetchRoleMappingData', 'load data'));
                console.log(e);
                setErrorFlag(true);
            }
            finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [addToast, props.coreStart.http, props.roleName, props.prevAction]);
    const handleRoleMappingDelete = async () => {
        try {
            const usersToDelete = selection.map((r) => r.userName);
            const internalUsers = mappedUsers
                .filter((r) => r.userType === role_mapping_utils_1.UserType.internal)
                .map((r) => r.userName);
            const externalIdentities = mappedUsers
                .filter((r) => r.userType === role_mapping_utils_1.UserType.external)
                .map((r) => r.userName);
            const updateObject = {
                users: lodash_1.difference(internalUsers, usersToDelete),
                backend_roles: lodash_1.difference(externalIdentities, usersToDelete),
                hosts,
            };
            await role_mapping_utils_1.updateRoleMapping(props.coreStart.http, props.roleName, updateObject);
            setMappedUsers(lodash_1.difference(mappedUsers, selection));
            setSelection([]);
        }
        catch (e) {
            console.log(e);
        }
    };
    const [showDeleteConfirmModal, deleteConfirmModal] = delete_confirm_modal_utils_1.useDeleteConfirmState(handleRoleMappingDelete, 'mapping(s)');
    const emptyListMessage = (react_1.default.createElement(eui_1.EuiEmptyPrompt, { title: react_1.default.createElement("h2", null, "No user has been mapped to this role"), titleSize: "s", body: react_1.default.createElement(eui_1.EuiText, { size: "s", color: "subdued", grow: false },
            react_1.default.createElement("p", null, "You can map internal users or external identities to this role")), actions: react_1.default.createElement(eui_1.EuiFlexGroup, { gutterSize: "s", alignItems: "center" },
            react_1.default.createElement(eui_1.EuiFlexItem, null,
                react_1.default.createElement(display_utils_1.ExternalLinkButton, { text: "Create internal user", href: url_builder_1.buildHashUrl(types_1.ResourceType.users, types_1.Action.create) })),
            react_1.default.createElement(eui_1.EuiFlexItem, null,
                react_1.default.createElement(eui_1.EuiButton, { "data-test-subj": "edit-rolemapping", fill: true, onClick: () => {
                        window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.roles, types_1.Action.edit, props.roleName, types_1.SubAction.mapuser);
                    } }, "Map users"))) }));
    const tabs = [
        {
            id: 'permissions',
            name: 'Permissions',
            disabled: false,
            content: (react_1.default.createElement(react_1.default.Fragment, null,
                react_1.default.createElement(eui_1.EuiSpacer, { size: "m" }),
                isReserved && (react_1.default.createElement(eui_1.EuiCallOut, { title: "This role is reserved for the Security plugin environment. Reserved roles are restricted for any permission customizations.", iconType: "lock", size: "s" },
                    react_1.default.createElement("p", null,
                        "Make use of this role by mapping users. You can also",
                        ' ',
                        react_1.default.createElement(eui_1.EuiLink, { href: url_builder_1.buildHashUrl(types_1.ResourceType.roles, types_1.Action.create) }, "create your own role"),
                        ' ',
                        "or ",
                        react_1.default.createElement(eui_1.EuiLink, { href: duplicateRoleLink }, "duplicate"),
                        " this one for further customization."))),
                react_1.default.createElement(eui_1.EuiSpacer, { size: "m" }),
                react_1.default.createElement(cluster_permission_panel_1.ClusterPermissionPanel, { roleName: props.roleName, clusterPermissions: roleClusterPermission, actionGroups: actionGroupDict, loading: loading, isReserved: isReserved }),
                react_1.default.createElement(eui_1.EuiSpacer, { size: "m" }),
                react_1.default.createElement(index_permission_panel_1.IndexPermissionPanel, { roleName: props.roleName, indexPermissions: roleIndexPermission, actionGroups: actionGroupDict, errorFlag: errorFlag, loading: loading, isReserved: isReserved }),
                react_1.default.createElement(eui_1.EuiSpacer, { size: "m" }),
                react_1.default.createElement(tenants_panel_1.TenantsPanel, { roleName: props.roleName, tenantPermissions: roleTenantPermission, errorFlag: errorFlag, coreStart: props.coreStart, loading: loading, isReserved: isReserved }))),
        },
        {
            id: 'users',
            name: 'Mapped users',
            disabled: false,
            content: (react_1.default.createElement(react_1.default.Fragment, null,
                react_1.default.createElement(eui_1.EuiSpacer, null),
                react_1.default.createElement(eui_1.EuiPageContent, null,
                    react_1.default.createElement(eui_1.EuiPageContentHeader, null,
                        react_1.default.createElement(eui_1.EuiPageContentHeaderSection, null,
                            react_1.default.createElement(eui_1.EuiTitle, { size: "s" },
                                react_1.default.createElement("h3", null,
                                    "Mapped users",
                                    react_1.default.createElement("span", { className: "panel-header-count" },
                                        " (",
                                        mappedUsers.length,
                                        ")"))),
                            react_1.default.createElement(eui_1.EuiText, { size: "xs", color: "subdued", className: "panel-header-subtext" },
                                "You can map two types of users: internal users and external identities. An internal user can have its own backend role and host for an external authentication and authorization. An external identity directly maps to roles through an external authentication system.",
                                ' ',
                                react_1.default.createElement(display_utils_1.ExternalLink, { href: constants_1.DocLinks.MapUsersToRolesDoc }))),
                        react_1.default.createElement(eui_1.EuiPageContentHeaderSection, null,
                            react_1.default.createElement(eui_1.EuiFlexGroup, null,
                                react_1.default.createElement(eui_1.EuiFlexItem, null,
                                    react_1.default.createElement(eui_1.EuiButton, { onClick: showDeleteConfirmModal, disabled: selection.length === 0 }, "Delete mapping")),
                                react_1.default.createElement(eui_1.EuiFlexItem, null,
                                    react_1.default.createElement(eui_1.EuiButton, { onClick: () => {
                                            window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.roles, types_1.Action.edit, props.roleName, types_1.SubAction.mapuser);
                                        } }, "Manage mapping"))))),
                    react_1.default.createElement(eui_1.EuiHorizontalRule, { margin: "s" }),
                    react_1.default.createElement(eui_1.EuiPageBody, null,
                        react_1.default.createElement(eui_1.EuiInMemoryTable, { "data-test-subj": "role-mapping-list", tableLayout: 'auto', loading: mappedUsers === [] && !errorFlag, columns: mappedUserColumns, items: mappedUsers, itemId: 'userName', pagination: true, message: loading_spinner_utils_1.showTableStatusMessage(loading, mappedUsers, emptyListMessage), selection: { onSelectionChange: setSelection }, sorting: true, error: errorFlag ? 'Load data failed, please check console log for more detail.' : '' }))))),
        },
    ];
    let pageActions;
    const actionsMenuItems = [
        react_1.default.createElement(eui_1.EuiButtonEmpty, { key: "duplicate", href: duplicateRoleLink }, "duplicate"),
        react_1.default.createElement(eui_1.EuiButtonEmpty, { "data-test-subj": "delete", key: "delete", color: "danger", onClick: async () => {
                try {
                    await role_list_utils_1.requestDeleteRoles(props.coreStart.http, [props.roleName]);
                    storage_utils_1.setCrossPageToast(url_builder_1.buildUrl(types_1.ResourceType.roles), {
                        id: 'deleteRole',
                        color: 'success',
                        title: props.roleName + ' deleted.',
                    });
                    window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.roles);
                }
                catch (e) {
                    addToast(toast_utils_1.createUnknownErrorToast('deleteRole', 'delete role'));
                }
            } }, "delete"),
    ];
    const [actionsMenu] = context_menu_1.useContextMenuState('Actions', {}, actionsMenuItems);
    if (isReserved) {
        pageActions = react_1.default.createElement(eui_1.EuiButton, { href: duplicateRoleLink }, "Duplicate role");
    }
    else {
        pageActions = (react_1.default.createElement(eui_1.EuiFlexGroup, { gutterSize: "s" },
            react_1.default.createElement(eui_1.EuiFlexItem, null, actionsMenu),
            react_1.default.createElement(eui_1.EuiFlexItem, null,
                react_1.default.createElement(eui_1.EuiButton, { href: url_builder_1.buildHashUrl(types_1.ResourceType.roles, types_1.Action.edit, props.roleName) }, "Edit role"))));
    }
    return (react_1.default.createElement(react_1.default.Fragment, null,
        props.buildBreadcrumbs(props.roleName),
        react_1.default.createElement(eui_1.EuiPageContentHeader, null,
            react_1.default.createElement(eui_1.EuiPageContentHeaderSection, null,
                react_1.default.createElement(eui_1.EuiTitle, { size: "l" },
                    react_1.default.createElement("h1", null, props.roleName))),
            react_1.default.createElement(eui_1.EuiPageContentHeaderSection, null, pageActions)),
        react_1.default.createElement(eui_1.EuiTabbedContent, { tabs: tabs, initialSelectedTab: props.prevAction === types_1.SubAction.mapuser
                ? tabs[MAP_USER_TAB_INDEX]
                : tabs[PERMISSIONS_TAB_INDEX] }),
        react_1.default.createElement(eui_1.EuiSpacer, null),
        react_1.default.createElement(eui_1.EuiGlobalToastList, { toasts: toasts, toastLifeTimeMs: 10000, dismissToast: removeToast }),
        deleteConfirmModal));
}
exports.RoleView = RoleView;
