"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantsPanel = void 0;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importDefault(require("react"));
const eui_1 = require("@elastic/eui");
const auth_info_utils_1 = require("../../../../utils/auth-info-utils");
const panel_with_header_1 = require("../../utils/panel-with-header");
const types_1 = require("../../types");
const display_utils_1 = require("../../utils/display-utils");
const tenant_utils_1 = require("../../utils/tenant-utils");
const constants_1 = require("../../constants");
const types_2 = require("../../types");
const chrome_wrapper_1 = require("../../../../services/chrome_wrapper");
const toast_utils_1 = require("../../utils/toast-utils");
const loading_spinner_utils_1 = require("../../utils/loading-spinner-utils");
const url_builder_1 = require("../../utils/url-builder");
function TenantsPanel(props) {
    const [tenantPermissionDetail, setTenantPermissionDetail] = react_1.default.useState([]);
    const [currentUsername, setCurrentUsername] = react_1.default.useState('');
    const [toasts, addToast, removeToast] = toast_utils_1.useToastState();
    const [errorFlag, setErrorFlag] = react_1.default.useState(props.errorFlag);
    react_1.default.useEffect(() => {
        const fetchData = async () => {
            try {
                const rawTenantData = await tenant_utils_1.fetchTenants(props.coreStart.http);
                const processedTenantData = tenant_utils_1.transformTenantData(rawTenantData, false);
                setTenantPermissionDetail(tenant_utils_1.transformRoleTenantPermissionData(props.tenantPermissions, processedTenantData));
                const currentUser = await auth_info_utils_1.getCurrentUser(props.coreStart.http);
                setCurrentUsername(currentUser);
            }
            catch (e) {
                console.log(e);
                setErrorFlag(true);
            }
        };
        fetchData();
    }, [props]);
    const viewDashboard = async (tenantName) => {
        try {
            await tenant_utils_1.selectTenant(props.coreStart.http, {
                tenant: tenantName,
                username: currentUsername,
            });
            window.location.href = chrome_wrapper_1.getNavLinkById(props.coreStart, types_2.PageId.dashboardId);
        }
        catch (e) {
            console.log(e);
            addToast(toast_utils_1.createUnknownErrorToast('viewDashboard', `view dashboard for ${tenantName} tenant`));
        }
    };
    const viewVisualization = async (tenantName) => {
        try {
            await tenant_utils_1.selectTenant(props.coreStart.http, {
                tenant: tenantName,
                username: currentUsername,
            });
            window.location.href = chrome_wrapper_1.getNavLinkById(props.coreStart, types_2.PageId.visualizationId);
        }
        catch (e) {
            console.log(e);
            addToast(toast_utils_1.createUnknownErrorToast('viewVisualization', `view visualization for ${tenantName} tenant`));
        }
    };
    const columns = [
        {
            field: 'tenant_patterns',
            name: 'Name',
            render: display_utils_1.truncatedListView(display_utils_1.tableItemsUIProps),
            truncateText: true,
            sortable: true,
        },
        {
            field: 'description',
            name: 'Description',
            truncateText: true,
        },
        {
            field: 'permissionType',
            name: 'Read/write permission',
        },
        {
            field: 'tenantValue',
            name: 'Dashboard',
            render: (tenant) => {
                if (tenant === constants_1.RoleViewTenantInvalidText) {
                    return (react_1.default.createElement(react_1.default.Fragment, null,
                        react_1.default.createElement(eui_1.EuiText, { size: "s" }, constants_1.RoleViewTenantInvalidText)));
                }
                return (react_1.default.createElement(react_1.default.Fragment, null,
                    react_1.default.createElement(eui_1.EuiLink, { onClick: () => viewDashboard(tenant) }, "View dashboard")));
            },
        },
        {
            field: 'tenantValue',
            name: 'Visualizations',
            render: (tenant) => {
                if (tenant === constants_1.RoleViewTenantInvalidText) {
                    return (react_1.default.createElement(react_1.default.Fragment, null,
                        react_1.default.createElement(eui_1.EuiText, { size: "s" }, constants_1.RoleViewTenantInvalidText)));
                }
                return (react_1.default.createElement(react_1.default.Fragment, null,
                    react_1.default.createElement(eui_1.EuiLink, { onClick: () => viewVisualization(tenant) }, "View visualizations")));
            },
        },
    ];
    const emptyListMessage = (react_1.default.createElement(eui_1.EuiEmptyPrompt, { title: react_1.default.createElement("h3", null, "No tenant permission"), titleSize: "s", actions: react_1.default.createElement(eui_1.EuiButton, { "data-test-subj": "addTenantPermission", disabled: props.isReserved, onClick: () => {
                window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.roles, types_1.Action.edit, props.roleName);
            } }, "Add tenant permission") }));
    const headerText = 'Tenant permissions';
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement(panel_with_header_1.PanelWithHeader, { headerText: headerText, headerSubText: "Tenants in Kibana are spaces for saving index patterns, visualizations, dashboards, and other Kibana objects. \n        Tenants are useful for safely sharing your work with other Kibana users. \n        You can control which roles have access to a tenant and whether those roles have read or write access.", helpLink: constants_1.DocLinks.TenantPermissionsDoc, count: tenantPermissionDetail.length },
            react_1.default.createElement(eui_1.EuiInMemoryTable, { "data-test-subj": "tenant-permission-container", tableLayout: 'auto', loading: tenantPermissionDetail === [] && !errorFlag, columns: columns, items: tenantPermissionDetail, sorting: { sort: { field: 'type', direction: 'asc' } }, error: errorFlag ? 'Load data failed, please check console log for more detail.' : '', message: loading_spinner_utils_1.showTableStatusMessage(props.loading, props.tenantPermissions, emptyListMessage) })),
        react_1.default.createElement(eui_1.EuiGlobalToastList, { toasts: toasts, toastLifeTimeMs: 10000, dismissToast: removeToast })));
}
exports.TenantsPanel = TenantsPanel;
