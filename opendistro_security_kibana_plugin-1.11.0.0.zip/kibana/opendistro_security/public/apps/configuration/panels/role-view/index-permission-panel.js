"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.IndexPermissionPanel = exports.renderFieldLevelSecurity = exports.renderRowExpanstionArrow = exports.toggleRowDetails = void 0;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importStar(require("react"));
const eui_1 = require("@elastic/eui");
const panel_with_header_1 = require("../../utils/panel-with-header");
const types_1 = require("../../types");
const display_utils_1 = require("../../utils/display-utils");
const permission_tree_1 = require("../permission-tree");
const index_permission_utils_1 = require("../../utils/index-permission-utils");
const display_utils_2 = require("../../utils/display-utils");
const constants_1 = require("../../constants");
const loading_spinner_utils_1 = require("../../utils/loading-spinner-utils");
const url_builder_1 = require("../../utils/url-builder");
const ui_constants_1 = require("../../ui-constants");
function toggleRowDetails(item, actionGroupDict, setItemIdToExpandedRowMap) {
    setItemIdToExpandedRowMap((prevState) => {
        const itemIdToExpandedRowMapValues = { ...prevState };
        if (itemIdToExpandedRowMapValues[item.id]) {
            delete itemIdToExpandedRowMapValues[item.id];
        }
        else {
            itemIdToExpandedRowMapValues[item.id] = (react_1.default.createElement(permission_tree_1.PermissionTree, { permissions: item.allowed_actions, actionGroups: actionGroupDict }));
        }
        return itemIdToExpandedRowMapValues;
    });
}
exports.toggleRowDetails = toggleRowDetails;
function renderRowExpanstionArrow(itemIdToExpandedRowMap, actionGroupDict, setItemIdToExpandedRowMap) {
    return (item) => (react_1.default.createElement(eui_1.EuiButtonIcon, { onClick: () => toggleRowDetails(item, actionGroupDict, setItemIdToExpandedRowMap), "aria-label": itemIdToExpandedRowMap[item.id] ? 'Collapse' : 'Expand', iconType: itemIdToExpandedRowMap[item.id] ? 'arrowUp' : 'arrowDown' }));
}
exports.renderRowExpanstionArrow = renderRowExpanstionArrow;
function renderFieldLevelSecurity() {
    return (items) => {
        // Show - to indicate empty
        if (items === undefined || items.length === 0) {
            return (react_1.default.createElement(eui_1.EuiFlexGroup, { direction: "column", style: { margin: '1px' } },
                react_1.default.createElement(eui_1.EuiText, { "data-test-subj": "empty-fls-text", key: '-', className: display_utils_1.tableItemsUIProps.cssClassName }, ui_constants_1.EMPTY_FIELD_VALUE)));
        }
        return (react_1.default.createElement(eui_1.EuiFlexGroup, { direction: "column", style: { margin: '1px' } },
            react_1.default.createElement(eui_1.EuiText, { "data-test-subj": "fls-text", className: display_utils_1.tableItemsUIProps.cssClassName },
                index_permission_utils_1.getFieldLevelSecurityMethod(items) === 'exclude' ? 'Exclude' : 'Include',
                ":",
                ' ',
                display_utils_1.displayArray(items.map((s) => s.replace(/^~/, ''))))));
    };
}
exports.renderFieldLevelSecurity = renderFieldLevelSecurity;
function getColumns(itemIdToExpandedRowMap, actionGroupDict, setItemIdToExpandedRowMap) {
    return [
        {
            field: 'index_patterns',
            name: 'Index',
            sortable: true,
            render: display_utils_1.truncatedListView(display_utils_1.tableItemsUIProps),
            truncateText: true,
        },
        {
            field: 'allowed_actions',
            name: 'Permissions',
            render: display_utils_1.truncatedListView(display_utils_1.tableItemsUIProps),
            truncateText: true,
        },
        {
            field: 'dls',
            name: display_utils_2.displayHeaderWithTooltip('Document-level security', constants_1.ToolTipContent.DocumentLevelSecurity),
            render: (dls) => {
                if (!dls) {
                    return ui_constants_1.EMPTY_FIELD_VALUE;
                }
                // TODO: unify the experience for both cases which may require refactoring of renderExpression.
                try {
                    return display_utils_2.renderExpression('Document-level security', JSON.parse(dls));
                }
                catch (e) {
                    // Support the use case for $variable without double quotes in DLS, e.g. variable is an array.
                    console.warn('Failed to parse dls as json!');
                    return dls;
                }
            },
        },
        {
            field: 'fls',
            name: display_utils_2.displayHeaderWithTooltip('Field-level security', constants_1.ToolTipContent.FieldLevelSecurity),
            render: renderFieldLevelSecurity(),
        },
        {
            field: 'masked_fields',
            name: 'Anonymizations',
            render: display_utils_1.truncatedListView(display_utils_1.tableItemsUIProps),
            truncateText: true,
        },
        {
            align: eui_1.RIGHT_ALIGNMENT,
            width: '40px',
            isExpander: true,
            render: renderRowExpanstionArrow(itemIdToExpandedRowMap, actionGroupDict, setItemIdToExpandedRowMap),
        },
    ];
}
function IndexPermissionPanel(props) {
    const [itemIdToExpandedRowMap, setItemIdToExpandedRowMap] = react_1.useState({});
    const emptyListMessage = (react_1.default.createElement(eui_1.EuiEmptyPrompt, { title: react_1.default.createElement("h3", null, "No index permission"), titleSize: "s", actions: react_1.default.createElement(eui_1.EuiButton, { "data-test-subj": "addIndexPermission", disabled: props.isReserved, onClick: () => {
                window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.roles, types_1.Action.edit, props.roleName);
            } }, "Add index permission") }));
    const headerText = 'Index permissions';
    return (react_1.default.createElement(panel_with_header_1.PanelWithHeader, { headerText: headerText, headerSubText: "Index permissions allow you to specify how users in this role can access the indices. You can restrict a role to a subset of documents in an index,\n      and which document fields a user can see as well. If you use field-level security in conjunction with document-level security,\n      make sure you don't restrict access to the fields that document-level security uses.", helpLink: constants_1.DocLinks.IndexPermissionsDoc, count: props.indexPermissions.length },
        react_1.default.createElement(eui_1.EuiInMemoryTable, { "data-test-subj": "index-permission-container", tableLayout: 'auto', loading: props.indexPermissions === [] && !props.errorFlag, columns: getColumns(itemIdToExpandedRowMap, props.actionGroups, setItemIdToExpandedRowMap), items: props.indexPermissions, itemId: 'id', sorting: { sort: { field: 'type', direction: 'asc' } }, error: props.errorFlag ? 'Load data failed, please check console log for more detail.' : '', isExpandable: true, itemIdToExpandedRowMap: itemIdToExpandedRowMap, message: loading_spinner_utils_1.showTableStatusMessage(props.loading, props.indexPermissions, emptyListMessage) })));
}
exports.IndexPermissionPanel = IndexPermissionPanel;
