"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClusterPermissionPanel = void 0;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importDefault(require("react"));
const eui_1 = require("@elastic/eui");
const panel_with_header_1 = require("../../utils/panel-with-header");
const permission_tree_1 = require("../permission-tree");
const types_1 = require("../../types");
const url_builder_1 = require("../../utils/url-builder");
const loading_spinner_utils_1 = require("../../utils/loading-spinner-utils");
const constants_1 = require("../../constants");
function ClusterPermissionPanel(props) {
    const noClusterPermissions = (react_1.default.createElement(eui_1.EuiEmptyPrompt, { title: react_1.default.createElement("h3", null, "No cluster permission"), titleSize: "s", actions: react_1.default.createElement(eui_1.EuiButton, { "data-test-subj": "addClusterPermission", disabled: props.isReserved, onClick: () => {
                window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.roles, types_1.Action.edit, props.roleName);
            } }, "Add cluster permission") }));
    const headerText = 'Cluster permissions';
    return (react_1.default.createElement(panel_with_header_1.PanelWithHeader, { headerText: headerText, headerSubText: "Cluster permissions specify how users in this role can access the cluster. You can\n      specify permissions using both action groups or single permissions. An action\n      group is a list of single permissions.", helpLink: constants_1.DocLinks.ClusterPermissionsDoc, count: props.clusterPermissions.length }, props.loading ? (react_1.default.createElement("div", { className: "text-center" }, loading_spinner_utils_1.loadingSpinner)) : props.clusterPermissions.length === 0 ? (noClusterPermissions) : (react_1.default.createElement(permission_tree_1.PermissionTree, { permissions: props.clusterPermissions, actionGroups: props.actionGroups }))));
}
exports.ClusterPermissionPanel = ClusterPermissionPanel;
