"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserList = exports.getColumns = exports.dictView = void 0;
const tslib_1 = require("tslib");
const eui_1 = require("@elastic/eui");
const lodash_1 = require("lodash");
const react_1 = tslib_1.__importStar(require("react"));
const auth_info_utils_1 = require("../../../utils/auth-info-utils");
const constants_1 = require("../constants");
const types_1 = require("../types");
const ui_constants_1 = require("../ui-constants");
const context_menu_1 = require("../utils/context-menu");
const delete_confirm_modal_utils_1 = require("../utils/delete-confirm-modal-utils");
const display_utils_1 = require("../utils/display-utils");
const internal_user_list_utils_1 = require("../utils/internal-user-list-utils");
const loading_spinner_utils_1 = require("../utils/loading-spinner-utils");
const url_builder_1 = require("../utils/url-builder");
function dictView(items) {
    if (lodash_1.isEmpty(items)) {
        return ui_constants_1.EMPTY_FIELD_VALUE;
    }
    return (react_1.default.createElement(eui_1.EuiFlexGroup, { direction: "column", style: { margin: '1px' } }, lodash_1.map(items, (v, k) => (react_1.default.createElement(eui_1.EuiText, { key: k, className: display_utils_1.tableItemsUIProps.cssClassName },
        k,
        ": ",
        `"${v}"`)))));
}
exports.dictView = dictView;
function getColumns(currentUsername) {
    return [
        {
            field: 'username',
            name: 'Username',
            render: (username) => (react_1.default.createElement(react_1.default.Fragment, null,
                react_1.default.createElement("a", { href: url_builder_1.buildHashUrl(types_1.ResourceType.users, types_1.Action.edit, username) }, username),
                username === currentUsername && (react_1.default.createElement(react_1.default.Fragment, null,
                    "\u00A0",
                    react_1.default.createElement(eui_1.EuiBadge, null, "Current"))))),
            sortable: true,
        },
        {
            field: 'attributes',
            name: 'Attributes',
            render: dictView,
            truncateText: true,
        },
    ];
}
exports.getColumns = getColumns;
function UserList(props) {
    const [userData, setUserData] = react_1.default.useState([]);
    const [errorFlag, setErrorFlag] = react_1.default.useState(false);
    const [selection, setSelection] = react_1.useState([]);
    const [currentUsername, setCurrentUsername] = react_1.useState('');
    const [loading, setLoading] = react_1.useState(false);
    const [query, setQuery] = react_1.useState('');
    react_1.default.useEffect(() => {
        const fetchData = async () => {
            try {
                setLoading(true);
                const userDataPromise = internal_user_list_utils_1.getUserList(props.coreStart.http);
                setCurrentUsername((await auth_info_utils_1.getAuthInfo(props.coreStart.http)).user_name);
                setUserData(await userDataPromise);
            }
            catch (e) {
                console.log(e);
                setErrorFlag(true);
            }
            finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [props.coreStart.http]);
    const handleDelete = async () => {
        const usersToDelete = selection.map((r) => r.username);
        try {
            await internal_user_list_utils_1.requestDeleteUsers(props.coreStart.http, usersToDelete);
            // Refresh from server (calling fetchData) does not work here, the server still return the users
            // that had been just deleted, probably because ES takes some time to sync to all nodes.
            // So here remove the selected users from local memory directly.
            setUserData(lodash_1.difference(userData, selection));
            setSelection([]);
        }
        catch (e) {
            console.log(e);
        }
        finally {
            closeActionsMenu();
        }
    };
    const [showDeleteConfirmModal, deleteConfirmModal] = delete_confirm_modal_utils_1.useDeleteConfirmState(handleDelete, 'user(s)');
    const actionsMenuItems = [
        react_1.default.createElement(eui_1.EuiButtonEmpty, { key: "edit", onClick: () => {
                window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.users, types_1.Action.edit, selection[0].username);
            }, disabled: selection.length !== 1 }, "Edit"),
        react_1.default.createElement(eui_1.EuiButtonEmpty, { key: "duplicate", onClick: () => {
                window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.users, types_1.Action.duplicate, selection[0].username);
            }, disabled: selection.length !== 1 }, "Duplicate"),
        react_1.default.createElement(eui_1.EuiButtonEmpty, { key: "export", disabled: selection.length !== 1, href: selection.length === 1
                ? `${props.coreStart.http.basePath.serverBasePath}${constants_1.API_ENDPOINT_INTERNALUSERS}/${selection[0].username}`
                : '', target: "_blank" }, "Export JSON"),
        react_1.default.createElement(eui_1.EuiButtonEmpty, { key: "delete", color: "danger", onClick: showDeleteConfirmModal, disabled: selection.length === 0 || selection.some((e) => e.username === currentUsername) }, "Delete"),
    ];
    const [actionsMenu, closeActionsMenu] = context_menu_1.useContextMenuState('Actions', {}, actionsMenuItems);
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement(eui_1.EuiPageHeader, null,
            react_1.default.createElement(eui_1.EuiTitle, { size: "l" },
                react_1.default.createElement("h1", null, "Internal users"))),
        react_1.default.createElement(eui_1.EuiPageContent, null,
            react_1.default.createElement(eui_1.EuiPageContentHeader, null,
                react_1.default.createElement(eui_1.EuiPageContentHeaderSection, null,
                    react_1.default.createElement(eui_1.EuiTitle, { size: "s" },
                        react_1.default.createElement("h3", null,
                            "Internal users",
                            react_1.default.createElement("span", { className: "panel-header-count" },
                                ' ',
                                "(",
                                eui_1.Query.execute(query, userData).length,
                                ")"))),
                    react_1.default.createElement(eui_1.EuiText, { size: "xs", color: "subdued" },
                        "The Security plugin includes an internal user database. Use this database in place of, or in addition to, an external authentication system such as LDAP server or Active Directory. You can map an internal user to a role from",
                        ' ',
                        react_1.default.createElement(eui_1.EuiLink, { href: url_builder_1.buildHashUrl(types_1.ResourceType.roles) }, "Roles"),
                        ". First, click into the detail page of the role. Then, under \u201CMapped users\u201D, click \u201CManage mapping\u201D ",
                        react_1.default.createElement(display_utils_1.ExternalLink, { href: constants_1.DocLinks.MapUsersToRolesDoc }))),
                react_1.default.createElement(eui_1.EuiPageContentHeaderSection, null,
                    react_1.default.createElement(eui_1.EuiFlexGroup, null,
                        react_1.default.createElement(eui_1.EuiFlexItem, null, actionsMenu),
                        react_1.default.createElement(eui_1.EuiFlexItem, null,
                            react_1.default.createElement(eui_1.EuiButton, { fill: true, href: url_builder_1.buildHashUrl(types_1.ResourceType.users, types_1.Action.create) }, "Create internal user"))))),
            react_1.default.createElement(eui_1.EuiPageBody, null,
                react_1.default.createElement(eui_1.EuiInMemoryTable, { tableLayout: 'auto', loading: userData === [] && !errorFlag, columns: getColumns(currentUsername), 
                    // @ts-ignore
                    items: userData, itemId: 'username', pagination: true, search: {
                        box: { placeholder: 'Search internal users' },
                        onChange: (arg) => {
                            setQuery(arg.queryText);
                            return true;
                        },
                    }, 
                    // @ts-ignore
                    selection: { onSelectionChange: setSelection }, sorting: true, error: errorFlag ? 'Load data failed, please check console log for more detail.' : '', message: loading_spinner_utils_1.showTableStatusMessage(loading, userData) })),
            deleteConfirmModal)));
}
exports.UserList = UserList;
