"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AttributePanel = exports.unbuildAttributeState = exports.buildAttributeState = void 0;
const tslib_1 = require("tslib");
const eui_1 = require("@elastic/eui");
const lodash_1 = require("lodash");
const react_1 = tslib_1.__importStar(require("react"));
const array_state_utils_1 = require("../../utils/array-state-utils");
const panel_with_header_1 = require("../../utils/panel-with-header");
const form_row_1 = require("../../utils/form-row");
const constants_1 = require("../../constants");
function buildAttributeState(attributesDict) {
    return lodash_1.map(attributesDict, (v, k) => ({
        key: k.toString(),
        value: v,
    }));
}
exports.buildAttributeState = buildAttributeState;
function unbuildAttributeState(attributesList) {
    return attributesList.reduce((attributes, { key, value }) => ({
        ...attributes,
        [key]: value,
    }), {});
}
exports.unbuildAttributeState = unbuildAttributeState;
function getEmptyAttribute() {
    return { key: '', value: '' };
}
function generateAttributesPanels(userAttributes, setAttributes) {
    const panels = userAttributes.map((userAttribute, arrayIndex) => {
        const onValueChangeHandler = (attributeToUpdate) => array_state_utils_1.updateElementInArrayHandler(setAttributes, [arrayIndex, attributeToUpdate]);
        return (react_1.default.createElement(react_1.Fragment, { key: `attributes-${arrayIndex}` },
            react_1.default.createElement(eui_1.EuiFlexGroup, null,
                react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                    react_1.default.createElement(form_row_1.FormRow, { headerText: arrayIndex === 0 ? 'Variable name' : '' },
                        react_1.default.createElement(eui_1.EuiFieldText, { id: `attribute-${arrayIndex}`, value: userAttribute.key, onChange: (e) => onValueChangeHandler('key')(e.target.value), placeholder: "Type in variable name" }))),
                react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                    react_1.default.createElement(form_row_1.FormRow, { headerText: arrayIndex === 0 ? 'Value' : '' },
                        react_1.default.createElement(eui_1.EuiFieldText, { id: `value-${arrayIndex}`, value: userAttribute.value, onChange: (e) => onValueChangeHandler('value')(e.target.value), placeholder: "Type in value" }))),
                react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                    react_1.default.createElement(eui_1.EuiFormRow, { hasEmptyLabelSpace: arrayIndex === 0 ? true : false },
                        react_1.default.createElement(eui_1.EuiButton, { id: `delete-${arrayIndex}`, color: "danger", onClick: () => array_state_utils_1.removeElementFromArray(setAttributes, [], arrayIndex) }, "Remove"))))));
    });
    return react_1.default.createElement(react_1.default.Fragment, null, panels);
}
function AttributePanel(props) {
    const { state, setState } = props;
    // Show one empty row if there is no data.
    if (lodash_1.isEmpty(state)) {
        setState([getEmptyAttribute()]);
    }
    return (react_1.default.createElement(panel_with_header_1.PanelWithHeader, { headerText: "Attributes", headerSubText: "Attributes can be used to further describe the user, and, more importantly they can be used as \n      variables in the Document Level Security query in the index permission of a role. This makes it possible to \n      write dynamic DLS queries based on a user's attributes.", helpLink: constants_1.DocLinks.AttributeBasedSecurityDoc, optional: true },
        generateAttributesPanels(state, setState),
        react_1.default.createElement(eui_1.EuiSpacer, null),
        react_1.default.createElement(eui_1.EuiButton, { id: "add-row", onClick: () => {
                array_state_utils_1.appendElementToArray(setState, [], getEmptyAttribute());
            } }, "Add another attribute")));
}
exports.AttributePanel = AttributePanel;
