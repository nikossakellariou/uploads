"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.InternalUserEdit = void 0;
const tslib_1 = require("tslib");
const eui_1 = require("@elastic/eui");
const react_1 = tslib_1.__importStar(require("react"));
const types_1 = require("../../types");
const internal_user_detail_utils_1 = require("../../utils/internal-user-detail-utils");
const panel_with_header_1 = require("../../utils/panel-with-header");
const password_edit_panel_1 = require("../../utils/password-edit-panel");
const toast_utils_1 = require("../../utils/toast-utils");
const url_builder_1 = require("../../utils/url-builder");
const attribute_panel_1 = require("./attribute-panel");
const storage_utils_1 = require("../../utils/storage-utils");
const display_utils_1 = require("../../utils/display-utils");
const resource_utils_1 = require("../../utils/resource-utils");
const name_row_1 = require("../../utils/name-row");
const constants_1 = require("../../constants");
const TITLE_TEXT_DICT = {
    create: 'Create internal user',
    edit: 'Edit internal user',
    duplicate: 'Duplicate internal user',
};
function InternalUserEdit(props) {
    const [userName, setUserName] = react_1.useState('');
    const [password, setPassword] = react_1.useState('');
    const [isPasswordInvalid, setIsPasswordInvalid] = react_1.default.useState(false);
    const [attributes, setAttributes] = react_1.useState([]);
    const [backendRoles, setBackendRoles] = react_1.useState([]);
    const [toasts, addToast, removeToast] = toast_utils_1.useToastState();
    const [isFormValid, setIsFormValid] = react_1.useState(true);
    react_1.default.useEffect(() => {
        const action = props.action;
        if (action === 'edit' || action === 'duplicate') {
            const fetchData = async () => {
                try {
                    const user = await internal_user_detail_utils_1.getUserDetail(props.coreStart.http, props.sourceUserName);
                    setAttributes(attribute_panel_1.buildAttributeState(user.attributes));
                    setBackendRoles(user.backend_roles);
                    setUserName(resource_utils_1.generateResourceName(action, props.sourceUserName));
                }
                catch (e) {
                    addToast(toast_utils_1.createUnknownErrorToast('fetchUser', 'load data'));
                    console.error(e);
                }
            };
            fetchData();
        }
    }, [addToast, props.action, props.coreStart.http, props.sourceUserName]);
    const updateUserHandler = async () => {
        try {
            if (isPasswordInvalid) {
                addToast(toast_utils_1.createErrorToast('passwordInvalid', 'Update error', 'Password does not match.'));
                return;
            }
            // Remove attributes with empty key
            const validAttributes = attributes.filter((v) => v.key !== '');
            const updateObject = {
                password,
                backend_roles: backendRoles,
                attributes: attribute_panel_1.unbuildAttributeState(validAttributes),
            };
            await internal_user_detail_utils_1.updateUser(props.coreStart.http, userName, updateObject);
            storage_utils_1.setCrossPageToast(url_builder_1.buildUrl(types_1.ResourceType.users), {
                id: 'updateUserSucceeded',
                color: 'success',
                title: toast_utils_1.getSuccessToastMessage('User', props.action, userName),
            });
            // Redirect to user listing
            window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.users);
        }
        catch (e) {
            if (e.message) {
                addToast(toast_utils_1.createErrorToast('updateUserFailed', 'Update error', e.message));
            }
            else {
                addToast(toast_utils_1.createUnknownErrorToast('updateUserFailed', `${props.action} user`));
                console.error(e);
            }
        }
    };
    return (react_1.default.createElement(react_1.default.Fragment, null,
        props.buildBreadcrumbs(TITLE_TEXT_DICT[props.action]),
        react_1.default.createElement(eui_1.EuiSpacer, null),
        react_1.default.createElement(eui_1.EuiPageHeader, null,
            react_1.default.createElement(eui_1.EuiFlexGroup, { direction: "column", gutterSize: "xs" },
                react_1.default.createElement(eui_1.EuiFlexItem, null,
                    react_1.default.createElement(eui_1.EuiTitle, { size: "l" },
                        react_1.default.createElement("h1", null, TITLE_TEXT_DICT[props.action]))),
                react_1.default.createElement(eui_1.EuiFlexItem, null,
                    react_1.default.createElement(eui_1.EuiText, { size: "xs", color: "subdued" },
                        "The security plugin includes an internal user database. Use this database in place of, or in addition to, an external authentication system such as LDAP or Active Directory.",
                        ' ',
                        react_1.default.createElement(display_utils_1.ExternalLink, { href: constants_1.DocLinks.UsersAndRolesDoc }))))),
        react_1.default.createElement(panel_with_header_1.PanelWithHeader, { headerText: "Credentials" },
            react_1.default.createElement(eui_1.EuiForm, null,
                react_1.default.createElement(name_row_1.NameRow, { headerText: "Username", headerSubText: "Specify a descriptive and unique user name. You cannot edit the name once the user is created.", resourceName: userName, resourceType: "user", action: props.action, setNameState: setUserName, setIsFormValid: setIsFormValid }),
                react_1.default.createElement(password_edit_panel_1.PasswordEditPanel, { updatePassword: setPassword, updateIsInvalid: setIsPasswordInvalid }))),
        react_1.default.createElement(eui_1.EuiSpacer, { size: "m" }),
        react_1.default.createElement(attribute_panel_1.AttributePanel, { state: attributes, setState: setAttributes }),
        react_1.default.createElement(eui_1.EuiSpacer, { size: "m" }),
        react_1.default.createElement(eui_1.EuiFlexGroup, { justifyContent: "flexEnd" },
            react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                react_1.default.createElement(eui_1.EuiButton, { onClick: () => {
                        window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.users);
                    } }, "Cancel")),
            react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                react_1.default.createElement(eui_1.EuiButton, { id: "submit", fill: true, onClick: updateUserHandler, disabled: !isFormValid }, props.action === 'edit' ? 'Save changes' : 'Create'))),
        react_1.default.createElement(eui_1.EuiGlobalToastList, { toasts: toasts, toastLifeTimeMs: 10000, dismissToast: removeToast })));
}
exports.InternalUserEdit = InternalUserEdit;
