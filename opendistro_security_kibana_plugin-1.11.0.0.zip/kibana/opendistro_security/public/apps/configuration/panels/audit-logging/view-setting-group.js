"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ViewSettingGroup = void 0;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importStar(require("react"));
const lodash_1 = require("lodash");
const eui_1 = require("@elastic/eui");
const display_utils_1 = require("../../utils/display-utils");
function ViewSettingGroup(props) {
    const renderField = (config, setting) => {
        let val = lodash_1.get(config, setting.path);
        if (setting.type === 'bool') {
            val = val || false;
            // @ts-ignore
            return display_utils_1.renderTextFlexItem(setting.title, display_utils_1.displayBoolean(val));
        }
        else if (setting.type === 'array') {
            val = val || [];
            // @ts-ignore
            return display_utils_1.renderTextFlexItem(setting.title, display_utils_1.displayArray(val));
        }
        else if (setting.type === 'map') {
            val = val || {};
            // @ts-ignore
            return display_utils_1.renderTextFlexItem(setting.title, display_utils_1.displayObject(val));
        }
        else {
            return react_1.default.createElement(react_1.default.Fragment, null);
        }
    };
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement(eui_1.EuiText, null,
            react_1.default.createElement("h3", null, props.settingGroup.title)),
        react_1.default.createElement(eui_1.EuiSpacer, null),
        react_1.default.createElement(eui_1.EuiFlexGrid, { columns: 3 }, props.settingGroup.settings.map((setting) => {
            return react_1.default.createElement(react_1.Fragment, { key: setting.title }, renderField(props.config, setting));
        }))));
}
exports.ViewSettingGroup = ViewSettingGroup;
