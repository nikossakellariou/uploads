"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditLoggingEditSettings = void 0;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importDefault(require("react"));
const eui_1 = require("@elastic/eui");
const lodash_1 = require("lodash");
const constants_1 = require("./constants");
const edit_setting_group_1 = require("./edit-setting-group");
const url_builder_1 = require("../../utils/url-builder");
const types_1 = require("../../types");
const audit_logging_utils_1 = require("../../utils/audit-logging-utils");
const toast_utils_1 = require("../../utils/toast-utils");
const storage_utils_1 = require("../../utils/storage-utils");
function AuditLoggingEditSettings(props) {
    const [editConfig, setEditConfig] = react_1.default.useState({});
    const [toasts, addToast, removeToast] = toast_utils_1.useToastState();
    const [invalidSettings, setInvalidSettings] = react_1.default.useState([]);
    const handleChange = (path, val) => {
        setEditConfig((previousEditedConfig) => {
            return lodash_1.set(lodash_1.cloneDeep(editConfig), path, val);
        });
    };
    const handleInvalid = (path, error) => {
        const invalid = lodash_1.without(invalidSettings, path);
        if (error) {
            invalid.push(path);
        }
        setInvalidSettings(invalid);
    };
    react_1.default.useEffect(() => {
        const fetchConfig = async () => {
            try {
                const fetchedConfig = await audit_logging_utils_1.getAuditLogging(props.coreStart.http);
                setEditConfig(fetchedConfig);
            }
            catch (e) {
                console.log(e);
            }
        };
        fetchConfig();
    }, [props.coreStart.http]);
    const renderSaveAndCancel = () => {
        return (react_1.default.createElement(react_1.default.Fragment, null,
            react_1.default.createElement(eui_1.EuiFlexGroup, { justifyContent: "flexEnd" },
                react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                    react_1.default.createElement(eui_1.EuiButton, { onClick: () => {
                            window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.auditLogging);
                        } }, "Cancel")),
                react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                    react_1.default.createElement(eui_1.EuiButton, { fill: true, isDisabled: invalidSettings.length !== 0, onClick: () => {
                            saveConfig(editConfig);
                        } }, "Save")))));
    };
    const saveConfig = async (configToUpdate) => {
        try {
            await audit_logging_utils_1.updateAuditLogging(props.coreStart.http, configToUpdate);
            const addSuccessToast = (text) => {
                const successToast = {
                    id: 'update-result',
                    color: 'success',
                    iconType: 'check',
                    title: 'Success',
                    text,
                };
                storage_utils_1.setCrossPageToast(url_builder_1.buildUrl(types_1.ResourceType.auditLogging), successToast);
            };
            if (props.setting === 'general') {
                addSuccessToast('General settings saved');
            }
            else {
                addSuccessToast('Compliance settings saved');
            }
            window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.auditLogging);
        }
        catch (e) {
            const failureToast = {
                id: 'update-result',
                color: 'danger',
                iconType: 'alert',
                title: 'Failed to update audit configuration due to ' + e?.message,
            };
            addToast(failureToast);
        }
        finally {
            window.scrollTo({ top: 0 });
        }
    };
    const renderComplianceSetting = () => {
        return (react_1.default.createElement(react_1.default.Fragment, null,
            react_1.default.createElement(eui_1.EuiPageHeader, null,
                react_1.default.createElement(eui_1.EuiTitle, { size: "l" },
                    react_1.default.createElement("h1", null, "Compliance settings"))),
            react_1.default.createElement(eui_1.EuiPanel, null,
                react_1.default.createElement(edit_setting_group_1.EditSettingGroup, { settingGroup: constants_1.SETTING_GROUPS.COMPLIANCE_CONFIG_MODE_SETTINGS, config: editConfig, handleChange: handleChange }),
                editConfig.compliance && editConfig.compliance.enabled && (react_1.default.createElement(react_1.default.Fragment, null,
                    react_1.default.createElement(edit_setting_group_1.EditSettingGroup, { settingGroup: constants_1.SETTING_GROUPS.COMPLIANCE_CONFIG_SETTINGS, config: editConfig, handleChange: handleChange }),
                    react_1.default.createElement(eui_1.EuiSpacer, null),
                    react_1.default.createElement(edit_setting_group_1.EditSettingGroup, { settingGroup: constants_1.SETTING_GROUPS.COMPLIANCE_SETTINGS_READ, config: editConfig, handleChange: handleChange, handleInvalid: handleInvalid }),
                    react_1.default.createElement(eui_1.EuiSpacer, null),
                    react_1.default.createElement(edit_setting_group_1.EditSettingGroup, { settingGroup: constants_1.SETTING_GROUPS.COMPLIANCE_SETTINGS_WRITE, config: editConfig, handleChange: handleChange })))),
            react_1.default.createElement(eui_1.EuiSpacer, null),
            renderSaveAndCancel(),
            react_1.default.createElement(eui_1.EuiGlobalToastList, { toasts: toasts, toastLifeTimeMs: 10000, dismissToast: removeToast })));
    };
    const renderGeneralSettings = () => {
        return (react_1.default.createElement(react_1.default.Fragment, null,
            react_1.default.createElement(eui_1.EuiPageHeader, null,
                react_1.default.createElement(eui_1.EuiTitle, { size: "l" },
                    react_1.default.createElement("h1", null, "General settings"))),
            react_1.default.createElement(eui_1.EuiPanel, null,
                react_1.default.createElement(edit_setting_group_1.EditSettingGroup, { settingGroup: constants_1.SETTING_GROUPS.LAYER_SETTINGS, config: editConfig, handleChange: handleChange }),
                react_1.default.createElement(eui_1.EuiSpacer, { size: "xl" }),
                react_1.default.createElement(edit_setting_group_1.EditSettingGroup, { settingGroup: constants_1.SETTING_GROUPS.ATTRIBUTE_SETTINGS, config: editConfig, handleChange: handleChange }),
                react_1.default.createElement(eui_1.EuiSpacer, { size: "xl" }),
                react_1.default.createElement(edit_setting_group_1.EditSettingGroup, { settingGroup: constants_1.SETTING_GROUPS.IGNORE_SETTINGS, config: editConfig, handleChange: handleChange })),
            react_1.default.createElement(eui_1.EuiSpacer, null),
            renderSaveAndCancel(),
            react_1.default.createElement(eui_1.EuiGlobalToastList, { toasts: toasts, toastLifeTimeMs: 10000, dismissToast: removeToast })));
    };
    let content;
    if (props.setting === 'general') {
        content = renderGeneralSettings();
    }
    else {
        content = renderComplianceSetting();
    }
    return react_1.default.createElement("div", { className: "panel-restrict-width" }, content);
}
exports.AuditLoggingEditSettings = AuditLoggingEditSettings;
