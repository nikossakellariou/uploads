"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUB_URL_FOR_COMPLIANCE_SETTINGS_EDIT = exports.SUB_URL_FOR_GENERAL_SETTINGS_EDIT = exports.SETTING_GROUPS = exports.COMPLIANCE_SETTINGS_WRITE = exports.COMPLIANCE_SETTINGS_READ = exports.COMPLIANCE_CONFIG_SETTINGS = exports.COMPLIANCE_CONFIG_MODE_SETTINGS = exports.IGNORE_SETTINGS = exports.ATTRIBUTE_SETTINGS = exports.LAYER_SETTINGS = exports.CONFIG = exports.excludeFromDisabledTransportCategories = exports.excludeFromDisabledRestCategories = exports.RESPONSE_MESSAGES = exports.CONFIG_LABELS = void 0;
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
const lodash_1 = require("lodash");
exports.CONFIG_LABELS = {
    AUDIT_LOGGING: 'Audit logging',
    GENERAL_SETTINGS: 'General settings',
    LAYER_SETTINGS: 'Layer settings',
    ATTRIBUTE_SETTINGS: 'Attribute settings',
    IGNORE_SETTINGS: 'Ignore settings',
    COMPLIANCE_SETTINGS: 'Compliance settings',
    COMPLIANCE_MODE: 'Compliance mode',
    COMPLIANCE_CONFIG_SETTINGS: 'Config',
    COMPLIANCE_READ: 'Read',
    COMPLIANCE_WRITE: 'Write',
};
exports.RESPONSE_MESSAGES = {
    FETCH_ERROR_TITLE: 'Sorry, there was an error fetching audit configuration.',
    FETCH_ERROR_MESSAGE: 'Please ensure hot reloading of audit configuration is enabled in the security plugin.',
    UPDATE_SUCCESS: 'Audit configuration was successfully updated.',
    UPDATE_FAILURE: 'Audit configuration could not be updated. Please check configuration.',
};
const REST_LAYER = {
    title: 'REST layer',
    path: 'audit.enable_rest',
    description: 'Enable or disable auditing events that happen on the REST layer.',
    type: 'bool',
};
const REST_DISABLED_CATEGORIES = {
    title: 'REST disabled categories',
    path: 'audit.disabled_rest_categories',
    description: 'Specify audit categories which must be ignored on the REST layer. Modifying these could result in ' +
        'significant overhead.',
    type: 'array',
    options: [
        'BAD_HEADERS',
        'FAILED_LOGIN',
        'MISSING_PRIVILEGES',
        'GRANTED_PRIVILEGES',
        'SSL_EXCEPTION',
        'AUTHENTICATED',
    ],
    placeHolder: 'Select categories',
};
function excludeFromDisabledRestCategories(optionsToExclude) {
    lodash_1.pullAll(REST_DISABLED_CATEGORIES.options || [], optionsToExclude);
}
exports.excludeFromDisabledRestCategories = excludeFromDisabledRestCategories;
const TRANSPORT_LAYER = {
    title: 'Transport layer',
    path: 'audit.enable_transport',
    description: 'Enable or disable auditing events that happen on the transport layer.',
    type: 'bool',
};
const TRANSPORT_DISABLED_CATEGORIES = {
    title: 'Transport disabled categories',
    path: 'audit.disabled_transport_categories',
    description: 'Specify audit categories which must be ignored on the transport layer. Modifying these could result ' +
        'in significant overhead.',
    type: 'array',
    options: [
        'BAD_HEADERS',
        'FAILED_LOGIN',
        'GRANTED_PRIVILEGES',
        'INDEX_EVENT',
        'MISSING_PRIVILEGES',
        'SSL_EXCEPTION',
        'OPENDISTRO_SECURITY_INDEX_ATTEMPT',
        'AUTHENTICATED',
    ],
    placeHolder: 'Select categories',
};
function excludeFromDisabledTransportCategories(optionsToExclude) {
    lodash_1.pullAll(TRANSPORT_DISABLED_CATEGORIES.options || [], optionsToExclude);
}
exports.excludeFromDisabledTransportCategories = excludeFromDisabledTransportCategories;
const BULK_REQUESTS = {
    title: 'Bulk requests',
    path: 'audit.resolve_bulk_requests',
    description: 'Resolve bulk requests during auditing of requests. Enabling this will generate a log for each ' +
        'document request which could result in significant overhead.',
    type: 'bool',
};
const REQUEST_BODY = {
    title: 'Request body',
    path: 'audit.log_request_body',
    description: 'Include request body during auditing of requests.',
    type: 'bool',
};
const RESOLVE_INDICES = {
    title: 'Resolve indices',
    path: 'audit.resolve_indices',
    description: 'Resolve indices during auditing of requests.',
    type: 'bool',
};
const SENSITIVE_HEADERS = {
    title: 'Sensitive headers',
    path: 'audit.exclude_sensitive_headers',
    description: 'Exclude sensitive headers during auditing. (e.g. authorization header)',
    type: 'bool',
};
const IGNORED_USERS = {
    title: 'Ignored users',
    path: 'audit.ignore_users',
    description: 'Users to ignore during auditing. Changing the defaults could result in significant overhead.',
    type: 'array',
    placeHolder: 'Add users or user patterns',
};
const IGNORED_REQUESTS = {
    title: 'Ignored requests',
    path: 'audit.ignore_requests',
    description: 'Request patterns to ignore during auditing.',
    type: 'array',
    placeHolder: 'Add request patterns',
};
const ENABLED = {
    title: 'Compliance logging',
    path: 'compliance.enabled',
    description: 'Enable or disable compliance logging.',
    type: 'bool',
};
const INTERNAL_CONFIG = {
    title: 'Internal config logging',
    path: 'compliance.internal_config',
    description: 'Enable or disable logging of events on internal security index.',
    type: 'bool',
};
const EXTERNAL_CONFIG = {
    title: 'External config logging',
    path: 'compliance.external_config',
    description: 'Enable or disable logging of external configuration.',
    type: 'bool',
};
const READ_METADATA_ONLY = {
    title: 'Read metadata',
    path: 'compliance.read_metadata_only',
    description: 'Do not log any document fields. Log only metadata of the document.',
    type: 'bool',
};
const READ_IGNORED_USERS = {
    title: 'Ignored users',
    path: 'compliance.read_ignore_users',
    description: 'Users to ignore during auditing.',
    type: 'array',
    placeHolder: 'Add users or user patterns',
};
const READ_WATCHED_FIELDS = {
    title: 'Watched fields',
    path: 'compliance.read_watched_fields',
    description: 'List the indices and fields to watch during read events. Adding watched fields will generate one log per document' +
        ' access and could result in significant overhead. Sample data content:',
    type: 'map',
    code: `{
  "index-name-pattern": ["field-name-pattern"],
  "logs*": ["message"],
  "twitter": ["id", "user*"]
}`,
    error: 'Invalid content. Please check sample data content.',
};
const WRITE_METADATA_ONLY = {
    title: 'Write metadata',
    path: 'compliance.write_metadata_only',
    description: 'Do not log any document content. Log only metadata of the document.',
    type: 'bool',
};
const WRITE_LOG_DIFFS = {
    title: 'Log diffs',
    path: 'compliance.write_log_diffs',
    description: '',
    type: 'bool',
};
const WRITE_IGNORED_USERS = {
    title: 'Ignored users',
    path: 'compliance.write_ignore_users',
    description: 'Users to ignore during auditing.',
    type: 'array',
    placeHolder: 'Add users or user patterns',
};
const WRITE_WATCHED_FIELDS = {
    title: 'Watch indices',
    path: 'compliance.write_watched_indices',
    description: 'List the indices to watch during write events. Adding watched indices will generate one log per ' +
        'document access and could result in significant overhead.',
    type: 'array',
    placeHolder: 'Add indices',
};
exports.CONFIG = {
    ENABLED: {
        title: 'Enable audit logging',
        path: 'enabled',
        description: 'Enable or disable audit logging',
        type: 'bool',
    },
    AUDIT: {
        REST_LAYER,
        REST_DISABLED_CATEGORIES,
        TRANSPORT_LAYER,
        TRANSPORT_DISABLED_CATEGORIES,
        BULK_REQUESTS,
        REQUEST_BODY,
        RESOLVE_INDICES,
        SENSITIVE_HEADERS,
        IGNORED_USERS,
        IGNORED_REQUESTS,
    },
    COMPLIANCE: {
        ENABLED,
        INTERNAL_CONFIG,
        EXTERNAL_CONFIG,
        READ_METADATA_ONLY,
        READ_IGNORED_USERS,
        READ_WATCHED_FIELDS,
        WRITE_METADATA_ONLY,
        WRITE_LOG_DIFFS,
        WRITE_IGNORED_USERS,
        WRITE_WATCHED_FIELDS,
    },
};
exports.LAYER_SETTINGS = {
    title: exports.CONFIG_LABELS.LAYER_SETTINGS,
    settings: [
        exports.CONFIG.AUDIT.REST_LAYER,
        exports.CONFIG.AUDIT.REST_DISABLED_CATEGORIES,
        exports.CONFIG.AUDIT.TRANSPORT_LAYER,
        exports.CONFIG.AUDIT.TRANSPORT_DISABLED_CATEGORIES,
    ],
};
exports.ATTRIBUTE_SETTINGS = {
    title: exports.CONFIG_LABELS.ATTRIBUTE_SETTINGS,
    settings: [
        exports.CONFIG.AUDIT.BULK_REQUESTS,
        exports.CONFIG.AUDIT.REQUEST_BODY,
        exports.CONFIG.AUDIT.RESOLVE_INDICES,
        exports.CONFIG.AUDIT.SENSITIVE_HEADERS,
    ],
};
exports.IGNORE_SETTINGS = {
    title: exports.CONFIG_LABELS.IGNORE_SETTINGS,
    settings: [exports.CONFIG.AUDIT.IGNORED_USERS, exports.CONFIG.AUDIT.IGNORED_REQUESTS],
};
exports.COMPLIANCE_CONFIG_MODE_SETTINGS = {
    title: exports.CONFIG_LABELS.COMPLIANCE_MODE,
    settings: [exports.CONFIG.COMPLIANCE.ENABLED],
};
exports.COMPLIANCE_CONFIG_SETTINGS = {
    title: exports.CONFIG_LABELS.COMPLIANCE_CONFIG_SETTINGS,
    settings: [exports.CONFIG.COMPLIANCE.INTERNAL_CONFIG, exports.CONFIG.COMPLIANCE.EXTERNAL_CONFIG],
};
exports.COMPLIANCE_SETTINGS_READ = {
    title: exports.CONFIG_LABELS.COMPLIANCE_READ,
    settings: [
        exports.CONFIG.COMPLIANCE.READ_METADATA_ONLY,
        exports.CONFIG.COMPLIANCE.READ_IGNORED_USERS,
        exports.CONFIG.COMPLIANCE.READ_WATCHED_FIELDS,
    ],
};
exports.COMPLIANCE_SETTINGS_WRITE = {
    title: exports.CONFIG_LABELS.COMPLIANCE_WRITE,
    settings: [
        exports.CONFIG.COMPLIANCE.WRITE_METADATA_ONLY,
        exports.CONFIG.COMPLIANCE.WRITE_LOG_DIFFS,
        exports.CONFIG.COMPLIANCE.WRITE_IGNORED_USERS,
        exports.CONFIG.COMPLIANCE.WRITE_WATCHED_FIELDS,
    ],
};
exports.SETTING_GROUPS = {
    AUDIT_SETTINGS: {
        settings: [exports.CONFIG.ENABLED],
    },
    LAYER_SETTINGS: exports.LAYER_SETTINGS,
    ATTRIBUTE_SETTINGS: exports.ATTRIBUTE_SETTINGS,
    IGNORE_SETTINGS: exports.IGNORE_SETTINGS,
    COMPLIANCE_CONFIG_MODE_SETTINGS: exports.COMPLIANCE_CONFIG_MODE_SETTINGS,
    COMPLIANCE_CONFIG_SETTINGS: exports.COMPLIANCE_CONFIG_SETTINGS,
    COMPLIANCE_SETTINGS_READ: exports.COMPLIANCE_SETTINGS_READ,
    COMPLIANCE_SETTINGS_WRITE: exports.COMPLIANCE_SETTINGS_WRITE,
};
exports.SUB_URL_FOR_GENERAL_SETTINGS_EDIT = '/edit/generalSettings';
exports.SUB_URL_FOR_COMPLIANCE_SETTINGS_EDIT = '/edit/complianceSettings';
