"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EditSettingGroup = void 0;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importStar(require("react"));
const eui_1 = require("@elastic/eui");
const lodash_1 = require("lodash");
const display_utils_1 = require("../../utils/display-utils");
const combo_box_utils_1 = require("../../utils/combo-box-utils");
const code_editor_1 = require("./code-editor");
require("./_index.scss");
const renderCodeBlock = (setting) => {
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement(eui_1.EuiCodeBlock, { paddingSize: "none", isCopyable: true }, setting.code)));
};
const displayLabel = (val) => {
    return val.replace(/\./g, ':');
};
function EditSettingGroup(props) {
    const renderField = (config, setting, handleChange, handleInvalid) => {
        let val = lodash_1.get(config, setting.path);
        if (setting.type === 'bool') {
            val = val || false;
            return (react_1.default.createElement(eui_1.EuiSwitch
            // @ts-ignore
            , { 
                // @ts-ignore
                label: display_utils_1.displayBoolean(val), 
                // @ts-ignore
                checked: val, onChange: (e) => {
                    handleChange(setting.path, e.target.checked);
                } }));
        }
        else if (setting.type === 'array' && typeof setting.options !== 'undefined') {
            val = val || [];
            return (react_1.default.createElement(eui_1.EuiComboBox, { placeholder: setting.title, options: setting.options.map(combo_box_utils_1.stringToComboBoxOption), 
                // @ts-ignore
                selectedOptions: val.map(combo_box_utils_1.stringToComboBoxOption), onChange: (selectedOptions) => {
                    handleChange(setting.path, selectedOptions.map(combo_box_utils_1.comboBoxOptionToString));
                } }));
        }
        else if (setting.type === 'array') {
            val = val || [];
            return (react_1.default.createElement(eui_1.EuiComboBox, { noSuggestions: true, placeholder: setting.title, 
                // @ts-ignore
                selectedOptions: val.map(combo_box_utils_1.stringToComboBoxOption), onChange: (selectedOptions) => {
                    // @ts-ignore
                    handleChange(setting.path, selectedOptions.map(combo_box_utils_1.comboBoxOptionToString));
                }, onCreateOption: (searchValue) => {
                    // @ts-ignore
                    handleChange(setting.path, [...val, searchValue]);
                } }));
        }
        else if (setting.type === 'map') {
            const handleCodeChange = (newVal) => {
                const updated = JSON.parse(newVal);
                handleChange(setting.path, updated);
            };
            const handleCodeInvalid = (error) => {
                // @ts-ignore
                handleInvalid(setting.path, error);
            };
            const codeMap = lodash_1.get(config, setting.path);
            let codeString;
            if (lodash_1.isEmpty(codeMap)) {
                codeString = '{}';
            }
            else {
                // @ts-ignore
                codeString = display_utils_1.displayObject(codeMap);
            }
            return (react_1.default.createElement(code_editor_1.JsonCodeEditor
            // @ts-ignore
            , { 
                // @ts-ignore
                initialValue: codeString, 
                // @ts-ignore
                errorMessage: setting.error, handleCodeChange: handleCodeChange, handleCodeInvalid: handleCodeInvalid }));
        }
        else {
            return react_1.default.createElement(react_1.default.Fragment, null);
        }
    };
    const settingGroup = props.settingGroup;
    return (react_1.default.createElement(react_1.default.Fragment, null,
        settingGroup.title && (react_1.default.createElement(react_1.default.Fragment, null,
            react_1.default.createElement(eui_1.EuiTitle, null,
                react_1.default.createElement("h3", null, settingGroup.title)),
            react_1.default.createElement(eui_1.EuiSpacer, null))),
        settingGroup.settings.map((setting) => {
            return (react_1.default.createElement(react_1.Fragment, { key: setting.path },
                react_1.default.createElement(eui_1.EuiDescribedFormGroup, { title: react_1.default.createElement("h3", null, setting.title), description: react_1.default.createElement("div", { style: { maxWidth: '450px' } },
                        setting.description,
                        setting.code && renderCodeBlock(setting)), fullWidth: true },
                    react_1.default.createElement(eui_1.EuiFormRow, { label: displayLabel(setting.path) }, renderField(props.config, setting, props.handleChange, props.handleInvalid)))));
        })));
}
exports.EditSettingGroup = EditSettingGroup;
