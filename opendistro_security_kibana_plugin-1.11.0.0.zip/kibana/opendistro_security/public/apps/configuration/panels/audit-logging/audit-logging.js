"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditLogging = void 0;
const tslib_1 = require("tslib");
const eui_1 = require("@elastic/eui");
const react_1 = tslib_1.__importDefault(require("react"));
const react_2 = require("@kbn/i18n/react");
const types_1 = require("../../types");
const audit_logging_utils_1 = require("../../utils/audit-logging-utils");
const display_utils_1 = require("../../utils/display-utils");
const url_builder_1 = require("../../utils/url-builder");
const constants_1 = require("./constants");
const view_setting_group_1 = require("./view-setting-group");
const constants_2 = require("../../constants");
function renderStatusPanel(onSwitchChange, auditLoggingEnabled) {
    return (react_1.default.createElement(eui_1.EuiPanel, null,
        react_1.default.createElement(eui_1.EuiTitle, null,
            react_1.default.createElement("h3", null, "Audit logging")),
        react_1.default.createElement(eui_1.EuiHorizontalRule, { margin: "m" }),
        react_1.default.createElement(eui_1.EuiForm, null,
            react_1.default.createElement(eui_1.EuiDescribedFormGroup, { title: react_1.default.createElement("h3", null, "Storage location"), className: "described-form-group" },
                react_1.default.createElement(eui_1.EuiFormRow, { className: "form-row" },
                    react_1.default.createElement(eui_1.EuiText, { color: "subdued", grow: false },
                        react_1.default.createElement(react_2.FormattedMessage, { id: "audit.logs.storageInstruction", defaultMessage: "Configure the output location and storage types in {elasticsearchCode}. The default storage location is {internalElasticsearchCode}, which stores the logs in an index on this cluster.", values: {
                                elasticsearchCode: react_1.default.createElement(eui_1.EuiCode, null, "elasticsearch.yml"),
                                internalElasticsearchCode: react_1.default.createElement(eui_1.EuiCode, null, "internal_elasticsearch"),
                            } }),
                        ' ',
                        react_1.default.createElement(display_utils_1.ExternalLink, { href: constants_2.DocLinks.AuditLogsStorageDoc })))),
            react_1.default.createElement(eui_1.EuiDescribedFormGroup, { title: react_1.default.createElement("h3", null, "Enable audit logging"), className: "described-form-group" },
                react_1.default.createElement(eui_1.EuiFormRow, null,
                    react_1.default.createElement(eui_1.EuiSwitch, { name: "auditLoggingEnabledSwitch", label: display_utils_1.displayBoolean(auditLoggingEnabled), checked: auditLoggingEnabled, onChange: onSwitchChange }))))));
}
function renderGeneralSettings(config) {
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement(view_setting_group_1.ViewSettingGroup, { config: config, settingGroup: constants_1.SETTING_GROUPS.LAYER_SETTINGS }),
        react_1.default.createElement(eui_1.EuiSpacer, null),
        react_1.default.createElement(view_setting_group_1.ViewSettingGroup, { config: config, settingGroup: constants_1.SETTING_GROUPS.ATTRIBUTE_SETTINGS }),
        react_1.default.createElement(eui_1.EuiSpacer, null),
        react_1.default.createElement(view_setting_group_1.ViewSettingGroup, { config: config, settingGroup: constants_1.SETTING_GROUPS.IGNORE_SETTINGS })));
}
function renderComplianceSettings(config) {
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement(view_setting_group_1.ViewSettingGroup, { config: config, settingGroup: constants_1.SETTING_GROUPS.COMPLIANCE_CONFIG_MODE_SETTINGS }),
        react_1.default.createElement(eui_1.EuiSpacer, null),
        react_1.default.createElement(view_setting_group_1.ViewSettingGroup, { config: config, settingGroup: constants_1.SETTING_GROUPS.COMPLIANCE_CONFIG_SETTINGS }),
        react_1.default.createElement(eui_1.EuiSpacer, null),
        react_1.default.createElement(view_setting_group_1.ViewSettingGroup, { config: config, settingGroup: constants_1.SETTING_GROUPS.COMPLIANCE_SETTINGS_READ }),
        react_1.default.createElement(eui_1.EuiSpacer, null),
        react_1.default.createElement(view_setting_group_1.ViewSettingGroup, { config: config, settingGroup: constants_1.SETTING_GROUPS.COMPLIANCE_SETTINGS_WRITE }),
        react_1.default.createElement(eui_1.EuiSpacer, null)));
}
function AuditLogging(props) {
    const [configuration, setConfiguration] = react_1.default.useState({});
    const onSwitchChange = async () => {
        try {
            const updatedConfiguration = { ...configuration };
            updatedConfiguration.enabled = !updatedConfiguration.enabled;
            await audit_logging_utils_1.updateAuditLogging(props.coreStart.http, updatedConfiguration);
            setConfiguration(updatedConfiguration);
        }
        catch (e) {
            console.error(e);
        }
    };
    react_1.default.useEffect(() => {
        const fetchData = async () => {
            try {
                const auditLogging = await audit_logging_utils_1.getAuditLogging(props.coreStart.http);
                setConfiguration(auditLogging);
            }
            catch (e) {
                // TODO: switch to better error handling.
                console.log(e);
            }
        };
        fetchData();
    }, [props.coreStart.http, props.fromType]);
    const statusPanel = renderStatusPanel(onSwitchChange, configuration.enabled || false);
    let content;
    if (!configuration.enabled) {
        content = statusPanel;
    }
    else {
        content = (react_1.default.createElement(react_1.default.Fragment, null,
            statusPanel,
            react_1.default.createElement(eui_1.EuiSpacer, null),
            react_1.default.createElement(eui_1.EuiPanel, null,
                react_1.default.createElement(eui_1.EuiFlexGroup, null,
                    react_1.default.createElement(eui_1.EuiFlexItem, null,
                        react_1.default.createElement(eui_1.EuiTitle, null,
                            react_1.default.createElement("h3", null, "General settings"))),
                    react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                        react_1.default.createElement(eui_1.EuiButton, { onClick: () => {
                                window.location.href =
                                    url_builder_1.buildHashUrl(types_1.ResourceType.auditLogging) + constants_1.SUB_URL_FOR_GENERAL_SETTINGS_EDIT;
                            } }, "Configure"))),
                react_1.default.createElement(eui_1.EuiHorizontalRule, { margin: "m" }),
                renderGeneralSettings(configuration)),
            react_1.default.createElement(eui_1.EuiSpacer, null),
            react_1.default.createElement(eui_1.EuiPanel, null,
                react_1.default.createElement(eui_1.EuiFlexGroup, null,
                    react_1.default.createElement(eui_1.EuiFlexItem, null,
                        react_1.default.createElement(eui_1.EuiTitle, null,
                            react_1.default.createElement("h3", null, "Compliance settings"))),
                    react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                        react_1.default.createElement(eui_1.EuiButton, { onClick: () => {
                                window.location.href =
                                    url_builder_1.buildHashUrl(types_1.ResourceType.auditLogging) + constants_1.SUB_URL_FOR_COMPLIANCE_SETTINGS_EDIT;
                            } }, "Configure"))),
                react_1.default.createElement(eui_1.EuiHorizontalRule, { margin: "m" }),
                renderComplianceSettings(configuration))));
    }
    return react_1.default.createElement("div", { className: "panel-restrict-width" }, content);
}
exports.AuditLogging = AuditLogging;
