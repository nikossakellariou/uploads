"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PermissionList = exports.renderRowExpanstionArrow = exports.toggleRowDetails = exports.renderBooleanToCheckMark = void 0;
const tslib_1 = require("tslib");
const eui_1 = require("@elastic/eui");
const lodash_1 = require("lodash");
const react_1 = tslib_1.__importStar(require("react"));
const types_1 = require("../../types");
const action_groups_utils_1 = require("../../utils/action-groups-utils");
const combo_box_utils_1 = require("../../utils/combo-box-utils");
const display_utils_1 = require("../../utils/display-utils");
const toast_utils_1 = require("../../utils/toast-utils");
const edit_modal_1 = require("./edit-modal");
const permission_tree_1 = require("../permission-tree");
const loading_spinner_utils_1 = require("../../utils/loading-spinner-utils");
const delete_confirm_modal_utils_1 = require("../../utils/delete-confirm-modal-utils");
const context_menu_1 = require("../../utils/context-menu");
const resource_utils_1 = require("../../utils/resource-utils");
const constants_1 = require("../../constants");
function renderBooleanToCheckMark(value) {
    return value ? react_1.default.createElement(eui_1.EuiIcon, { type: "check" }) : '';
}
exports.renderBooleanToCheckMark = renderBooleanToCheckMark;
function toggleRowDetails(item, actionGroupDict, setItemIdToExpandedRowMap) {
    setItemIdToExpandedRowMap((prevState) => {
        const itemIdToExpandedRowMapValues = { ...prevState };
        if (itemIdToExpandedRowMapValues[item.name]) {
            delete itemIdToExpandedRowMapValues[item.name];
        }
        else {
            itemIdToExpandedRowMapValues[item.name] = (react_1.default.createElement(permission_tree_1.PermissionTree, { permissions: item.allowedActions, actionGroups: actionGroupDict }));
        }
        return itemIdToExpandedRowMapValues;
    });
}
exports.toggleRowDetails = toggleRowDetails;
function renderRowExpanstionArrow(itemIdToExpandedRowMap, actionGroupDict, setItemIdToExpandedRowMap) {
    return (item) => item.type === 'Action group' && (react_1.default.createElement(eui_1.EuiButtonIcon, { onClick: () => toggleRowDetails(item, actionGroupDict, setItemIdToExpandedRowMap), "aria-label": itemIdToExpandedRowMap[item.name] ? 'Collapse' : 'Expand', iconType: itemIdToExpandedRowMap[item.name] ? 'arrowUp' : 'arrowDown' }));
}
exports.renderRowExpanstionArrow = renderRowExpanstionArrow;
function getColumns(itemIdToExpandedRowMap, actionGroupDict, setItemIdToExpandedRowMap) {
    return [
        {
            field: 'name',
            name: 'Name',
            sortable: true,
        },
        {
            field: 'type',
            name: 'Type',
            sortable: true,
        },
        {
            field: 'hasClusterPermission',
            name: 'Cluster permission',
            render: renderBooleanToCheckMark,
        },
        {
            field: 'hasIndexPermission',
            name: 'Index permission',
            render: renderBooleanToCheckMark,
        },
        {
            field: 'reserved',
            name: 'Customization',
            render: (reserved) => {
                return display_utils_1.renderCustomization(reserved, display_utils_1.tableItemsUIProps);
            },
        },
        {
            align: eui_1.RIGHT_ALIGNMENT,
            width: '40px',
            isExpander: true,
            render: renderRowExpanstionArrow(itemIdToExpandedRowMap, actionGroupDict, setItemIdToExpandedRowMap),
        },
    ];
}
const SEARCH_OPTIONS = {
    box: { placeholder: 'Search for action group name or permission name' },
    filters: [
        {
            type: 'field_value_selection',
            field: 'type',
            name: 'All types',
            options: [{ value: 'Action group' }, { value: 'Single permission' }],
        },
        {
            type: 'field_value_selection',
            name: 'All permissions',
            options: [
                { field: 'hasClusterPermission', name: 'Cluster permissions', value: true },
                { field: 'hasIndexPermission', name: 'Index permissions', value: true },
            ],
        },
        {
            type: 'field_value_selection',
            field: 'reserved',
            name: 'Customization',
            multiSelect: false,
            options: [
                {
                    value: true,
                    view: display_utils_1.renderCustomization(true, display_utils_1.tableItemsUIProps),
                },
                {
                    value: false,
                    view: display_utils_1.renderCustomization(false, display_utils_1.tableItemsUIProps),
                },
            ],
        },
    ],
};
function PermissionList(props) {
    const [permissionList, setPermissionList] = react_1.useState([]);
    const [actionGroupDict, setActionGroupDict] = react_1.useState({});
    const [errorFlag, setErrorFlag] = react_1.useState(false);
    const [selection, setSelection] = react_1.default.useState([]);
    const [itemIdToExpandedRowMap, setItemIdToExpandedRowMap] = react_1.useState({});
    // Modal state
    const [editModal, setEditModal] = react_1.useState(null);
    const [toasts, addToast, removeToast] = toast_utils_1.useToastState();
    const [loading, setLoading] = react_1.useState(false);
    const [query, setQuery] = react_1.useState('');
    const fetchData = react_1.useCallback(async () => {
        try {
            setLoading(true);
            const actionGroups = await action_groups_utils_1.fetchActionGroups(props.coreStart.http);
            setActionGroupDict(actionGroups);
            setPermissionList(await action_groups_utils_1.mergeAllPermissions(actionGroups));
        }
        catch (e) {
            console.log(e);
            setErrorFlag(true);
        }
        finally {
            setLoading(false);
        }
    }, [props.coreStart.http]);
    react_1.default.useEffect(() => {
        fetchData();
    }, [props.coreStart.http, fetchData]);
    const handleDelete = async () => {
        const groupsToDelete = selection.map((r) => r.name);
        try {
            await action_groups_utils_1.requestDeleteActionGroups(props.coreStart.http, groupsToDelete);
            setPermissionList(lodash_1.difference(permissionList, selection));
            setSelection([]);
        }
        catch (e) {
            console.log(e);
        }
        finally {
            closeActionsMenu();
        }
    };
    const [showDeleteConfirmModal, deleteConfirmModal] = delete_confirm_modal_utils_1.useDeleteConfirmState(handleDelete, 'action group(s)');
    const actionsMenuItems = [
        react_1.default.createElement(eui_1.EuiButtonEmpty, { id: "edit", key: "edit", onClick: () => showEditModal(selection[0].name, types_1.Action.edit, selection[0].allowedActions), disabled: selection.length !== 1 || selection[0].reserved }, "Edit"),
        react_1.default.createElement(eui_1.EuiButtonEmpty, { id: "duplicate", key: "duplicate", onClick: () => showEditModal(resource_utils_1.generateResourceName(types_1.Action.duplicate, selection[0].name), types_1.Action.duplicate, selection[0].allowedActions), disabled: selection.length !== 1 || selection[0].type !== 'Action group' }, "Duplicate"),
        react_1.default.createElement(eui_1.EuiButtonEmpty, { key: "delete", color: "danger", onClick: showDeleteConfirmModal, disabled: selection.length === 0 || selection.some((group) => group.reserved) }, "Delete"),
    ];
    const [actionsMenu, closeActionsMenu] = context_menu_1.useContextMenuState('Actions', {}, actionsMenuItems);
    const showEditModal = (initialGroupName, action, initialAllowedAction) => {
        setEditModal(react_1.default.createElement(edit_modal_1.PermissionEditModal, { groupName: initialGroupName, action: action, allowedActions: initialAllowedAction, optionUniverse: permissionList.map((group) => combo_box_utils_1.stringToComboBoxOption(group.name)), handleClose: () => setEditModal(null), handleSave: async (groupName, allowedAction) => {
                try {
                    await action_groups_utils_1.updateActionGroup(props.coreStart.http, groupName, {
                        allowed_actions: allowedAction,
                    });
                    setEditModal(null);
                    fetchData();
                    addToast({
                        id: 'saveSucceeded',
                        title: toast_utils_1.getSuccessToastMessage('Action group', action, groupName),
                        color: 'success',
                    });
                }
                catch (e) {
                    console.log(e);
                    setEditModal(null);
                    addToast({
                        id: 'saveFailed',
                        title: `Failed to save ${action} group. You may refresh the page to retry or see browser console for more information.`,
                        color: 'danger',
                    });
                }
            } }));
    };
    const createActionGroupMenuItems = [
        react_1.default.createElement(eui_1.EuiButtonEmpty, { key: "create-from-blank", onClick: () => showEditModal('', types_1.Action.create, []) }, "Create from blank"),
        react_1.default.createElement(eui_1.EuiButtonEmpty, { key: "create-from-selection", id: "create-from-selection", onClick: () => showEditModal('', types_1.Action.create, selection.map((item) => item.name)), disabled: selection.length === 0 }, "Create from selection"),
    ];
    const [createActionGroupMenu] = context_menu_1.useContextMenuState('Create action group', { fill: true }, createActionGroupMenuItems);
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement(eui_1.EuiPageHeader, null,
            react_1.default.createElement(eui_1.EuiTitle, { size: "l" },
                react_1.default.createElement("h1", null, "Permissions"))),
        react_1.default.createElement(eui_1.EuiPageContent, null,
            react_1.default.createElement(eui_1.EuiPageContentHeader, null,
                react_1.default.createElement(eui_1.EuiPageContentHeaderSection, null,
                    react_1.default.createElement(eui_1.EuiTitle, { size: "s" },
                        react_1.default.createElement("h3", null,
                            "Permissions",
                            react_1.default.createElement("span", { className: "panel-header-count" },
                                ' ',
                                "(",
                                eui_1.Query.execute(query, permissionList).length,
                                ")"))),
                    react_1.default.createElement(eui_1.EuiText, { size: "xs", color: "subdued" },
                        "Permissions are individual actions, such as cluster:admin/snapshot/restore, which lets you restore snapshots. Action groups are reusable collections of permissions, such as MANAGE_SNAPSHOTS, which lets you view, take, delete, and restore snapshots. You can often meet your security needs using the default action groups, but you might find it convenient to create your own. ",
                        react_1.default.createElement(display_utils_1.ExternalLink, { href: constants_1.DocLinks.PermissionsDoc }))),
                react_1.default.createElement(eui_1.EuiPageContentHeaderSection, null,
                    react_1.default.createElement(eui_1.EuiFlexGroup, null,
                        react_1.default.createElement(eui_1.EuiFlexItem, null, actionsMenu),
                        react_1.default.createElement(eui_1.EuiFlexItem, null, createActionGroupMenu)))),
            react_1.default.createElement(eui_1.EuiPageBody, null,
                react_1.default.createElement(eui_1.EuiInMemoryTable, { tableLayout: 'auto', loading: permissionList === [] && !errorFlag, columns: getColumns(itemIdToExpandedRowMap, actionGroupDict, setItemIdToExpandedRowMap), items: permissionList, itemId: 'name', pagination: true, search: {
                        ...SEARCH_OPTIONS,
                        onChange: (arg) => {
                            setQuery(arg.queryText);
                            return true;
                        },
                    }, selection: { onSelectionChange: setSelection }, sorting: { sort: { field: 'type', direction: 'asc' } }, error: errorFlag ? 'Load data failed, please check console log for more detail.' : '', isExpandable: true, itemIdToExpandedRowMap: itemIdToExpandedRowMap, message: loading_spinner_utils_1.showTableStatusMessage(loading, permissionList) }))),
        editModal,
        deleteConfirmModal,
        react_1.default.createElement(eui_1.EuiGlobalToastList, { toasts: toasts, toastLifeTimeMs: 10000, dismissToast: removeToast })));
}
exports.PermissionList = PermissionList;
