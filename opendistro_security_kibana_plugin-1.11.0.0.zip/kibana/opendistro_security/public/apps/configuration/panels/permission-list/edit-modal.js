"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PermissionEditModal = void 0;
const tslib_1 = require("tslib");
const eui_1 = require("@elastic/eui");
const react_1 = tslib_1.__importStar(require("react"));
const types_1 = require("../../types");
const combo_box_utils_1 = require("../../utils/combo-box-utils");
const form_row_1 = require("../../utils/form-row");
const name_row_1 = require("../../utils/name-row");
const TITLE_DICT = {
    [types_1.Action.create]: 'Create new action group',
    [types_1.Action.edit]: 'Edit action group',
    [types_1.Action.duplicate]: 'Duplicate action group',
};
function PermissionEditModal(props) {
    const [groupName, setGroupName] = react_1.useState(props.groupName);
    const [allowedActions, setAllowedActions] = react_1.useState(props.allowedActions.map(combo_box_utils_1.stringToComboBoxOption));
    const [isFormValid, setIsFormValid] = react_1.useState(true);
    return (react_1.default.createElement(eui_1.EuiOverlayMask, null,
        react_1.default.createElement(eui_1.EuiModal, { onClose: props.handleClose },
            react_1.default.createElement(eui_1.EuiModalHeader, null,
                react_1.default.createElement(eui_1.EuiModalHeaderTitle, null, TITLE_DICT[props.action])),
            react_1.default.createElement(eui_1.EuiModalBody, null,
                react_1.default.createElement(eui_1.EuiForm, null,
                    react_1.default.createElement(name_row_1.NameRow, { headerText: "Name", headerSubText: "Enter a unique name to describe the purpose of this group. You cannot change the name after creation.", resourceName: groupName, resourceType: "", action: props.action, setNameState: setGroupName, setIsFormValid: setIsFormValid }),
                    react_1.default.createElement(form_row_1.FormRow, { headerText: "Permissions" },
                        react_1.default.createElement(eui_1.EuiComboBox, { options: props.optionUniverse, selectedOptions: allowedActions, onCreateOption: combo_box_utils_1.appendOptionToComboBoxHandler(setAllowedActions, []), onChange: setAllowedActions })))),
            react_1.default.createElement(eui_1.EuiModalFooter, null,
                react_1.default.createElement(eui_1.EuiButtonEmpty, { onClick: props.handleClose }, "Cancel"),
                react_1.default.createElement(eui_1.EuiButton, { id: "submit", onClick: async () => {
                        await props.handleSave(groupName, allowedActions.map(combo_box_utils_1.comboBoxOptionToString));
                    }, fill: true, disabled: !isFormValid }, props.action === types_1.Action.create ? 'Create' : 'Save')))));
}
exports.PermissionEditModal = PermissionEditModal;
