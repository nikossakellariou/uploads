"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetStarted = void 0;
const tslib_1 = require("tslib");
const eui_1 = require("@elastic/eui");
const react_1 = tslib_1.__importDefault(require("react"));
const react_2 = require("@kbn/i18n/react");
const get_started_svg_1 = tslib_1.__importDefault(require("../../../assets/get_started.svg"));
const url_builder_1 = require("../utils/url-builder");
const types_1 = require("../types");
const constants_1 = require("../constants");
const display_utils_1 = require("../utils/display-utils");
const setOfSteps = [
    {
        title: 'Add backends',
        children: (react_1.default.createElement(react_1.default.Fragment, null,
            react_1.default.createElement(eui_1.EuiText, { size: "s", color: "subdued" },
                "Add authentication",
                react_1.default.createElement(eui_1.EuiCode, null, "(authc)"),
                "and authorization",
                react_1.default.createElement(eui_1.EuiCode, null, "(authz)"),
                "information to",
                react_1.default.createElement(eui_1.EuiCode, null, "plugins/opendistro_security/securityconfig/config.yml"),
                ". The ",
                react_1.default.createElement(eui_1.EuiCode, null, "authc"),
                " section contains the backends to check user credentials against. The ",
                react_1.default.createElement(eui_1.EuiCode, null, "authz"),
                "section contains any backends to fetch external identities from. The most common example of an external identity is an LDAP group.",
                ' ',
                react_1.default.createElement(display_utils_1.ExternalLink, { href: constants_1.DocLinks.AuthenticationFlowDoc })),
            react_1.default.createElement(eui_1.EuiSpacer, { size: "m" }),
            react_1.default.createElement(eui_1.EuiFlexGroup, { gutterSize: "s", wrap: true },
                react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                    react_1.default.createElement(display_utils_1.ExternalLinkButton, { fill: true, href: constants_1.DocLinks.BackendConfigurationDoc, text: "Create config.yml" })),
                react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                    react_1.default.createElement(eui_1.EuiButton, { "data-test-subj": "review-authentication-and-authorization", onClick: () => {
                            window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.auth);
                        } }, "Review authentication and authorization"))),
            react_1.default.createElement(eui_1.EuiSpacer, { size: "l" }))),
    },
    {
        title: 'Create roles',
        children: (react_1.default.createElement(react_1.default.Fragment, null,
            react_1.default.createElement(eui_1.EuiText, { size: "s", color: "subdued" },
                "Roles are reusable collections of permissions. The default roles are a great starting point, but you might need to create custom roles that meet your exact needs.",
                ' ',
                react_1.default.createElement(display_utils_1.ExternalLink, { href: constants_1.DocLinks.CreateRolesDoc })),
            react_1.default.createElement(eui_1.EuiSpacer, { size: "m" }),
            react_1.default.createElement(eui_1.EuiFlexGroup, { gutterSize: "s" },
                react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                    react_1.default.createElement(eui_1.EuiButton, { "data-test-subj": "explore-existing-roles", fill: true, onClick: () => {
                            window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.roles);
                        } }, "Explore existing roles")),
                react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                    react_1.default.createElement(eui_1.EuiButton, { "data-test-subj": "create-new-role", onClick: () => {
                            window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.roles, types_1.Action.create);
                        } }, "Create new role"))),
            react_1.default.createElement(eui_1.EuiSpacer, { size: "l" }))),
    },
    {
        title: 'Map users',
        children: (react_1.default.createElement(react_1.default.Fragment, null,
            react_1.default.createElement(eui_1.EuiText, { size: "s", color: "subdued" },
                "After a user successfully authenticates, the security plugin retrieves that user\u2019s roles. You can map roles directly to users, but you can also map them to external identities.",
                ' ',
                react_1.default.createElement(display_utils_1.ExternalLink, { href: constants_1.DocLinks.MapUsersToRolesDoc })),
            react_1.default.createElement(eui_1.EuiSpacer, { size: "m" }),
            react_1.default.createElement(eui_1.EuiFlexGroup, { gutterSize: "s" },
                react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                    react_1.default.createElement(eui_1.EuiButton, { "data-test-subj": "map-users-to-role", fill: true, onClick: () => {
                            window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.users);
                        } }, "Map users to a role")),
                react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                    react_1.default.createElement(eui_1.EuiButton, { "data-test-subj": "create-internal-user", onClick: () => {
                            window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.users, types_1.Action.create);
                        } }, "Create internal user"))))),
    },
];
function GetStarted(props) {
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement("div", { className: "panel-restrict-width" },
            react_1.default.createElement(eui_1.EuiPageHeader, null,
                react_1.default.createElement(eui_1.EuiTitle, { size: "l" },
                    react_1.default.createElement("h1", null, "Get started")),
                react_1.default.createElement(display_utils_1.ExternalLinkButton, { text: "Open in new window", href: url_builder_1.buildHashUrl() })),
            react_1.default.createElement(eui_1.EuiPanel, { paddingSize: "l" },
                react_1.default.createElement(eui_1.EuiText, { size: "s", color: "subdued" },
                    react_1.default.createElement("p", null, "The Open Distro for Elasticsearch security plugin lets you define the API calls that users can make and the data they can access. The most basic configuration consists of three steps.")),
                react_1.default.createElement(eui_1.EuiSpacer, { size: "l" }),
                react_1.default.createElement(eui_1.EuiImage, { size: "xl", alt: "Three steps to set up your security", url: get_started_svg_1.default }),
                react_1.default.createElement(eui_1.EuiSpacer, { size: "l" }),
                react_1.default.createElement(eui_1.EuiSteps, { steps: setOfSteps })),
            react_1.default.createElement(eui_1.EuiSpacer, { size: "l" }),
            react_1.default.createElement(eui_1.EuiPanel, { paddingSize: "l" },
                react_1.default.createElement(eui_1.EuiTitle, { size: "s" },
                    react_1.default.createElement("h3", null, "Optional: Configure audit logs")),
                react_1.default.createElement(eui_1.EuiText, { size: "s", color: "subdued" },
                    react_1.default.createElement("p", null,
                        react_1.default.createElement(react_2.FormattedMessage, { id: "audit.logs.introduction", defaultMessage: "Audit logs let you track user access to your Elasticsearch cluster and are useful for compliance purposes." }),
                        ' ',
                        react_1.default.createElement(display_utils_1.ExternalLink, { href: constants_1.DocLinks.AuditLogsDoc })),
                    react_1.default.createElement(eui_1.EuiButton, { "data-test-subj": "review-audit-log-configuration", fill: true, onClick: () => {
                            window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.auditLogging);
                        } }, "Review Audit Log Configuration"))))));
}
exports.GetStarted = GetStarted;
