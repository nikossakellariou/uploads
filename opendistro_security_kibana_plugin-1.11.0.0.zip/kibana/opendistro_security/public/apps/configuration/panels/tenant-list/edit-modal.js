"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantEditModal = void 0;
const tslib_1 = require("tslib");
const eui_1 = require("@elastic/eui");
const react_1 = tslib_1.__importStar(require("react"));
const types_1 = require("../../types");
const form_row_1 = require("../../utils/form-row");
const name_row_1 = require("../../utils/name-row");
const TITLE_DICT = {
    [types_1.Action.create]: 'Create tenant',
    [types_1.Action.edit]: 'Edit tenant',
    [types_1.Action.duplicate]: 'Duplicate tenant',
};
function TenantEditModal(props) {
    const [tenantName, setTenantName] = react_1.useState(props.tenantName);
    const [tenantDescription, setTenantDescription] = react_1.useState(props.tenantDescription);
    const [isFormValid, setIsFormValid] = react_1.useState(true);
    const handleTenantDescriptionChange = (e) => {
        setTenantDescription(e.target.value);
    };
    return (react_1.default.createElement(eui_1.EuiOverlayMask, null,
        react_1.default.createElement(eui_1.EuiModal, { onClose: props.handleClose },
            react_1.default.createElement(eui_1.EuiModalHeader, null,
                react_1.default.createElement(eui_1.EuiModalHeaderTitle, null, TITLE_DICT[props.action])),
            react_1.default.createElement(eui_1.EuiModalBody, null,
                react_1.default.createElement(eui_1.EuiForm, null,
                    react_1.default.createElement(name_row_1.NameRow, { headerText: "Name", headerSubText: "Specify a descriptive and unique tenant name that is easy to recognize. You cannot edit the name once the tenant is created.", resourceName: tenantName, resourceType: "tenant", action: props.action, setNameState: setTenantName, setIsFormValid: setIsFormValid, fullWidth: true }),
                    react_1.default.createElement(form_row_1.FormRow, { headerText: "Description", headerSubText: "Describe the purpose of the tenant.", optional: true },
                        react_1.default.createElement(eui_1.EuiTextArea, { fullWidth: true, placeholder: "Describe the tenant", value: tenantDescription, onChange: handleTenantDescriptionChange })))),
            react_1.default.createElement(eui_1.EuiHorizontalRule, { margin: "xs" }),
            react_1.default.createElement(eui_1.EuiModalFooter, null,
                react_1.default.createElement(eui_1.EuiButtonEmpty, { onClick: props.handleClose }, "Cancel"),
                react_1.default.createElement(eui_1.EuiButton, { id: "submit", onClick: async () => {
                        await props.handleSave(tenantName, tenantDescription);
                    }, fill: true, disabled: !isFormValid }, props.action === types_1.Action.create ? 'Create' : 'Save')))));
}
exports.TenantEditModal = TenantEditModal;
