"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantList = void 0;
const tslib_1 = require("tslib");
const eui_1 = require("@elastic/eui");
const react_1 = tslib_1.__importStar(require("react"));
const lodash_1 = require("lodash");
const auth_info_utils_1 = require("../../../../utils/auth-info-utils");
const types_1 = require("../../types");
const display_utils_1 = require("../../utils/display-utils");
const tenant_utils_1 = require("../../utils/tenant-utils");
const chrome_wrapper_1 = require("../../../../services/chrome_wrapper");
const edit_modal_1 = require("./edit-modal");
const toast_utils_1 = require("../../utils/toast-utils");
const types_2 = require("../../types");
const delete_confirm_modal_utils_1 = require("../../utils/delete-confirm-modal-utils");
const loading_spinner_utils_1 = require("../../utils/loading-spinner-utils");
const context_menu_1 = require("../../utils/context-menu");
const resource_utils_1 = require("../../utils/resource-utils");
const constants_1 = require("../../constants");
const tenant_instruction_view_1 = require("./tenant-instruction-view");
function TenantList(props) {
    const [tenantData, setTenantData] = react_1.default.useState([]);
    const [errorFlag, setErrorFlag] = react_1.default.useState(false);
    const [selection, setSelection] = react_1.default.useState([]);
    const [currentTenant, setCurrentTenant] = react_1.useState('');
    const [currentUsername, setCurrentUsername] = react_1.useState('');
    // Modal state
    const [editModal, setEditModal] = react_1.useState(null);
    const [toasts, addToast, removeToast] = toast_utils_1.useToastState();
    const [loading, setLoading] = react_1.useState(false);
    const [query, setQuery] = react_1.useState('');
    // Configuration
    const isPrivateEnabled = props.config.multitenancy.tenants.enable_private;
    const fetchData = react_1.useCallback(async () => {
        try {
            setLoading(true);
            const rawTenantData = await tenant_utils_1.fetchTenants(props.coreStart.http);
            const processedTenantData = tenant_utils_1.transformTenantData(rawTenantData, isPrivateEnabled);
            const activeTenant = await tenant_utils_1.fetchCurrentTenant(props.coreStart.http);
            const currentUser = await auth_info_utils_1.getCurrentUser(props.coreStart.http);
            setCurrentUsername(currentUser);
            setCurrentTenant(tenant_utils_1.resolveTenantName(activeTenant, currentUser));
            setTenantData(processedTenantData);
        }
        catch (e) {
            console.log(e);
            setErrorFlag(true);
        }
        finally {
            setLoading(false);
        }
    }, [isPrivateEnabled, props.coreStart.http]);
    react_1.default.useEffect(() => {
        fetchData();
    }, [props.coreStart.http, fetchData]);
    const handleDelete = async () => {
        const tenantsToDelete = selection.map((r) => r.tenant);
        try {
            await tenant_utils_1.requestDeleteTenant(props.coreStart.http, tenantsToDelete);
            setTenantData(lodash_1.difference(tenantData, selection));
            setSelection([]);
        }
        catch (e) {
            console.log(e);
        }
        finally {
            closeActionsMenu();
        }
    };
    const [showDeleteConfirmModal, deleteConfirmModal] = delete_confirm_modal_utils_1.useDeleteConfirmState(handleDelete, 'tenant(s)');
    const changeTenant = async (tenantValue) => {
        const selectedTenant = await tenant_utils_1.selectTenant(props.coreStart.http, {
            tenant: tenantValue,
            username: currentUsername,
        });
        setCurrentTenant(tenant_utils_1.resolveTenantName(selectedTenant, currentUsername));
    };
    const getTenantName = (tenantValue) => {
        return tenantData.find((tenant) => tenant.tenantValue === tenantValue)?.tenant;
    };
    const switchToSelectedTenant = async (tenantValue, tenantName) => {
        try {
            await changeTenant(tenantValue);
            setSelection([]);
            addToast({
                id: 'selectSucceeded',
                title: `Selected tenant is now ${tenantName}`,
                color: 'success',
            });
        }
        catch (e) {
            console.log(e);
            addToast(toast_utils_1.createUnknownErrorToast('selectFailed', `select ${tenantName} tenant`));
        }
        finally {
            closeActionsMenu();
        }
    };
    const viewOrCreateDashboard = async (tenantValue, action) => {
        try {
            await changeTenant(tenantValue);
            window.location.href = chrome_wrapper_1.getNavLinkById(props.coreStart, types_2.PageId.dashboardId);
        }
        catch (e) {
            console.log(e);
            addToast(toast_utils_1.createUnknownErrorToast(`${action}Dashboard`, `${action} dashboard for ${getTenantName(tenantValue)} tenant`));
        }
    };
    const viewOrCreateVisualization = async (tenantValue, action) => {
        try {
            await changeTenant(tenantValue);
            window.location.href = chrome_wrapper_1.getNavLinkById(props.coreStart, types_2.PageId.visualizationId);
        }
        catch (e) {
            console.log(e);
            addToast(toast_utils_1.createUnknownErrorToast(`${action}Visualization`, `${action} visualization for ${getTenantName(tenantValue)} tenant`));
        }
    };
    const columns = [
        {
            field: 'tenant',
            name: 'Name',
            render: (tenantName) => (react_1.default.createElement(react_1.default.Fragment, null,
                tenantName,
                tenantName === currentTenant && (react_1.default.createElement(react_1.default.Fragment, null,
                    "\u00A0",
                    react_1.default.createElement(eui_1.EuiBadge, null, "Current"))))),
            sortable: true,
        },
        {
            field: 'description',
            name: 'Description',
            truncateText: true,
        },
        {
            field: 'tenantValue',
            name: 'Dashboard',
            render: (tenant) => (react_1.default.createElement(react_1.default.Fragment, null,
                react_1.default.createElement(eui_1.EuiLink, { onClick: () => viewOrCreateDashboard(tenant, types_1.Action.view) }, "View dashboard"))),
        },
        {
            field: 'tenantValue',
            name: 'Visualizations',
            render: (tenant) => (react_1.default.createElement(react_1.default.Fragment, null,
                react_1.default.createElement(eui_1.EuiLink, { onClick: () => viewOrCreateVisualization(tenant, types_1.Action.view) }, "View visualizations"))),
        },
        {
            field: 'reserved',
            name: 'Customization',
            render: (reserved) => {
                return display_utils_1.renderCustomization(reserved, display_utils_1.tableItemsUIProps);
            },
        },
    ];
    const actionsMenuItems = [
        react_1.default.createElement(eui_1.EuiButtonEmpty, { id: "switchTenant", key: "switchTenant", disabled: selection.length !== 1, onClick: () => switchToSelectedTenant(selection[0].tenantValue, selection[0].tenant) }, "Switch to selected tenant"),
        react_1.default.createElement(eui_1.EuiButtonEmpty, { id: "edit", key: "edit", disabled: selection.length !== 1 || selection[0].reserved, onClick: () => showEditModal(selection[0].tenant, types_1.Action.edit, selection[0].description) }, "Edit"),
        react_1.default.createElement(eui_1.EuiButtonEmpty, { id: "duplicate", key: "duplicate", disabled: selection.length !== 1, onClick: () => showEditModal(resource_utils_1.generateResourceName(types_1.Action.duplicate, selection[0].tenant), types_1.Action.duplicate, selection[0].description) }, "Duplicate"),
        react_1.default.createElement(eui_1.EuiButtonEmpty, { id: "createDashboard", key: "createDashboard", disabled: selection.length !== 1, onClick: () => viewOrCreateDashboard(selection[0].tenantValue, types_1.Action.create) }, "Create dashboard"),
        react_1.default.createElement(eui_1.EuiButtonEmpty, { id: "createVisualizations", key: "createVisualizations", disabled: selection.length !== 1, onClick: () => viewOrCreateVisualization(selection[0].tenantValue, types_1.Action.create) }, "Create visualizations"),
        react_1.default.createElement(eui_1.EuiButtonEmpty, { id: "delete", key: "delete", color: "danger", onClick: showDeleteConfirmModal, disabled: selection.length === 0 || selection.some((tenant) => tenant.reserved) }, "Delete"),
    ];
    const [actionsMenu, closeActionsMenu] = context_menu_1.useContextMenuState('Actions', {}, actionsMenuItems);
    const showEditModal = (initialTenantName, action, initialTenantDescription) => {
        setEditModal(react_1.default.createElement(edit_modal_1.TenantEditModal, { tenantName: initialTenantName, tenantDescription: initialTenantDescription, action: action, handleClose: () => setEditModal(null), handleSave: async (tenantName, tenantDescription) => {
                try {
                    await tenant_utils_1.updateTenant(props.coreStart.http, tenantName, {
                        description: tenantDescription,
                    });
                    setEditModal(null);
                    fetchData();
                    addToast({
                        id: 'saveSucceeded',
                        title: toast_utils_1.getSuccessToastMessage('Tenant', action, tenantName),
                        color: 'success',
                    });
                }
                catch (e) {
                    console.log(e);
                    addToast(toast_utils_1.createUnknownErrorToast('saveFailed', `save ${action} tenant`));
                }
            } }));
    };
    if (!props.config.multitenancy.enabled) {
        return react_1.default.createElement(tenant_instruction_view_1.TenantInstructionView, null);
    }
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement(eui_1.EuiPageHeader, null,
            react_1.default.createElement(eui_1.EuiTitle, { size: "l" },
                react_1.default.createElement("h1", null, "Tenants"))),
        react_1.default.createElement(eui_1.EuiPageContent, null,
            react_1.default.createElement(eui_1.EuiPageContentHeader, null,
                react_1.default.createElement(eui_1.EuiPageContentHeaderSection, null,
                    react_1.default.createElement(eui_1.EuiTitle, { size: "s" },
                        react_1.default.createElement("h3", null,
                            "Tenants",
                            react_1.default.createElement("span", { className: "panel-header-count" },
                                ' ',
                                "(",
                                eui_1.Query.execute(query, tenantData).length,
                                ")"))),
                    react_1.default.createElement(eui_1.EuiText, { size: "xs", color: "subdued" },
                        "Tenants in Kibana are spaces for saving index patterns, visualizations, dashboards, and other Kibana objects. Use tenants to safely share your work with other Kibana users. You can control which roles have access to a tenant and whether those roles have read or write access. The \u201CCurrent\u201D label indicates which tenant you are using now. Switch to another tenant anytime from your user profile, which is located on the top right of the screen. ",
                        react_1.default.createElement(display_utils_1.ExternalLink, { href: constants_1.DocLinks.TenantPermissionsDoc }))),
                react_1.default.createElement(eui_1.EuiPageContentHeaderSection, null,
                    react_1.default.createElement(eui_1.EuiFlexGroup, null,
                        react_1.default.createElement(eui_1.EuiFlexItem, null, actionsMenu),
                        react_1.default.createElement(eui_1.EuiFlexItem, null,
                            react_1.default.createElement(eui_1.EuiButton, { id: "createTenant", fill: true, onClick: () => showEditModal('', types_1.Action.create, '') }, "Create tenant"))))),
            react_1.default.createElement(eui_1.EuiPageBody, null,
                react_1.default.createElement(eui_1.EuiInMemoryTable, { tableLayout: 'auto', loading: tenantData === [] && !errorFlag, columns: columns, 
                    // @ts-ignore
                    items: tenantData, itemId: 'tenant', pagination: true, search: {
                        box: { placeholder: 'Find tenant' },
                        onChange: (arg) => {
                            setQuery(arg.queryText);
                            return true;
                        },
                    }, 
                    // @ts-ignore
                    selection: { onSelectionChange: setSelection }, sorting: true, error: errorFlag ? 'Load data failed, please check console log for more detail.' : '', message: loading_spinner_utils_1.showTableStatusMessage(loading, tenantData) }))),
        editModal,
        deleteConfirmModal,
        react_1.default.createElement(eui_1.EuiGlobalToastList, { toasts: toasts, toastLifeTimeMs: 10000, dismissToast: removeToast })));
}
exports.TenantList = TenantList;
