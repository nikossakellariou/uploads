"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthorizationPanel = void 0;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importStar(require("react"));
const eui_1 = require("@elastic/eui");
const lodash_1 = require("lodash");
const panel_with_header_1 = require("../../utils/panel-with-header");
const display_utils_1 = require("../../utils/display-utils");
const loading_spinner_utils_1 = require("../../utils/loading-spinner-utils");
const constants_1 = require("../../constants");
const columns = [
    {
        field: 'domain_name',
        name: 'Domain name',
    },
    {
        field: 'http_enabled',
        name: 'HTTP',
    },
    {
        field: 'transport_enabled',
        name: 'TRANSPORT',
    },
    {
        field: 'backend_type',
        name: 'Backend type',
    },
    {
        field: 'backend_configuration',
        name: 'Backend configuration',
        render: (config) => display_utils_1.renderExpression('Backend configuration', config),
    },
];
const ENABLED_STRING = 'Enabled';
const DISABLED_STRING = 'Disabled';
const emptyListMessage = (react_1.default.createElement(eui_1.EuiEmptyPrompt, { title: react_1.default.createElement("h3", null, "No authorization"), titleSize: "s", actions: react_1.default.createElement(display_utils_1.ExternalLinkButton, { href: constants_1.DocLinks.BackendConfigurationAuthorizationDoc, text: "Manage via config.yml" }) }));
function AuthorizationPanel(props) {
    const [query, setQuery] = react_1.useState('');
    const domains = lodash_1.keys(props.authz);
    const items = lodash_1.map(domains, function (domain) {
        const data = lodash_1.get(props.authz, domain);
        // @ts-ignore
        const backend = data.authorization_backend;
        return {
            domain_name: domain,
            // @ts-ignore
            http_enabled: data.http_enabled ? ENABLED_STRING : DISABLED_STRING,
            // @ts-ignore
            transport_enabled: data.transport_enabled ? ENABLED_STRING : DISABLED_STRING,
            backend_type: backend.type,
            backend_configuration: backend.config,
        };
    });
    const search = {
        box: {
            placeholder: 'Search authorization domain',
        },
        onChange: (arg) => {
            setQuery(arg.queryText);
            return true;
        },
    };
    const headerText = 'Authorization';
    return (react_1.default.createElement(panel_with_header_1.PanelWithHeader, { headerText: headerText, headerSubText: "After the user authenticates, the security plugin can collect external identities, such as LDAP groups, from authorization backends. These backends have no execution order; the plugin tries to collect external identities from all of them.", helpLink: constants_1.DocLinks.BackendConfigurationAuthorizationDoc, count: eui_1.Query.execute(query, items).length },
        react_1.default.createElement(eui_1.EuiInMemoryTable, { tableLayout: 'auto', columns: columns, items: items, itemId: 'domain_name', pagination: true, sorting: true, search: search, message: loading_spinner_utils_1.showTableStatusMessage(props.loading, items, emptyListMessage) })));
}
exports.AuthorizationPanel = AuthorizationPanel;
