"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.InstructionView = void 0;
const tslib_1 = require("tslib");
const eui_1 = require("@elastic/eui");
const react_1 = tslib_1.__importDefault(require("react"));
const display_utils_1 = require("../../utils/display-utils");
const constants_1 = require("../../constants");
function InstructionView() {
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement(eui_1.EuiTitle, { size: "l" },
            react_1.default.createElement("h1", null, "Authentication and authorization")),
        react_1.default.createElement(eui_1.EuiSpacer, { size: "xxl" }),
        react_1.default.createElement(eui_1.EuiText, { textAlign: "center" },
            react_1.default.createElement("h2", null, "You have not set up authentication and authorization")),
        react_1.default.createElement(eui_1.EuiText, { textAlign: "center", size: "xs", color: "subdued", className: "instruction-text" },
            "In order to use Security plugin, you must decide on authentication ",
            react_1.default.createElement(eui_1.EuiCode, null, "authc"),
            ' ',
            "and authorization backends ",
            react_1.default.createElement(eui_1.EuiCode, null, "authz"),
            ". Use",
            ' ',
            react_1.default.createElement(eui_1.EuiCode, null, "plugins/opendistro_security/securityconfig/config.yml"),
            " to define how to retrieve and verify the user credentials, and how to fetch additional roles from backend system if needed."),
        react_1.default.createElement(eui_1.EuiSpacer, null),
        react_1.default.createElement("div", { style: { textAlign: 'center' } },
            react_1.default.createElement(display_utils_1.ExternalLinkButton, { fill: true, size: "s", href: constants_1.DocLinks.BackendConfigurationDoc, text: "Create config.yml" }))));
}
exports.InstructionView = InstructionView;
