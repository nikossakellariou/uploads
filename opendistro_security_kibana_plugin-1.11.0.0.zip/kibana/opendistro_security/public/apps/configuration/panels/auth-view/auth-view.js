"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthView = void 0;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importStar(require("react"));
const eui_1 = require("@elastic/eui");
const lodash_1 = require("lodash");
const authentication_sequence_panel_1 = require("./authentication-sequence-panel");
const authorization_panel_1 = require("./authorization-panel");
const constants_1 = require("../../constants");
const display_utils_1 = require("../../utils/display-utils");
const auth_view_utils_1 = require("../../utils/auth-view-utils");
const instruction_view_1 = require("./instruction-view");
function AuthView(props) {
    const [authentication, setAuthentication] = react_1.default.useState([]);
    const [authorization, setAuthorization] = react_1.default.useState([]);
    const [loading, setLoading] = react_1.useState(false);
    react_1.default.useEffect(() => {
        const fetchData = async () => {
            try {
                setLoading(true);
                const config = await auth_view_utils_1.getSecurityConfig(props.coreStart.http);
                setAuthentication(config.authc);
                setAuthorization(config.authz);
            }
            catch (e) {
                console.log(e);
            }
            finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [props.coreStart.http]);
    if (lodash_1.isEmpty(authentication)) {
        return react_1.default.createElement(instruction_view_1.InstructionView, null);
    }
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement(eui_1.EuiPageHeader, null,
            react_1.default.createElement(eui_1.EuiTitle, { size: "l" },
                react_1.default.createElement("h1", null, "Authentication and authorization")),
            react_1.default.createElement(display_utils_1.ExternalLinkButton, { href: constants_1.DocLinks.BackendConfigurationDoc, text: "Manage via config.yml" })),
        react_1.default.createElement(authentication_sequence_panel_1.AuthenticationSequencePanel, { authc: authentication, loading: loading }),
        react_1.default.createElement(eui_1.EuiSpacer, { size: "m" }),
        react_1.default.createElement(authorization_panel_1.AuthorizationPanel, { authz: authorization, loading: loading })));
}
exports.AuthView = AuthView;
