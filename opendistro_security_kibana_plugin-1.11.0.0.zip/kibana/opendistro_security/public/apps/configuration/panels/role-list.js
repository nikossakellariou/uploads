"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.RoleList = void 0;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importStar(require("react"));
const eui_1 = require("@elastic/eui");
const lodash_1 = require("lodash");
const role_list_utils_1 = require("../utils/role-list-utils");
const types_1 = require("../types");
const url_builder_1 = require("../utils/url-builder");
const display_utils_1 = require("../utils/display-utils");
const loading_spinner_utils_1 = require("../utils/loading-spinner-utils");
const delete_confirm_modal_utils_1 = require("../utils/delete-confirm-modal-utils");
const context_menu_1 = require("../utils/context-menu");
const constants_1 = require("../constants");
const columns = [
    {
        field: 'roleName',
        name: 'Role',
        render: (text) => (react_1.default.createElement("a", { href: url_builder_1.buildHashUrl(types_1.ResourceType.roles, types_1.Action.view, text) }, text)),
        sortable: true,
    },
    {
        field: 'clusterPermissions',
        name: 'Cluster permissions',
        render: display_utils_1.truncatedListView(display_utils_1.tableItemsUIProps),
        truncateText: true,
    },
    {
        field: 'indexPermissions',
        name: 'Index permissions',
        render: display_utils_1.truncatedListView(display_utils_1.tableItemsUIProps),
        truncateText: true,
    },
    {
        field: 'internalUsers',
        name: 'Internal users',
        render: display_utils_1.truncatedListView(display_utils_1.tableItemsUIProps),
    },
    {
        field: 'backendRoles',
        name: 'External indentities',
        render: display_utils_1.truncatedListView(display_utils_1.tableItemsUIProps),
    },
    {
        field: 'tenantPermissions',
        name: 'Tenants',
        render: display_utils_1.truncatedListView(display_utils_1.tableItemsUIProps),
    },
    {
        field: 'reserved',
        name: 'Customization',
        render: (reserved) => {
            return display_utils_1.renderCustomization(reserved, display_utils_1.tableItemsUIProps);
        },
    },
];
function RoleList(props) {
    const [roleData, setRoleData] = react_1.default.useState([]);
    const [errorFlag, setErrorFlag] = react_1.default.useState(false);
    const [selection, setSelection] = react_1.useState([]);
    const [loading, setLoading] = react_1.useState(false);
    react_1.default.useEffect(() => {
        const fetchData = async () => {
            try {
                setLoading(true);
                const rawRoleData = await role_list_utils_1.fetchRole(props.coreStart.http);
                const rawRoleMappingData = await role_list_utils_1.fetchRoleMapping(props.coreStart.http);
                const processedData = role_list_utils_1.transformRoleData(rawRoleData, rawRoleMappingData);
                setRoleData(processedData);
            }
            catch (e) {
                console.log(e);
                setErrorFlag(true);
            }
            finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [props.coreStart.http]);
    const handleDelete = async () => {
        const rolesToDelete = selection.map((r) => r.roleName);
        try {
            await role_list_utils_1.requestDeleteRoles(props.coreStart.http, rolesToDelete);
            // Refresh from server (calling fetchData) does not work here, the server still return the roles
            // that had been just deleted, probably because ES takes some time to sync to all nodes.
            // So here remove the selected roles from local memory directly.
            setRoleData(lodash_1.difference(roleData, selection));
            setSelection([]);
        }
        catch (e) {
            console.log(e);
        }
        finally {
            closeActionsMenu();
        }
    };
    const [showDeleteConfirmModal, deleteConfirmModal] = delete_confirm_modal_utils_1.useDeleteConfirmState(handleDelete, 'role(s)');
    const actionsMenuItems = [
        react_1.default.createElement(eui_1.EuiButtonEmpty, { key: "edit", onClick: () => {
                window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.roles, types_1.Action.edit, selection[0].roleName);
            }, disabled: selection.length !== 1 || selection[0].reserved }, "Edit"),
        // TODO: Change duplication to a popup window
        react_1.default.createElement(eui_1.EuiButtonEmpty, { key: "duplicate", onClick: () => {
                window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.roles, types_1.Action.duplicate, selection[0].roleName);
            }, disabled: selection.length !== 1 }, "Duplicate"),
        react_1.default.createElement(eui_1.EuiButtonEmpty, { key: "delete", color: "danger", onClick: showDeleteConfirmModal, disabled: selection.length === 0 || selection.some((e) => e.reserved) }, "Delete"),
    ];
    const [actionsMenu, closeActionsMenu] = context_menu_1.useContextMenuState('Actions', {}, actionsMenuItems);
    const [searchOptions, setSearchOptions] = react_1.useState({});
    const [query, setQuery] = react_1.useState('');
    react_1.useEffect(() => {
        setSearchOptions({
            onChange: (arg) => {
                setQuery(arg.queryText);
                return true;
            },
            filters: [
                {
                    type: 'field_value_selection',
                    field: 'clusterPermissions',
                    name: 'Cluster permissions',
                    options: role_list_utils_1.buildSearchFilterOptions(roleData, 'clusterPermissions'),
                },
                {
                    type: 'field_value_selection',
                    field: 'indexPermissions',
                    name: 'Index permissions',
                    options: role_list_utils_1.buildSearchFilterOptions(roleData, 'indexPermissions'),
                },
                {
                    type: 'field_value_selection',
                    field: 'internalUsers',
                    name: 'Internal users',
                    options: role_list_utils_1.buildSearchFilterOptions(roleData, 'internalUsers'),
                },
                {
                    type: 'field_value_selection',
                    field: 'backendRoles',
                    name: 'External identities',
                    options: role_list_utils_1.buildSearchFilterOptions(roleData, 'backendRoles'),
                },
                {
                    type: 'field_value_selection',
                    field: 'tenantPermissions',
                    name: 'Tenants',
                    options: role_list_utils_1.buildSearchFilterOptions(roleData, 'tenantPermissions'),
                },
                {
                    type: 'field_value_selection',
                    field: 'reserved',
                    name: 'Customization',
                    multiSelect: false,
                    options: [
                        {
                            value: true,
                            view: display_utils_1.renderCustomization(true, display_utils_1.tableItemsUIProps),
                        },
                        {
                            value: false,
                            view: display_utils_1.renderCustomization(false, display_utils_1.tableItemsUIProps),
                        },
                    ],
                },
            ],
        });
    }, [roleData]);
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement(eui_1.EuiPageHeader, null,
            react_1.default.createElement(eui_1.EuiTitle, { size: "l" },
                react_1.default.createElement("h1", null, "Roles"))),
        react_1.default.createElement(eui_1.EuiPageContent, null,
            react_1.default.createElement(eui_1.EuiPageContentHeader, { id: "role-table-container" },
                react_1.default.createElement(eui_1.EuiPageContentHeaderSection, null,
                    react_1.default.createElement(eui_1.EuiTitle, { size: "s" },
                        react_1.default.createElement("h3", null,
                            "Roles",
                            react_1.default.createElement("span", { className: "panel-header-count" },
                                ' ',
                                "(",
                                eui_1.Query.execute(query, roleData).length,
                                ")"))),
                    react_1.default.createElement(eui_1.EuiText, { size: "xs", color: "subdued" },
                        "Roles are the core way of controlling access to your cluster. Roles contain any combination of cluster-wide permission, index-specific permissions, document- and field-level security, and tenants. Then you map users to these roles so that users gain those permissions. ",
                        react_1.default.createElement(display_utils_1.ExternalLink, { href: constants_1.DocLinks.UsersAndRolesDoc }))),
                react_1.default.createElement(eui_1.EuiPageContentHeaderSection, null,
                    react_1.default.createElement(eui_1.EuiFlexGroup, null,
                        react_1.default.createElement(eui_1.EuiFlexItem, null, actionsMenu),
                        react_1.default.createElement(eui_1.EuiFlexItem, null,
                            react_1.default.createElement(eui_1.EuiButton, { fill: true, href: url_builder_1.buildHashUrl(types_1.ResourceType.roles, types_1.Action.create) }, "Create role"))))),
            react_1.default.createElement(eui_1.EuiPageBody, null,
                react_1.default.createElement(eui_1.EuiInMemoryTable, { tableLayout: 'auto', loading: roleData === [] && !errorFlag, columns: columns, items: roleData, itemId: 'roleName', pagination: true, selection: { onSelectionChange: setSelection }, sorting: true, search: searchOptions, error: errorFlag ? 'Load data failed, please check console log for more detail.' : '', message: loading_spinner_utils_1.showTableStatusMessage(loading, roleData) })),
            deleteConfirmModal)));
}
exports.RoleList = RoleList;
