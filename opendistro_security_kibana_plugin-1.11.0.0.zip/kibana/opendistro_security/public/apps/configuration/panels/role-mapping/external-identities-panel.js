"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExternalIdentitiesPanel = exports.buildExternalIdentityState = exports.unbuildExternalIdentityState = void 0;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importStar(require("react"));
const eui_1 = require("@elastic/eui");
const lodash_1 = require("lodash");
const panel_with_header_1 = require("../../utils/panel-with-header");
const form_row_1 = require("../../utils/form-row");
const array_state_utils_1 = require("../../utils/array-state-utils");
const constants_1 = require("../../constants");
function unbuildExternalIdentityState(externalIdentities) {
    return externalIdentities.map((item) => {
        return item.externalIdentity;
    });
}
exports.unbuildExternalIdentityState = unbuildExternalIdentityState;
function buildExternalIdentityState(externalIdentities) {
    return lodash_1.map(externalIdentities, (externalIdentity) => ({
        externalIdentity,
    }));
}
exports.buildExternalIdentityState = buildExternalIdentityState;
function getEmptyExternalIdentity() {
    return { externalIdentity: '' };
}
function ExternalIdentitiesPanel(props) {
    const { externalIdentities, setExternalIdentities } = props;
    // Show one empty row if there is no data.
    if (lodash_1.isEmpty(externalIdentities)) {
        setExternalIdentities([getEmptyExternalIdentity()]);
    }
    const panel = externalIdentities.map((externalIdentity, arrayIndex) => {
        const onValueChangeHandler = (externalIdentityToUpdate) => array_state_utils_1.updateElementInArrayHandler(setExternalIdentities, [arrayIndex, externalIdentityToUpdate]);
        return (react_1.default.createElement(react_1.Fragment, { key: `externalIdentity-${arrayIndex}` },
            react_1.default.createElement(eui_1.EuiFlexGroup, null,
                react_1.default.createElement(eui_1.EuiFlexItem, { style: { maxWidth: '400px' } },
                    react_1.default.createElement(form_row_1.FormRow, { headerText: arrayIndex === 0 ? 'External identities' : '' },
                        react_1.default.createElement(eui_1.EuiFieldText, { id: `externalIdentity-${arrayIndex}`, value: externalIdentity.externalIdentity, onChange: (e) => onValueChangeHandler('externalIdentity')(e.target.value), placeholder: "Type in external identity" }))),
                react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                    react_1.default.createElement(eui_1.EuiFormRow, { hasEmptyLabelSpace: arrayIndex === 0 ? true : false },
                        react_1.default.createElement(eui_1.EuiButton, { id: `remove-${arrayIndex}`, color: "danger", onClick: () => array_state_utils_1.removeElementFromArray(setExternalIdentities, [], arrayIndex) }, "Remove"))))));
    });
    return (react_1.default.createElement(panel_with_header_1.PanelWithHeader, { headerText: "External identities", headerSubText: "Use an external identity to directly map to roles through an external authentication system.", helpLink: constants_1.DocLinks.CreateUsersDoc },
        panel,
        react_1.default.createElement(eui_1.EuiSpacer, null),
        react_1.default.createElement(eui_1.EuiButton, { id: "add-row", onClick: () => {
                array_state_utils_1.appendElementToArray(setExternalIdentities, [], getEmptyExternalIdentity());
            } }, "Add another external identity")));
}
exports.ExternalIdentitiesPanel = ExternalIdentitiesPanel;
