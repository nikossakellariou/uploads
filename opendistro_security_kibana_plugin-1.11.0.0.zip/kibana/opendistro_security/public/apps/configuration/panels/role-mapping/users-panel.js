"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.InternalUsersPanel = void 0;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importDefault(require("react"));
const eui_1 = require("@elastic/eui");
const panel_with_header_1 = require("../../utils/panel-with-header");
const form_row_1 = require("../../utils/form-row");
const url_builder_1 = require("../../utils/url-builder");
const types_1 = require("../../types");
const display_utils_1 = require("../../utils/display-utils");
const constants_1 = require("../../constants");
const combo_box_utils_1 = require("../../utils/combo-box-utils");
function InternalUsersPanel(props) {
    const { state, optionUniverse, setState } = props;
    return (react_1.default.createElement(panel_with_header_1.PanelWithHeader, { headerText: "Users", headerSubText: "You can create an internal user in internal user database of the security plugin. An\n      internal user can have its own backend role and host for an external authentication and\n      authorization.", helpLink: constants_1.DocLinks.CreateUsersDoc },
        react_1.default.createElement(eui_1.EuiForm, null,
            react_1.default.createElement(form_row_1.FormRow, { headerText: "Users", helpText: "Look up by user name. You can also create new internal user." },
                react_1.default.createElement(eui_1.EuiFlexGroup, null,
                    react_1.default.createElement(eui_1.EuiFlexItem, { style: { maxWidth: '400px' } },
                        react_1.default.createElement(eui_1.EuiComboBox, { options: optionUniverse, selectedOptions: state, onChange: setState, onCreateOption: combo_box_utils_1.appendOptionToComboBoxHandler(setState, []) })),
                    react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                        react_1.default.createElement(display_utils_1.ExternalLinkButton, { text: "Create new internal user", href: url_builder_1.buildHashUrl(types_1.ResourceType.users, types_1.Action.create) })))))));
}
exports.InternalUsersPanel = InternalUsersPanel;
