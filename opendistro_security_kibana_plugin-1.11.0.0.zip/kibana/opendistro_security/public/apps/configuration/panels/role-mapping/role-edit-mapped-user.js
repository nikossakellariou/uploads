"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.RoleEditMappedUser = void 0;
const tslib_1 = require("tslib");
const eui_1 = require("@elastic/eui");
const react_1 = tslib_1.__importStar(require("react"));
const users_panel_1 = require("./users-panel");
const external_identities_panel_1 = require("./external-identities-panel");
const combo_box_utils_1 = require("../../utils/combo-box-utils");
const url_builder_1 = require("../../utils/url-builder");
const types_1 = require("../../types");
const internal_user_list_utils_1 = require("../../utils/internal-user-list-utils");
const role_mapping_utils_1 = require("../../utils/role-mapping-utils");
const toast_utils_1 = require("../../utils/toast-utils");
const constants_1 = require("../../constants");
const storage_utils_1 = require("../../utils/storage-utils");
const display_utils_1 = require("../../utils/display-utils");
const TITLE_TEXT_DICT = {
    mapuser: 'Map user',
};
function RoleEditMappedUser(props) {
    const [internalUsers, setInternalUsers] = react_1.default.useState([]);
    const [externalIdentities, setExternalIdentities] = react_1.default.useState([]);
    const [userNames, setUserNames] = react_1.useState([]);
    const [hosts, setHosts] = react_1.default.useState([]);
    const [toasts, addToast, removeToast] = toast_utils_1.useToastState();
    react_1.default.useEffect(() => {
        const fetchData = async () => {
            try {
                const originalRoleMapData = await role_mapping_utils_1.getRoleMappingData(props.coreStart.http, props.roleName);
                if (originalRoleMapData) {
                    setInternalUsers(originalRoleMapData.users.map(combo_box_utils_1.stringToComboBoxOption));
                    setExternalIdentities(external_identities_panel_1.buildExternalIdentityState(originalRoleMapData.backend_roles));
                    setHosts(originalRoleMapData.hosts);
                }
            }
            catch (e) {
                addToast(toast_utils_1.createUnknownErrorToast('fetchRoleMappingData', 'load data'));
                console.log(e);
            }
        };
        fetchData();
    }, [addToast, props.coreStart.http, props.roleName]);
    react_1.default.useEffect(() => {
        const fetchInternalUserNames = async () => {
            try {
                setUserNames(await internal_user_list_utils_1.fetchUserNameList(props.coreStart.http));
            }
            catch (e) {
                addToast(toast_utils_1.createUnknownErrorToast('fetchInternalUserNames', 'load data'));
                console.error(e);
            }
        };
        fetchInternalUserNames();
    }, [addToast, props.coreStart.http]);
    const internalUserOptions = userNames.map(combo_box_utils_1.stringToComboBoxOption);
    const updateRoleMappingHandler = async () => {
        try {
            // Remove empty External Identities
            const validExternalIdentities = externalIdentities.filter((v) => v.externalIdentity !== '');
            const updateObject = {
                users: internalUsers.map(combo_box_utils_1.comboBoxOptionToString),
                backend_roles: external_identities_panel_1.unbuildExternalIdentityState(validExternalIdentities),
                hosts,
            };
            await role_mapping_utils_1.updateRoleMapping(props.coreStart.http, props.roleName, updateObject);
            storage_utils_1.setCrossPageToast(url_builder_1.buildUrl(types_1.ResourceType.roles, types_1.Action.view, props.roleName, types_1.SubAction.mapuser), {
                id: 'updateRoleMappingSucceeded',
                color: 'success',
                title: 'Role "' + props.roleName + '" successfully updated.',
            });
            window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.roles, types_1.Action.view, props.roleName, types_1.SubAction.mapuser);
        }
        catch (e) {
            if (e.message) {
                addToast(toast_utils_1.createErrorToast('saveRoleMappingFailed', 'save error', e.message));
            }
            else {
                addToast(toast_utils_1.createUnknownErrorToast('saveRoleMappingFailed', 'save ' + props.roleName));
                console.error(e);
            }
        }
    };
    return (react_1.default.createElement(react_1.default.Fragment, null,
        props.buildBreadcrumbs(props.roleName, TITLE_TEXT_DICT[types_1.SubAction.mapuser]),
        react_1.default.createElement(eui_1.EuiPageHeader, null,
            react_1.default.createElement(eui_1.EuiText, { size: "xs", color: "subdued" },
                react_1.default.createElement(eui_1.EuiTitle, { size: "m" },
                    react_1.default.createElement("h1", null, "Map user")),
                "Map users to this role to inherit role permissions. Two types of users are supported: internal user, and external identity. ",
                react_1.default.createElement(display_utils_1.ExternalLink, { href: constants_1.DocLinks.MapUsersToRolesDoc }))),
        react_1.default.createElement(eui_1.EuiSpacer, { size: "m" }),
        react_1.default.createElement(users_panel_1.InternalUsersPanel, { state: internalUsers, setState: setInternalUsers, optionUniverse: internalUserOptions }),
        react_1.default.createElement(eui_1.EuiSpacer, { size: "m" }),
        react_1.default.createElement(external_identities_panel_1.ExternalIdentitiesPanel, { externalIdentities: externalIdentities, setExternalIdentities: setExternalIdentities }),
        react_1.default.createElement(eui_1.EuiSpacer, { size: "m" }),
        react_1.default.createElement(eui_1.EuiFlexGroup, { justifyContent: "flexEnd" },
            react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                react_1.default.createElement(eui_1.EuiButton, { onClick: () => {
                        window.location.href = url_builder_1.buildHashUrl(types_1.ResourceType.roles, types_1.Action.view, props.roleName);
                    } }, "Cancel")),
            react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                react_1.default.createElement(eui_1.EuiButton, { id: "map", fill: true, onClick: updateRoleMappingHandler }, "Map"))),
        react_1.default.createElement(eui_1.EuiGlobalToastList, { toasts: toasts, toastLifeTimeMs: 10000, dismissToast: removeToast })));
}
exports.RoleEditMappedUser = RoleEditMappedUser;
