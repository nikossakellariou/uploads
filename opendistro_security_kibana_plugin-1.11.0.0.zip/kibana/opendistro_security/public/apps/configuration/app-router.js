"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppRouter = exports.getBreadcrumbs = void 0;
const tslib_1 = require("tslib");
const eui_1 = require("@elastic/eui");
const lodash_1 = require("lodash");
const react_1 = tslib_1.__importDefault(require("react"));
const react_router_dom_1 = require("react-router-dom");
const audit_logging_1 = require("./panels/audit-logging/audit-logging");
const audit_logging_edit_settings_1 = require("./panels/audit-logging/audit-logging-edit-settings");
const constants_1 = require("./panels/audit-logging/constants");
const auth_view_1 = require("./panels/auth-view/auth-view");
const get_started_1 = require("./panels/get-started");
const internal_user_edit_1 = require("./panels/internal-user-edit/internal-user-edit");
const nav_panel_1 = require("./panels/nav-panel");
const permission_list_1 = require("./panels/permission-list/permission-list");
const role_edit_1 = require("./panels/role-edit/role-edit");
const role_list_1 = require("./panels/role-list");
const role_edit_mapped_user_1 = require("./panels/role-mapping/role-edit-mapped-user");
const role_view_1 = require("./panels/role-view/role-view");
const tenant_list_1 = require("./panels/tenant-list/tenant-list");
const user_list_1 = require("./panels/user-list");
const types_1 = require("./types");
const url_builder_1 = require("./utils/url-builder");
const cross_page_toast_1 = require("./cross-page-toast");
const LANDING_PAGE_URL = '/getstarted';
const ROUTE_MAP = {
    getStarted: {
        name: 'Get Started',
        href: LANDING_PAGE_URL,
    },
    [types_1.ResourceType.roles]: {
        name: 'Roles',
        href: url_builder_1.buildUrl(types_1.ResourceType.roles),
    },
    [types_1.ResourceType.users]: {
        name: 'Internal users',
        href: url_builder_1.buildUrl(types_1.ResourceType.users),
    },
    [types_1.ResourceType.permissions]: {
        name: 'Permissions',
        href: url_builder_1.buildUrl(types_1.ResourceType.permissions),
    },
    [types_1.ResourceType.tenants]: {
        name: 'Tenants',
        href: url_builder_1.buildUrl(types_1.ResourceType.tenants),
    },
    [types_1.ResourceType.auth]: {
        name: 'Authc & authz',
        href: url_builder_1.buildUrl(types_1.ResourceType.auth),
    },
    [types_1.ResourceType.auditLogging]: {
        name: 'Audit logs',
        href: url_builder_1.buildUrl(types_1.ResourceType.auditLogging),
    },
};
const ROUTE_LIST = [
    ROUTE_MAP.getStarted,
    ROUTE_MAP[types_1.ResourceType.auth],
    ROUTE_MAP[types_1.ResourceType.roles],
    ROUTE_MAP[types_1.ResourceType.users],
    ROUTE_MAP[types_1.ResourceType.permissions],
    ROUTE_MAP[types_1.ResourceType.tenants],
    ROUTE_MAP[types_1.ResourceType.auditLogging],
];
const allNavPanelUrls = ROUTE_LIST.map((route) => route.href).concat([
    url_builder_1.buildUrl(types_1.ResourceType.auditLogging) + constants_1.SUB_URL_FOR_GENERAL_SETTINGS_EDIT,
    url_builder_1.buildUrl(types_1.ResourceType.auditLogging) + constants_1.SUB_URL_FOR_COMPLIANCE_SETTINGS_EDIT,
]);
function getBreadcrumbs(resourceType, pageTitle, subAction) {
    const breadcrumbs = [
        {
            text: 'Security',
            href: url_builder_1.buildHashUrl(),
        },
    ];
    if (resourceType) {
        breadcrumbs.push({
            text: ROUTE_MAP[resourceType].name,
            href: url_builder_1.buildHashUrl(resourceType),
        });
    }
    if (pageTitle) {
        breadcrumbs.push({
            text: pageTitle,
        });
    }
    if (subAction) {
        breadcrumbs.push({
            text: subAction,
        });
    }
    return breadcrumbs;
}
exports.getBreadcrumbs = getBreadcrumbs;
function AppRouter(props) {
    const setGlobalBreadcrumbs = lodash_1.flow(getBreadcrumbs, props.coreStart.chrome.setBreadcrumbs);
    return (react_1.default.createElement(react_router_dom_1.HashRouter, { basename: props.params.appBasePath },
        react_1.default.createElement(eui_1.EuiPage, null,
            allNavPanelUrls.map((route) => (
            // Create different routes to update the 'selected' nav item .
            react_1.default.createElement(react_router_dom_1.Route, { key: route, path: route, exact: true },
                react_1.default.createElement(eui_1.EuiPageSideBar, null,
                    react_1.default.createElement(nav_panel_1.NavPanel, { items: ROUTE_LIST }))))),
            react_1.default.createElement(eui_1.EuiPageBody, null,
                react_1.default.createElement(react_router_dom_1.Switch, null,
                    react_1.default.createElement(react_router_dom_1.Route, { path: url_builder_1.buildUrl(types_1.ResourceType.roles, types_1.Action.edit, ':roleName', types_1.SubAction.mapuser), render: (match) => (react_1.default.createElement(role_edit_mapped_user_1.RoleEditMappedUser, Object.assign({ buildBreadcrumbs: lodash_1.partial(setGlobalBreadcrumbs, types_1.ResourceType.roles) }, { ...props, ...match.match.params }))) }),
                    react_1.default.createElement(react_router_dom_1.Route, { path: url_builder_1.buildUrl(types_1.ResourceType.roles, types_1.Action.view, ':roleName', ':prevAction?'), render: (match) => (react_1.default.createElement(role_view_1.RoleView, Object.assign({ buildBreadcrumbs: lodash_1.partial(setGlobalBreadcrumbs, types_1.ResourceType.roles) }, { ...props, ...match.match.params }))) }),
                    react_1.default.createElement(react_router_dom_1.Route, { path: url_builder_1.buildUrl(types_1.ResourceType.roles) + '/:action/:sourceRoleName?', render: (match) => (react_1.default.createElement(role_edit_1.RoleEdit, Object.assign({ buildBreadcrumbs: lodash_1.partial(setGlobalBreadcrumbs, types_1.ResourceType.roles) }, { ...props, ...match.match.params }))) }),
                    react_1.default.createElement(react_router_dom_1.Route, { path: ROUTE_MAP.roles.href, render: () => {
                            setGlobalBreadcrumbs(types_1.ResourceType.roles);
                            return react_1.default.createElement(role_list_1.RoleList, Object.assign({}, props));
                        } }),
                    react_1.default.createElement(react_router_dom_1.Route, { path: ROUTE_MAP.auth.href, render: () => {
                            setGlobalBreadcrumbs(types_1.ResourceType.auth);
                            return react_1.default.createElement(auth_view_1.AuthView, Object.assign({}, props));
                        } }),
                    react_1.default.createElement(react_router_dom_1.Route, { path: url_builder_1.buildUrl(types_1.ResourceType.users) + '/:action/:sourceUserName?', render: (match) => (react_1.default.createElement(internal_user_edit_1.InternalUserEdit, Object.assign({ buildBreadcrumbs: lodash_1.partial(setGlobalBreadcrumbs, types_1.ResourceType.users) }, { ...props, ...match.match.params }))) }),
                    react_1.default.createElement(react_router_dom_1.Route, { path: ROUTE_MAP.users.href, render: () => {
                            setGlobalBreadcrumbs(types_1.ResourceType.users);
                            return react_1.default.createElement(user_list_1.UserList, Object.assign({}, props));
                        } }),
                    react_1.default.createElement(react_router_dom_1.Route, { path: url_builder_1.buildUrl(types_1.ResourceType.auditLogging) + constants_1.SUB_URL_FOR_GENERAL_SETTINGS_EDIT, render: () => {
                            setGlobalBreadcrumbs(types_1.ResourceType.auditLogging, 'General settings');
                            return react_1.default.createElement(audit_logging_edit_settings_1.AuditLoggingEditSettings, Object.assign({ setting: 'general' }, props));
                        } }),
                    react_1.default.createElement(react_router_dom_1.Route, { path: url_builder_1.buildUrl(types_1.ResourceType.auditLogging) + constants_1.SUB_URL_FOR_COMPLIANCE_SETTINGS_EDIT, render: () => {
                            setGlobalBreadcrumbs(types_1.ResourceType.auditLogging, 'Compliance settings');
                            return react_1.default.createElement(audit_logging_edit_settings_1.AuditLoggingEditSettings, Object.assign({ setting: 'compliance' }, props));
                        } }),
                    react_1.default.createElement(react_router_dom_1.Route, { path: ROUTE_MAP.auditLogging.href + '/:fromType?', render: (match) => {
                            setGlobalBreadcrumbs(types_1.ResourceType.auditLogging);
                            return react_1.default.createElement(audit_logging_1.AuditLogging, Object.assign({}, { ...props, ...match.match.params }));
                        } }),
                    react_1.default.createElement(react_router_dom_1.Route, { path: ROUTE_MAP.permissions.href, render: () => {
                            setGlobalBreadcrumbs(types_1.ResourceType.permissions);
                            return react_1.default.createElement(permission_list_1.PermissionList, Object.assign({}, props));
                        } }),
                    react_1.default.createElement(react_router_dom_1.Route, { path: ROUTE_MAP.tenants.href, render: () => {
                            setGlobalBreadcrumbs(types_1.ResourceType.tenants);
                            return react_1.default.createElement(tenant_list_1.TenantList, Object.assign({}, props));
                        } }),
                    react_1.default.createElement(react_router_dom_1.Route, { path: ROUTE_MAP.getStarted.href, render: () => {
                            setGlobalBreadcrumbs();
                            return react_1.default.createElement(get_started_1.GetStarted, Object.assign({}, props));
                        } }),
                    react_1.default.createElement(react_router_dom_1.Redirect, { exact: true, from: "/", to: LANDING_PAGE_URL }))),
            react_1.default.createElement(cross_page_toast_1.CrossPageToast, null))));
}
exports.AppRouter = AppRouter;
