"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildHashUrl = exports.buildUrl = void 0;
/**
 * Build hash based url.
 * e.g.
 *   buildUrl() => "/" (landing page)
 *   buildUrl(ResourceType.roles) => "/roles" (role listing page)
 *   buildUrl(ResourceType.roles, Action.create) => "/roles/create" (role creation page)
 *   buildUrl(ResourceType.roles, Action.view, "someRole") => "/roles/view/someRole" (role detail page)
 *   buildUrl(ResourceType.roles, Action.view, "someRole", SubAction.mapuser) => "/roles/view/someRole/mapuser" (Map User page)
 * edge case (wrong usage) fallbacks:
 *   buildUrl(undefined, Action.create) => ""
 *   buildUrl(ResourceType.roles, undefined, "someRole") => "/roles"
 */
function buildUrl(resouceType, action, resourceId, subAction) {
    const rawContents = [resouceType, action, resourceId, subAction];
    const contents = [];
    for (const content of rawContents) {
        if (content === undefined) {
            break;
        }
        contents.push(content);
    }
    return '/' + contents.join('/');
}
exports.buildUrl = buildUrl;
function buildHashUrl(resouceType, action, resourceId, subAction) {
    return '#' + buildUrl(resouceType, action, resourceId, subAction);
}
exports.buildHashUrl = buildHashUrl;
