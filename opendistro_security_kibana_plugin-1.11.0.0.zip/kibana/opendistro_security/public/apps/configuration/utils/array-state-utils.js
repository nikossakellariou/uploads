"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeElementFromArray = exports.appendElementToArray = exports.updateElementInArrayHandler = exports.updateElementInArray = void 0;
const lodash_1 = require("lodash");
function resolveValue(value) {
    return typeof value === 'function' ? value() : value;
}
/**
 * Update an element in an sub array
 * @param setStateCallback setState function
 * @param path lodash path, e.g. [0, indexPattern] or "[0].indexPattern"
 * @param newValue value to be updated
 *
 * e.g.
 *  currentState = [{a: 1}, {a: 2}]
 *  path = [0, 'a']
 *  newValue = 10
 * The newState will be [{a: 10}, {a: 2}]
 */
function updateElementInArray(setStateCallback, path, newValue) {
    setStateCallback((prevState) => {
        const newState = [...prevState];
        lodash_1.set(newState, path, resolveValue(newValue));
        return newState;
    });
}
exports.updateElementInArray = updateElementInArray;
exports.updateElementInArrayHandler = lodash_1.curry(updateElementInArray);
/**
 * Append an element to an array (or sub array indicating by path)
 * @param setStateCallback setState function
 * @param path lodash path, e.g. [0, indexPattern] or "[0].indexPattern", use [] to indicate root level
 * @param newValue value to be updated
 *
 * e.g.
 * Scenario 1, path = [] to append to root level array
 *  currentState = [1, 2]
 *  path = []
 *  newValue = 3
 * The newState will be [1, 2, 3]
 *
 * Scenario 2, path != [] to append to sub array
 *  currentState = [{a: [1, 2]}, {a: [3, 4]}]
 *  path = [0, 'a']
 *  newValue = 5
 * The newState will be [{a: [1, 2, 5]}, {a: [3, 4]}]
 */
function appendElementToArray(setStateCallback, path, newValue) {
    const resolvedNewValue = resolveValue(newValue);
    setStateCallback((prevState) => {
        if (path.length === 0) {
            return [...prevState, resolvedNewValue];
        }
        else {
            const newArray = [...lodash_1.get(prevState, path), resolvedNewValue];
            const newState = [...prevState];
            lodash_1.set(newState, path, newArray);
            return newState;
        }
    });
}
exports.appendElementToArray = appendElementToArray;
/**
 * Remove an element from an array (or sub array indicating by path)
 * @param setStateCallback setState function
 * @param path lodash path, e.g. [0, indexPattern] or "[0].indexPattern", use [] to indicate root level
 * @param index index of element to be removed
 *
 * e.g.
 * Scenario 1, path = [] to append to root level array
 *  currentState = [1, 2]
 *  path = []
 *  index = 0
 * The newState will be [2]
 *
 * Scenario 2, path != [] to append to sub array
 *  currentState = [{a: [1, 2]}, {a: [3, 4]}]
 *  path = [0, 'a']
 *  index = 1
 * The newState will be [{a: [1]}, {a: [3, 4]}]
 */
function removeElementFromArray(setStateCallback, path, index) {
    setStateCallback((prevState) => {
        if (path.length === 0) {
            const newState = [...prevState];
            newState.splice(index, 1);
            return newState;
        }
        else {
            const newArray = [...lodash_1.get(prevState, path)];
            newArray.splice(index, 1);
            const newState = [...prevState];
            lodash_1.set(newState, path, newArray);
            return newState;
        }
    });
}
exports.removeElementFromArray = removeElementFromArray;
