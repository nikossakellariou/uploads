"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.NameRow = void 0;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importStar(require("react"));
const eui_1 = require("@elastic/eui");
const form_row_1 = require("./form-row");
const resource_validation_util_1 = require("./resource-validation-util");
function NameRow(props) {
    const [errors, setErrors] = react_1.useState([]);
    const validateName = () => {
        setErrors(resource_validation_util_1.validateResourceName(props.resourceType, props.resourceName));
        const errorMessages = resource_validation_util_1.validateResourceName(props.resourceType, props.resourceName);
        props.setIsFormValid(!(errorMessages.length > 0));
        setErrors(errorMessages);
    };
    return (react_1.default.createElement(form_row_1.FormRow, { headerText: props.headerText, headerSubText: props.headerSubText, helpText: resource_validation_util_1.resourceNameHelpText(props.resourceType), isInvalid: errors.length > 0, error: errors },
        react_1.default.createElement(eui_1.EuiFieldText, { fullWidth: props.fullWidth, value: props.resourceName, onChange: (e) => {
                props.setNameState(e.target.value);
            }, onBlur: () => {
                validateName();
            }, disabled: props.action === 'edit', isInvalid: errors.length > 0 })));
}
exports.NameRow = NameRow;
