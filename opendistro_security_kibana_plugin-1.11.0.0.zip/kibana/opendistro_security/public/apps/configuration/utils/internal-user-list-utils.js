"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchUserNameList = exports.getUserList = exports.requestDeleteUsers = exports.transformUserData = void 0;
const lodash_1 = require("lodash");
const constants_1 = require("../constants");
function transformUserData(rawData) {
    return lodash_1.map(rawData, (value, key) => ({
        username: key || '',
        attributes: value.attributes,
        backend_roles: value.backend_roles,
    }));
}
exports.transformUserData = transformUserData;
async function requestDeleteUsers(http, users) {
    for (const user of users) {
        await http.delete(`${constants_1.API_ENDPOINT_INTERNALUSERS}/${user}`);
    }
}
exports.requestDeleteUsers = requestDeleteUsers;
async function getUserListRaw(http) {
    return (await http.get(`${constants_1.API_ENDPOINT_INTERNALUSERS}`));
}
async function getUserList(http) {
    const rawData = await getUserListRaw(http);
    return transformUserData(rawData.data);
}
exports.getUserList = getUserList;
async function fetchUserNameList(http) {
    return Object.keys((await getUserListRaw(http)).data);
}
exports.fetchUserNameList = fetchUserNameList;
