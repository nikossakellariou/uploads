"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resourceNameHelpText = exports.isResourceNameValid = exports.isResourceNameLengthValid = exports.validateResourceName = void 0;
const tslib_1 = require("tslib");
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
const xregexp_1 = tslib_1.__importDefault(require("xregexp"));
const lodash_1 = require("lodash");
const constants_1 = require("../constants");
const RESOURCE_ID_REGEX = xregexp_1.default('^[\\p{L}\\p{N}\\p{P}-]+$', 'u');
const VALID_LENGTH_HELP_TEXT = (resourceType) => {
    return `The ${resourceType} name must contain from ${constants_1.MIN_NUMBER_OF_CHARS_IN_RESOURCE_NAME} to ${constants_1.MAX_NUMBER_OF_CHARS_IN_RESOURCE_NAME} characters.`;
};
const VALID_CHARACTERS_HELP_TEXT = 'Valid characters are A-Z, a-z, 0-9, (_)underscore, (-) hyphen and unicode characters.';
function validateResourceName(resourceType, resourceName) {
    const errors = [];
    if (!isResourceNameLengthValid(resourceName)) {
        errors.push(VALID_LENGTH_HELP_TEXT(resourceType));
    }
    if (!isResourceNameValid(resourceName)) {
        errors.push(`Invalid characters found in ${resourceType} name. ${VALID_CHARACTERS_HELP_TEXT}`);
    }
    return errors;
}
exports.validateResourceName = validateResourceName;
function isResourceNameLengthValid(resourceName) {
    if (resourceName.length < constants_1.MIN_NUMBER_OF_CHARS_IN_RESOURCE_NAME ||
        resourceName.length > constants_1.MAX_NUMBER_OF_CHARS_IN_RESOURCE_NAME)
        return false;
    return true;
}
exports.isResourceNameLengthValid = isResourceNameLengthValid;
function isResourceNameValid(resourceName) {
    if (!lodash_1.isEmpty(resourceName) && !xregexp_1.default.test(resourceName, RESOURCE_ID_REGEX)) {
        return false;
    }
    return true;
}
exports.isResourceNameValid = isResourceNameValid;
function resourceNameHelpText(resourceType) {
    return `${VALID_LENGTH_HELP_TEXT(resourceType)} ${VALID_CHARACTERS_HELP_TEXT}`;
}
exports.resourceNameHelpText = resourceNameHelpText;
