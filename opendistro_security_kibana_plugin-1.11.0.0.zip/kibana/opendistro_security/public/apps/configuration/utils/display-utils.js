"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExternalLink = exports.ExternalLinkButton = exports.displayHeaderWithTooltip = exports.renderExpression = exports.truncatedListView = exports.renderCustomization = exports.displayObject = exports.displayArray = exports.displayBoolean = exports.renderTextFlexItem = exports.tableItemsUIProps = void 0;
const tslib_1 = require("tslib");
// TODO: call the util functions from wherever applicable.
const eui_1 = require("@elastic/eui");
const lodash_1 = require("lodash");
const react_1 = tslib_1.__importDefault(require("react"));
const expression_modal_1 = require("../panels/expression-modal");
const ui_constants_1 = require("../ui-constants");
const constants_1 = require("../constants");
exports.tableItemsUIProps = {
    cssClassName: 'table-items',
};
function renderTextFlexItem(header, value) {
    return (react_1.default.createElement(eui_1.EuiFlexItem, null,
        react_1.default.createElement(eui_1.EuiText, { size: "xs" },
            react_1.default.createElement("strong", null, header),
            react_1.default.createElement("div", null, value))));
}
exports.renderTextFlexItem = renderTextFlexItem;
function displayBoolean(bool) {
    return bool ? 'Enabled' : 'Disabled';
}
exports.displayBoolean = displayBoolean;
function displayArray(array) {
    return array?.join(', ') || ui_constants_1.EMPTY_FIELD_VALUE;
}
exports.displayArray = displayArray;
function displayObject(object) {
    return !lodash_1.isEmpty(object) ? JSON.stringify(object, null, 2) : ui_constants_1.EMPTY_FIELD_VALUE;
}
exports.displayObject = displayObject;
function renderCustomization(reserved, props) {
    return (react_1.default.createElement(eui_1.EuiFlexGroup, { alignItems: "center", gutterSize: "xs" },
        react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
            react_1.default.createElement(eui_1.EuiIcon, { type: reserved ? 'lock' : 'pencil' })),
        react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
            react_1.default.createElement(eui_1.EuiText, { className: props.cssClassName }, reserved ? 'Reserved' : 'Custom'))));
}
exports.renderCustomization = renderCustomization;
function truncatedListView(props, limit = 3) {
    return (items) => {
        // Show - to indicate empty
        if (items === undefined || items.length === 0) {
            return (react_1.default.createElement(eui_1.EuiFlexGroup, { direction: "column", style: { margin: '1px' } },
                react_1.default.createElement(eui_1.EuiText, { key: '-', className: props.cssClassName }, ui_constants_1.EMPTY_FIELD_VALUE)));
        }
        // If number of items over than limit, truncate and show ...
        return (react_1.default.createElement(eui_1.EuiFlexGroup, { direction: "column", style: { margin: '1px' } },
            items.slice(0, limit).map((item) => (react_1.default.createElement(eui_1.EuiText, { key: item, className: props.cssClassName }, item))),
            items.length > limit && (react_1.default.createElement(eui_1.EuiText, { key: '...', className: props.cssClassName }, "..."))));
    };
}
exports.truncatedListView = truncatedListView;
function renderExpression(title, expression) {
    if (lodash_1.isEmpty(expression)) {
        return ui_constants_1.EMPTY_FIELD_VALUE;
    }
    return react_1.default.createElement(expression_modal_1.ExpressionModal, { title: title, expression: expression });
}
exports.renderExpression = renderExpression;
exports.displayHeaderWithTooltip = (columnHeader, tooltipText) => {
    return (react_1.default.createElement(eui_1.EuiToolTip, { content: tooltipText },
        react_1.default.createElement("span", null,
            columnHeader,
            ' ',
            react_1.default.createElement(eui_1.EuiIcon, { size: "s", color: "subdued", type: "questionInCircle", className: "eui-alignTop" }))));
};
function ExternalLinkButton(props) {
    const { text, ...buttonProps } = props;
    return (react_1.default.createElement(eui_1.EuiButton, Object.assign({ iconType: "popout", iconSide: "right", target: "_blank" }, buttonProps), props.text));
}
exports.ExternalLinkButton = ExternalLinkButton;
function ExternalLink(props) {
    return (react_1.default.createElement(eui_1.EuiLink, { external: true, href: props.href, target: "_blank", className: "external-link-inline-block" }, constants_1.LEARN_MORE));
}
exports.ExternalLink = ExternalLink;
