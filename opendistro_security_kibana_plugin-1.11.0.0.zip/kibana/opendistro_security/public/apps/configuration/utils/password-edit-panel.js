"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PasswordEditPanel = void 0;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importStar(require("react"));
const eui_1 = require("@elastic/eui");
const form_row_1 = require("./form-row");
const apps_constants_1 = require("../../apps-constants");
function PasswordEditPanel(props) {
    const [password, setPassword] = react_1.useState('');
    const [repeatPassword, setRepeatPassword] = react_1.useState('');
    const [isRepeatPasswordInvalid, setIsRepeatPasswordInvalid] = react_1.useState(false);
    react_1.useEffect(() => {
        props.updatePassword(password);
        const isInvalid = repeatPassword !== password;
        setIsRepeatPasswordInvalid(isInvalid);
        props.updateIsInvalid(isInvalid);
    }, [password, props, repeatPassword]);
    const passwordChangeHandler = (e) => {
        setPassword(e.target.value);
    };
    const repeatPasswordChangeHandler = (e) => {
        setRepeatPassword(e.target.value);
    };
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement(form_row_1.FormRow, { headerText: "Password", helpText: apps_constants_1.PASSWORD_INSTRUCTION },
            react_1.default.createElement(eui_1.EuiFieldText, { prepend: react_1.default.createElement(eui_1.EuiIcon, { type: "lock" }), type: "password", onChange: passwordChangeHandler })),
        react_1.default.createElement(form_row_1.FormRow, { headerText: "Re-enter password", helpText: "The password must be identical to what you entered above." },
            react_1.default.createElement(eui_1.EuiFieldText, { prepend: react_1.default.createElement(eui_1.EuiIcon, { type: "lock" }), type: "password", isInvalid: isRepeatPasswordInvalid, onChange: repeatPasswordChangeHandler }))));
}
exports.PasswordEditPanel = PasswordEditPanel;
