"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAndClearCrossPageToast = exports.setCrossPageToast = exports.setValue = exports.getValue = void 0;
/*
 * This file leverage storage for frontend data. Currently it is for cross page toasts only,
 * so session storage is in use (no need to hold the toast message to until next session)
 */
function getValue(category, key) {
    const item = sessionStorage.getItem(`${category}::${key}`);
    if (!item) {
        return null;
    }
    return JSON.parse(item);
}
exports.getValue = getValue;
function setValue(category, key, value) {
    sessionStorage.setItem(`${category}::${key}`, JSON.stringify(value));
}
exports.setValue = setValue;
const TOAST_CATEGORY = 'toast';
function setCrossPageToast(targetUrl, toast) {
    setValue(TOAST_CATEGORY, targetUrl, toast);
}
exports.setCrossPageToast = setCrossPageToast;
function getAndClearCrossPageToast(targetUrl) {
    const result = getValue(TOAST_CATEGORY, targetUrl);
    setValue(TOAST_CATEGORY, targetUrl, null);
    return result;
}
exports.getAndClearCrossPageToast = getAndClearCrossPageToast;
