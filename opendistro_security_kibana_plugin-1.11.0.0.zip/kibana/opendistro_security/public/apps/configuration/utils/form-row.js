"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.FormRow = void 0;
const tslib_1 = require("tslib");
const eui_1 = require("@elastic/eui");
const react_1 = tslib_1.__importDefault(require("react"));
const display_utils_1 = require("./display-utils");
function FormRow(props) {
    return (react_1.default.createElement(eui_1.EuiFormRow, { fullWidth: true, label: react_1.default.createElement(react_1.default.Fragment, null,
            react_1.default.createElement(eui_1.EuiText, { size: "xs" },
                react_1.default.createElement("b", null, props.headerText),
                react_1.default.createElement("i", null, props.optional && ' - optional')),
            react_1.default.createElement(eui_1.EuiText, { color: "subdued", size: "xs" },
                props.headerSubText,
                props.helpLink && (react_1.default.createElement(react_1.default.Fragment, null,
                    ' ',
                    react_1.default.createElement(display_utils_1.ExternalLink, { href: props.helpLink }))))), helpText: props.helpText, isInvalid: props.isInvalid, error: props.error }, props.children));
}
exports.FormRow = FormRow;
