"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateRoleMapping = exports.transformRoleMappingData = exports.getRoleMappingData = exports.UserType = void 0;
const lodash_1 = require("lodash");
const constants_1 = require("../constants");
const request_utils_1 = require("./request-utils");
var UserType;
(function (UserType) {
    UserType["internal"] = "User";
    UserType["external"] = "External identity";
})(UserType = exports.UserType || (exports.UserType = {}));
async function getRoleMappingData(http, roleName) {
    return request_utils_1.getWithIgnores(http, `${constants_1.API_ENDPOINT_ROLESMAPPING}/${roleName}`, [404]);
}
exports.getRoleMappingData = getRoleMappingData;
function transformRoleMappingData(rawData) {
    const internalUsers = lodash_1.map(rawData.users, (mappedUser) => ({
        userName: mappedUser,
        userType: UserType.internal,
    }));
    const externalIdentity = lodash_1.map(rawData.backend_roles, (mappedExternalIdentity) => ({
        userName: mappedExternalIdentity,
        userType: UserType.external,
    }));
    return internalUsers.concat(externalIdentity);
}
exports.transformRoleMappingData = transformRoleMappingData;
async function updateRoleMapping(http, roleName, updateObject) {
    return await http.post(`${constants_1.API_ENDPOINT_ROLESMAPPING}/${roleName}`, {
        body: JSON.stringify(updateObject),
    });
}
exports.updateRoleMapping = updateRoleMapping;
