"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.requestDeleteActionGroups = exports.updateActionGroup = exports.mergeAllPermissions = exports.getAllPermissionsListing = exports.fetchActionGroupListing = exports.fetchActionGroups = void 0;
const lodash_1 = require("lodash");
const constants_1 = require("../constants");
async function fetchActionGroups(http) {
    const actiongroups = await http.get(constants_1.API_ENDPOINT_ACTIONGROUPS);
    return actiongroups.data;
}
exports.fetchActionGroups = fetchActionGroups;
function tranformActionGroupsToListingFormat(rawData) {
    return lodash_1.map(rawData, (value, key) => ({
        name: key || '',
        type: 'Action group',
        reserved: value.reserved,
        allowedActions: value.allowed_actions,
        hasClusterPermission: value.type === 'cluster' || value.type === 'all',
        hasIndexPermission: value.type === 'index' || value.type === 'all',
    }));
}
async function fetchActionGroupListing(http) {
    return tranformActionGroupsToListingFormat(await fetchActionGroups(http));
}
exports.fetchActionGroupListing = fetchActionGroupListing;
function getClusterSinglePermissions() {
    return constants_1.CLUSTER_PERMISSIONS.map((permission) => ({
        name: permission,
        type: 'Single permission',
        reserved: true,
        allowedActions: [],
        hasClusterPermission: true,
        hasIndexPermission: false,
    }));
}
function getIndexSinglePermissions() {
    return constants_1.INDEX_PERMISSIONS.map((permission) => ({
        name: permission,
        type: 'Single permission',
        reserved: true,
        allowedActions: [],
        hasClusterPermission: false,
        hasIndexPermission: true,
    }));
}
async function getAllPermissionsListing(http) {
    return mergeAllPermissions(await fetchActionGroups(http));
}
exports.getAllPermissionsListing = getAllPermissionsListing;
async function mergeAllPermissions(actionGroups) {
    return tranformActionGroupsToListingFormat(actionGroups)
        .concat(getClusterSinglePermissions())
        .concat(getIndexSinglePermissions());
}
exports.mergeAllPermissions = mergeAllPermissions;
async function updateActionGroup(http, groupName, updateObject) {
    return await http.post(`${constants_1.API_ENDPOINT_ACTIONGROUPS}/${groupName}`, {
        body: JSON.stringify(updateObject),
    });
}
exports.updateActionGroup = updateActionGroup;
async function requestDeleteActionGroups(http, groups) {
    for (const group of groups) {
        await http.delete(`${constants_1.API_ENDPOINT_ACTIONGROUPS}/${group}`);
    }
}
exports.requestDeleteActionGroups = requestDeleteActionGroups;
