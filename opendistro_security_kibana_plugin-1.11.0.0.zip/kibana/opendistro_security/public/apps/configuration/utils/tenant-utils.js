"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.transformRoleTenantPermissions = exports.getTenantPermissionType = exports.transformRoleTenantPermissionData = exports.formatTenantName = exports.resolveTenantName = exports.RESOLVED_PRIVATE_TENANT = exports.RESOLVED_GLOBAL_TENANT = exports.selectTenant = exports.requestDeleteTenant = exports.updateTenant = exports.fetchCurrentTenant = exports.transformTenantData = exports.fetchTenantNameList = exports.fetchTenants = exports.PRIVATE_USER_DICT = exports.GLOBAL_USER_DICT = exports.globalTenantName = void 0;
const lodash_1 = require("lodash");
const constants_1 = require("../constants");
const types_1 = require("../types");
const constants_2 = require("../constants");
exports.globalTenantName = 'global_tenant';
exports.GLOBAL_USER_DICT = {
    Label: 'Global',
    Value: '',
    Description: 'Everyone can see it',
};
exports.PRIVATE_USER_DICT = {
    Label: 'Private',
    Value: '__user__',
    Description: 'Only visible to the current logged in user',
};
async function fetchTenants(http) {
    return (await http.get(constants_1.API_ENDPOINT_TENANTS)).data;
}
exports.fetchTenants = fetchTenants;
async function fetchTenantNameList(http) {
    return Object.keys(await fetchTenants(http));
}
exports.fetchTenantNameList = fetchTenantNameList;
function transformTenantData(rawTenantData, isPrivateEnabled) {
    // @ts-ignore
    const tenantList = lodash_1.map(rawTenantData, (v, k) => ({
        tenant: k === exports.globalTenantName ? exports.GLOBAL_USER_DICT.Label : k || '',
        reserved: v.reserved,
        description: k === exports.globalTenantName ? exports.GLOBAL_USER_DICT.Description : v.description,
        tenantValue: k === exports.globalTenantName ? exports.GLOBAL_USER_DICT.Value : k || '',
    }));
    if (isPrivateEnabled) {
        // Insert Private Tenant in List
        tenantList.splice(1, 0, {
            tenant: exports.PRIVATE_USER_DICT.Label,
            reserved: true,
            description: exports.PRIVATE_USER_DICT.Description,
            tenantValue: exports.PRIVATE_USER_DICT.Value,
        });
    }
    return tenantList;
}
exports.transformTenantData = transformTenantData;
async function fetchCurrentTenant(http) {
    return await http.get(constants_1.API_ENDPOINT_MULTITENANCY);
}
exports.fetchCurrentTenant = fetchCurrentTenant;
async function updateTenant(http, tenantName, updateObject) {
    return await http.post(`${constants_1.API_ENDPOINT_TENANTS}/${tenantName}`, {
        body: JSON.stringify(updateObject),
    });
}
exports.updateTenant = updateTenant;
async function requestDeleteTenant(http, tenants) {
    for (const tenant of tenants) {
        await http.delete(`${constants_1.API_ENDPOINT_TENANTS}/${tenant}`);
    }
}
exports.requestDeleteTenant = requestDeleteTenant;
async function selectTenant(http, selectObject) {
    return await http.post(`${constants_1.API_ENDPOINT_MULTITENANCY}`, {
        body: JSON.stringify(selectObject),
    });
}
exports.selectTenant = selectTenant;
exports.RESOLVED_GLOBAL_TENANT = 'Global';
exports.RESOLVED_PRIVATE_TENANT = 'Private';
function resolveTenantName(tenant, userName) {
    if (!tenant || tenant === 'undefined') {
        return exports.RESOLVED_GLOBAL_TENANT;
    }
    if (tenant === userName || tenant === '__user__') {
        return exports.RESOLVED_PRIVATE_TENANT;
    }
    else {
        return tenant;
    }
}
exports.resolveTenantName = resolveTenantName;
function formatTenantName(tenantName) {
    if (tenantName === exports.globalTenantName)
        return exports.GLOBAL_USER_DICT.Label;
    return tenantName;
}
exports.formatTenantName = formatTenantName;
function transformRoleTenantPermissionData(tenantPermissions, tenantList) {
    return lodash_1.map(tenantPermissions, (tenantPermission) => {
        const tenantNames = tenantList.map((t) => t.tenant);
        /**
         * Here we only consider the case that containing one tenant and
         * for other case (multiple tenants, tenant pattern) we return N/A.
         */
        let tenantItem = null;
        if (tenantPermission.tenant_patterns.length === 1 &&
            tenantNames.includes(formatTenantName(tenantPermission.tenant_patterns[0]))) {
            tenantItem = tenantList.filter((t) => {
                return t.tenant === formatTenantName(tenantPermission.tenant_patterns[0]);
            })[0];
        }
        return {
            tenant_patterns: tenantPermission.tenant_patterns,
            permissionType: tenantPermission.permissionType,
            tenant: tenantItem?.tenant || constants_1.RoleViewTenantInvalidText,
            reserved: tenantItem?.reserved || false,
            description: tenantItem?.description || constants_1.RoleViewTenantInvalidText,
            tenantValue: tenantItem ? tenantItem.tenantValue : constants_1.RoleViewTenantInvalidText,
        };
    });
}
exports.transformRoleTenantPermissionData = transformRoleTenantPermissionData;
function getTenantPermissionType(tenantPermissions) {
    const readable = tenantPermissions.includes(constants_2.TENANT_READ_PERMISSION);
    const writable = tenantPermissions.includes(constants_2.TENANT_WRITE_PERMISSION);
    let permissionType = types_1.TenantPermissionType.None;
    if (readable && writable) {
        permissionType = types_1.TenantPermissionType.Full;
    }
    else if (readable) {
        permissionType = types_1.TenantPermissionType.Read;
    }
    else if (writable) {
        permissionType = types_1.TenantPermissionType.Write;
    }
    return permissionType;
}
exports.getTenantPermissionType = getTenantPermissionType;
function transformRoleTenantPermissions(roleTenantPermission) {
    return roleTenantPermission.map((tenantPermission) => ({
        tenant_patterns: tenantPermission.tenant_patterns,
        permissionType: getTenantPermissionType(tenantPermission.allowed_actions),
    }));
}
exports.transformRoleTenantPermissions = transformRoleTenantPermissions;
