"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.useDeleteConfirmState = void 0;
const tslib_1 = require("tslib");
const react_1 = tslib_1.__importStar(require("react"));
const eui_1 = require("@elastic/eui");
/**
 *
 * @param handleDelete: [Type: func] delete function which needs to be execute on click of confirm button.
 * @param entity: e.g. role(s), tenant(s), user(s), mapping etc. This will display in confirmation text before deletion.
 * @param customConfirmationText: If you want other than default confirm message, pass it as customConfirmationText.
 */
function useDeleteConfirmState(handleDelete, entity, customConfirmationText) {
    const [isDeleteConfirmModalVisible, setIsDeleteConfirmModalVisible] = react_1.useState(false);
    const closeDeleteConfirmModal = () => setIsDeleteConfirmModalVisible(false);
    const showDeleteConfirmModal = () => setIsDeleteConfirmModalVisible(true);
    const handleConfirm = async () => {
        await handleDelete();
        closeDeleteConfirmModal();
    };
    let deleteConfirmModal;
    if (isDeleteConfirmModalVisible) {
        deleteConfirmModal = (react_1.default.createElement(eui_1.EuiOverlayMask, null,
            react_1.default.createElement(eui_1.EuiConfirmModal, { title: "Confirm Delete", onCancel: closeDeleteConfirmModal, onConfirm: handleConfirm, cancelButtonText: "Cancel", confirmButtonText: "Confirm", defaultFocusedButton: "confirm" }, customConfirmationText ? (customConfirmationText) : (react_1.default.createElement("p", null,
                "Do you really want to delete selected ",
                entity,
                "?")))));
    }
    return [showDeleteConfirmModal, deleteConfirmModal];
}
exports.useDeleteConfirmState = useDeleteConfirmState;
