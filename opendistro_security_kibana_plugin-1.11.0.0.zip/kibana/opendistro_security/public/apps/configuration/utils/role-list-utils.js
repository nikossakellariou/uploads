"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchRoleMapping = exports.fetchRole = exports.requestDeleteRoles = exports.buildSearchFilterOptions = exports.transformRoleData = void 0;
const lodash_1 = require("lodash");
const constants_1 = require("../constants");
const request_utils_1 = require("./request-utils");
/*
Input[0] - Role Schema: {
  data: {
    [roleName]: {
      reserved: bool,
      cluster_permissions: [""]
      index_permissions: [{
        index_patterns: [""],
        fls: [""],
        masked_fields: [""],
        allowed_actions: [""]
      }],
      tenant_permissions: [{
        tenant_patterns: [""],
        allowed_actions: [""]
      }]
    }
  }
}

Input[1] - RoleMapping schema: {
  data: {
    [roleName]: {
      reserved,
      backend_roles: [""],
      users: [""]
    }
  }
}
*/
function transformRoleData(rawRoleData, rawRoleMappingData) {
    return lodash_1.map(rawRoleData.data, (v, k) => ({
        roleName: k || '',
        reserved: v.reserved,
        clusterPermissions: v.cluster_permissions,
        indexPermissions: lodash_1.chain(v.index_permissions)
            .map('index_patterns')
            .flatten()
            .compact()
            .value(),
        tenantPermissions: lodash_1.chain(v.tenant_permissions)
            .map('tenant_patterns')
            .flatten()
            .compact()
            .value(),
        internalUsers: rawRoleMappingData.data[k || '']?.users || [],
        backendRoles: rawRoleMappingData.data[k || '']?.backend_roles || [],
    }));
}
exports.transformRoleData = transformRoleData;
// Flatten list, remove duplicate and null, sort
function buildSearchFilterOptions(roleList, attrName) {
    return lodash_1.chain(roleList)
        .map(attrName)
        .flatten()
        .compact()
        .uniq()
        .sortBy()
        .map((e) => ({ value: e }))
        .value();
}
exports.buildSearchFilterOptions = buildSearchFilterOptions;
// Submit request to delete given roles. No error handling in this function.
async function requestDeleteRoles(http, roles) {
    for (const role of roles) {
        await http.delete(`${constants_1.API_ENDPOINT_ROLES}/${role}`);
        await request_utils_1.deleteWithIgnores(http, `${constants_1.API_ENDPOINT_ROLESMAPPING}/${role}`, [404]);
    }
}
exports.requestDeleteRoles = requestDeleteRoles;
// TODO: have a type definition for it
function fetchRole(http) {
    return http.get(constants_1.API_ENDPOINT_ROLES);
}
exports.fetchRole = fetchRole;
// TODO: have a type definition for it
function fetchRoleMapping(http) {
    return http.get(constants_1.API_ENDPOINT_ROLESMAPPING);
}
exports.fetchRoleMapping = fetchRoleMapping;
