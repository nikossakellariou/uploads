"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderApp = void 0;
const tslib_1 = require("tslib");
require("./_index.scss");
const react_1 = tslib_1.__importDefault(require("react"));
const react_dom_1 = tslib_1.__importDefault(require("react-dom"));
const react_2 = require("@kbn/i18n/react");
const app_router_1 = require("./app-router");
function renderApp(coreStart, navigation, params, config) {
    const deps = { coreStart, navigation, params, config };
    react_dom_1.default.render(react_1.default.createElement(react_2.I18nProvider, null,
        react_1.default.createElement(app_router_1.AppRouter, Object.assign({}, deps))), params.element);
    return () => react_dom_1.default.unmountComponentAtNode(params.element);
}
exports.renderApp = renderApp;
