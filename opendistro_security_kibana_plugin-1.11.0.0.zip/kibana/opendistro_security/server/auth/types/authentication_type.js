"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthenticationType = void 0;
const opendistro_security_client_1 = require("../../backend/opendistro_security_client");
const tenant_resolver_1 = require("../../multitenancy/tenant_resolver");
const errors_1 = require("../../errors");
class AuthenticationType {
    constructor(config, sessionStorageFactory, router, esClient, coreSetup, logger) {
        this.config = config;
        this.sessionStorageFactory = sessionStorageFactory;
        this.router = router;
        this.esClient = esClient;
        this.coreSetup = coreSetup;
        this.logger = logger;
        this.authHandler = async (request, response, toolkit) => {
            // skip auth for APIs that do not require auth
            if (this.authNotRequired(request)) {
                return toolkit.authenticated();
            }
            // if browser request, auth logic is:
            //   1. check if request includes auth header or paramter(e.g. jwt in url params) is present, if so, authenticate with auth header.
            //   2. if auth header not present, check if auth cookie is present, if no cookie, send to authentication workflow
            //   3. verify whether auth cookie is valid, if not valid, send to authentication workflow
            //   4. if cookie is valid, pass to route handlers
            const authHeaders = {};
            let cookie;
            let authInfo;
            // if this is an REST API call, suppose the request includes necessary auth header
            // see https://www.elastic.co/guide/en/kibana/master/using-api.html
            if (this.requestIncludesAuthInfo(request)) {
                try {
                    const additonalAuthHeader = this.getAdditionalAuthHeader(request);
                    Object.assign(authHeaders, additonalAuthHeader);
                    authInfo = await this.securityClient.authinfo(request, additonalAuthHeader);
                    cookie = await this.getCookie(request, authInfo);
                    this.sessionStorageFactory.asScoped(request).set(cookie);
                }
                catch (error) {
                    return response.unauthorized({
                        body: error.message,
                    });
                }
            }
            else {
                // no auth header in request, try cookie
                try {
                    cookie = await this.sessionStorageFactory.asScoped(request).get();
                }
                catch (error) {
                    this.logger.error(`Error parsing cookie: ${error.message}`);
                    cookie = undefined;
                }
                if (!cookie || !(await this.isValidCookie(cookie))) {
                    // clear cookie
                    this.sessionStorageFactory.asScoped(request).clear();
                    // for assets, we can still pass it to resource handler as notHandled.
                    // marking it as authenticated may result in login pop up when auth challenge
                    // is enabled.
                    if (request.url.pathname && request.url.pathname.startsWith('/bundles/')) {
                        return toolkit.notHandled();
                    }
                    // send to auth workflow
                    return this.handleUnauthedRequest(request, response, toolkit);
                }
                // extend session expiration time
                if (this.config.session.keepalive) {
                    cookie.expiryTime = Date.now() + this.config.session.ttl;
                    this.sessionStorageFactory.asScoped(request).set(cookie);
                }
                // cookie is valid
                // build auth header
                const authHeadersFromCookie = this.buildAuthHeaderFromCookie(cookie);
                Object.assign(authHeaders, authHeadersFromCookie);
                const additonalAuthHeader = this.getAdditionalAuthHeader(request);
                Object.assign(authHeaders, additonalAuthHeader);
            }
            // resolve tenant if necessary
            if (this.config.multitenancy?.enabled && tenant_resolver_1.isMultitenantPath(request)) {
                try {
                    const tenant = await this.resolveTenant(request, cookie, authHeaders, authInfo);
                    // return 401 if no tenant available
                    if (!tenant_resolver_1.isValidTenant(tenant)) {
                        return response.badRequest({
                            body: 'No available tenant for current user, please reach out to your system administrator',
                        });
                    }
                    // set tenant in header
                    Object.assign(authHeaders, { securitytenant: tenant });
                    // set tenant to cookie
                    if (tenant !== cookie.tenant) {
                        cookie.tenant = tenant;
                        this.sessionStorageFactory.asScoped(request).set(cookie);
                    }
                }
                catch (error) {
                    this.logger.error(`Failed to resolve user tenant: ${error}`);
                    if (error instanceof errors_1.UnauthenticatedError) {
                        if (request.url.pathname && request.url.pathname.startsWith('/bundles/')) {
                            return toolkit.notHandled();
                        }
                        return this.handleUnauthedRequest(request, response, toolkit);
                    }
                    throw error;
                }
            }
            return toolkit.authenticated({
                requestHeaders: authHeaders,
            });
        };
        this.securityClient = new opendistro_security_client_1.SecurityClient(esClient);
        this.type = '';
    }
    authNotRequired(request) {
        const pathname = request.url.pathname;
        if (!pathname) {
            return false;
        }
        // allow requests to ignored routes
        if (AuthenticationType.ROUTES_TO_IGNORE.includes(pathname)) {
            return true;
        }
        // allow requests to routes that doesn't require authentication
        if (this.config.auth.unauthenticated_routes.indexOf(pathname) > -1) {
            // TODO: use kibana server user
            return true;
        }
        return false;
    }
    async resolveTenant(request, cookie, authHeader, authInfo) {
        if (!authInfo) {
            try {
                authInfo = await this.securityClient.authinfo(request, authHeader);
            }
            catch (error) {
                throw new errors_1.UnauthenticatedError(error);
            }
        }
        const selectedTenant = tenant_resolver_1.resolveTenant(request, authInfo.user_name, authInfo.tenants, this.config, cookie);
        return selectedTenant;
    }
}
exports.AuthenticationType = AuthenticationType;
AuthenticationType.ROUTES_TO_IGNORE = [
    '/api/core/capabilities',
    '/app/login',
];
AuthenticationType.REST_API_CALL_HEADER = 'kbn-xsrf';
