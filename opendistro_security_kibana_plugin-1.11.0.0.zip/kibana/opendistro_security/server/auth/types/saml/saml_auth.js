"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SamlAuthentication = void 0;
const querystring_1 = require("querystring");
const routes_1 = require("./routes");
const authentication_type_1 = require("../authentication_type");
class SamlAuthentication extends authentication_type_1.AuthenticationType {
    constructor(config, sessionStorageFactory, router, esClient, coreSetup, logger) {
        super(config, sessionStorageFactory, router, esClient, coreSetup, logger);
        this.type = 'saml';
        this.setupRoutes();
    }
    generateNextUrl(request) {
        const path = this.coreSetup.http.basePath.serverBasePath + (request.url.path || '/app/kibana');
        return querystring_1.escape(path);
    }
    redirectToLoginUri(request, toolkit) {
        const nextUrl = this.generateNextUrl(request);
        return toolkit.redirected({
            location: `${this.coreSetup.http.basePath.serverBasePath}/auth/saml/login?nextUrl=${nextUrl}`,
        });
    }
    setupRoutes() {
        const samlAuthRoutes = new routes_1.SamlAuthRoutes(this.router, this.config, this.sessionStorageFactory, this.securityClient, this.coreSetup);
        samlAuthRoutes.setupRoutes();
    }
    requestIncludesAuthInfo(request) {
        return request.headers[SamlAuthentication.AUTH_HEADER_NAME] ? true : false;
    }
    getAdditionalAuthHeader(request) {
        return {};
    }
    async getCookie(request, authInfo) {
        return {
            username: authInfo.user_name,
            credentials: {
                authHeaderValue: request.headers[SamlAuthentication.AUTH_HEADER_NAME],
            },
            authType: this.type,
            expiryTime: Date.now() + this.config.cookie.ttl,
        };
    }
    async isValidCookie(cookie) {
        return (cookie.authType === this.type &&
            cookie.username &&
            cookie.expiryTime &&
            cookie.credentials?.authHeaderValue);
    }
    handleUnauthedRequest(request, response, toolkit) {
        return this.redirectToLoginUri(request, toolkit);
    }
    buildAuthHeaderFromCookie(cookie) {
        const headers = {};
        headers[SamlAuthentication.AUTH_HEADER_NAME] = cookie.credentials?.authHeaderValue;
        return headers;
    }
}
exports.SamlAuthentication = SamlAuthentication;
SamlAuthentication.AUTH_HEADER_NAME = 'authorization';
