"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.JwtAuthentication = void 0;
const authentication_type_1 = require("../authentication_type");
const routes_1 = require("./routes");
class JwtAuthentication extends authentication_type_1.AuthenticationType {
    constructor(config, sessionStorageFactory, router, esClient, coreSetup, logger) {
        super(config, sessionStorageFactory, router, esClient, coreSetup, logger);
        this.type = 'jwt';
        this.authHeaderName = this.config.jwt?.header.toLowerCase() || 'authorization';
        this.init();
    }
    async init() {
        const routes = new routes_1.JwtAuthRoutes(this.router, this.sessionStorageFactory);
        routes.setupRoutes();
    }
    getTokenFromUrlParam(request) {
        const urlParamName = this.config.jwt?.url_param;
        if (urlParamName) {
            const token = request.url.query[urlParamName];
            return token || undefined;
        }
        return undefined;
    }
    getBearerToken(request) {
        const token = this.getTokenFromUrlParam(request);
        if (token) {
            return `Bearer ${token}`;
        }
        // no token in url parameter, try to get token from header
        return request.headers[this.authHeaderName] || undefined;
    }
    requestIncludesAuthInfo(request) {
        if (request.headers[this.authHeaderName]) {
            return true;
        }
        const urlParamName = this.config.jwt?.url_param;
        if (urlParamName && request.url.query[urlParamName]) {
            return true;
        }
        return false;
    }
    getAdditionalAuthHeader(request) {
        const header = {};
        const token = this.getTokenFromUrlParam(request);
        if (token) {
            header[this.authHeaderName] = `Bearer ${token}`;
        }
        return header;
    }
    async getCookie(request, authInfo) {
        return {
            username: authInfo.user_name,
            credentials: {
                authHeaderValue: this.getBearerToken(request),
            },
            authType: this.type,
            expiryTime: Date.now() + this.config.cookie.ttl,
        };
    }
    async isValidCookie(cookie) {
        return (cookie.authType === this.type &&
            cookie.username &&
            cookie.expiryTime &&
            cookie.credentials?.authHeaderValue);
    }
    handleUnauthedRequest(request, response, toolkit) {
        return response.unauthorized();
    }
    buildAuthHeaderFromCookie(cookie) {
        const header = {};
        const authHeaderValue = cookie.credentials?.authHeaderValue;
        if (authHeaderValue) {
            header[this.authHeaderName] = authHeaderValue;
        }
        return header;
    }
}
exports.JwtAuthentication = JwtAuthentication;
