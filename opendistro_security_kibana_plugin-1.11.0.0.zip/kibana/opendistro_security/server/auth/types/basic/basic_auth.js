"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.BasicAuthentication = void 0;
const routes_1 = require("./routes");
const authentication_type_1 = require("../authentication_type");
const common_1 = require("../../../../common");
const next_url_1 = require("../../../utils/next_url");
class BasicAuthentication extends authentication_type_1.AuthenticationType {
    constructor(config, sessionStorageFactory, router, esClient, coreSetup, logger) {
        super(config, sessionStorageFactory, router, esClient, coreSetup, logger);
        this.type = 'basicauth';
        this.init();
    }
    async init() {
        const routes = new routes_1.BasicAuthRoutes(this.router, this.config, this.sessionStorageFactory, this.securityClient, this.coreSetup);
        routes.setupRoutes();
    }
    // override functions inherited from AuthenticationType
    requestIncludesAuthInfo(request) {
        return request.headers[BasicAuthentication.AUTH_HEADER_NAME] ? true : false;
    }
    getAdditionalAuthHeader(request) {
        return {};
    }
    async getCookie(request, authInfo) {
        if (this.config.auth.anonymous_auth_enabled &&
            authInfo.user_name === 'opendistro_security_anonymous') {
            return {
                username: authInfo.user_name,
                authType: this.type,
                expiryTime: Date.now() + this.config.cookie.ttl,
                isAnonymousAuth: true,
            };
        }
        return {
            username: authInfo.user_name,
            credentials: {
                authHeaderValue: request.headers[BasicAuthentication.AUTH_HEADER_NAME],
            },
            authType: this.type,
            expiryTime: Date.now() + this.config.cookie.ttl,
        };
    }
    async isValidCookie(cookie) {
        return (cookie.authType === this.type &&
            cookie.expiryTime &&
            ((cookie.username && cookie.credentials?.authHeaderValue) ||
                (this.config.auth.anonymous_auth_enabled && cookie.isAnonymousAuth)));
    }
    handleUnauthedRequest(request, response, toolkit) {
        // TODO: do the samething for other auth types?
        // return 302 for /app
        const pathname = request.url.pathname || '';
        if (pathname.startsWith('/app/') || pathname === '/') {
            const nextUrlParam = next_url_1.composeNextUrlQeuryParam(request, this.coreSetup.http.basePath.serverBasePath);
            const redirectLocation = `${this.coreSetup.http.basePath.serverBasePath}${common_1.LOGIN_PAGE_URI}?${nextUrlParam}`;
            return response.redirected({
                headers: {
                    location: `${redirectLocation}`,
                },
            });
        }
        else {
            return response.unauthorized({
                body: `Authentication required`,
            });
        }
    }
    buildAuthHeaderFromCookie(cookie) {
        if (this.config.auth.anonymous_auth_enabled && cookie.isAnonymousAuth) {
            return {};
        }
        const headers = {};
        Object.assign(headers, { authorization: cookie.credentials?.authHeaderValue });
        return headers;
    }
}
exports.BasicAuthentication = BasicAuthentication;
BasicAuthentication.AUTH_HEADER_NAME = 'authorization';
