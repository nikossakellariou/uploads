"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.BasicAuthRoutes = void 0;
const config_schema_1 = require("@kbn/config-schema");
const common_1 = require("../../../../common");
const tenant_resolver_1 = require("../../../multitenancy/tenant_resolver");
class BasicAuthRoutes {
    constructor(router, config, sessionStorageFactory, securityClient, coreSetup) {
        this.router = router;
        this.config = config;
        this.sessionStorageFactory = sessionStorageFactory;
        this.securityClient = securityClient;
        this.coreSetup = coreSetup;
    }
    setupRoutes() {
        // bootstrap an empty page so that browser app can render the login page
        // using client side routing.
        this.coreSetup.http.resources.register({
            path: common_1.LOGIN_PAGE_URI,
            validate: false,
            options: {
                authRequired: false,
            },
        }, async (context, request, response) => {
            this.sessionStorageFactory.asScoped(request).clear();
            return response.renderAnonymousCoreApp();
        });
        // login using username and password
        this.router.post({
            path: common_1.API_AUTH_LOGIN,
            validate: {
                body: config_schema_1.schema.object({
                    username: config_schema_1.schema.string(),
                    password: config_schema_1.schema.string(),
                }),
            },
            options: {
                authRequired: false,
            },
        }, async (context, request, response) => {
            const forbiddenUsernames = this.config.auth.forbidden_usernames;
            if (forbiddenUsernames.indexOf(request.body.username) > -1) {
                context.security_plugin.logger.error(`Denied login for forbidden username ${request.body.username}`);
                return response.badRequest({
                    // Cannot login using forbidden user name.
                    body: 'Invalid username or password',
                });
            }
            let user;
            try {
                user = await this.securityClient.authenticate(request, {
                    username: request.body.username,
                    password: request.body.password,
                });
            }
            catch (error) {
                context.security_plugin.logger.error(`Failed authentication: ${error}`);
                return response.unauthorized({
                    headers: {
                        'www-authenticate': error.message,
                    },
                });
            }
            this.sessionStorageFactory.asScoped(request).clear();
            const encodedCredentials = Buffer.from(`${request.body.username}:${request.body.password}`).toString('base64');
            const sessionStorage = {
                username: user.username,
                credentials: {
                    authHeaderValue: `Basic ${encodedCredentials}`,
                },
                authType: 'basicauth',
                isAnonymousAuth: false,
                expiryTime: Date.now() + this.config.cookie.ttl,
            };
            if (this.config.multitenancy?.enabled) {
                const selectTenant = tenant_resolver_1.resolveTenant(request, user.username, user.tenants, this.config, sessionStorage);
                sessionStorage.tenant = selectTenant;
            }
            this.sessionStorageFactory.asScoped(request).set(sessionStorage);
            return response.ok({
                body: {
                    username: user.username,
                    tenants: user.tenants,
                    roles: user.roles,
                    backendroles: user.backendRoles,
                    selectedTenants: this.config.multitenancy?.enabled ? sessionStorage.tenant : undefined,
                },
            });
        });
        // logout
        this.router.post({
            path: common_1.API_AUTH_LOGOUT,
            validate: false,
            options: {
                authRequired: false,
            },
        }, async (context, request, response) => {
            this.sessionStorageFactory.asScoped(request).clear();
            return response.ok({
                body: {},
            });
        });
        // anonymous auth
        this.router.get({
            path: `/auth/anonymous`,
            validate: false,
            options: {
                authRequired: false,
            },
        }, async (context, request, response) => {
            if (this.config.auth.anonymous_auth_enabled) {
                let user;
                try {
                    user = await this.securityClient.authenticateWithHeaders(request, {});
                }
                catch (error) {
                    context.security_plugin.logger.error(`Failed authentication: ${error}`);
                    return response.unauthorized({
                        headers: {
                            'www-authenticate': error.message,
                        },
                    });
                }
                this.sessionStorageFactory.asScoped(request).clear();
                const sessionStorage = {
                    username: user.username,
                    authType: 'basicauth',
                    isAnonymousAuth: true,
                    expiryTime: Date.now() + this.config.cookie.ttl,
                };
                if (this.config.multitenancy?.enabled) {
                    const selectTenant = tenant_resolver_1.resolveTenant(request, user.username, user.tenants, this.config, sessionStorage);
                    sessionStorage.tenant = selectTenant;
                }
                this.sessionStorageFactory.asScoped(request).set(sessionStorage);
                return response.ok({
                    body: {
                        username: user.username,
                        tenants: user.tenants,
                        roles: user.roles,
                        backendroles: user.backendRoles,
                        selectedTenants: this.config.multitenancy?.enabled
                            ? sessionStorage.tenant
                            : undefined,
                    },
                });
            }
            else {
                return response.badRequest({
                    body: 'Anonymous auth is disabled.',
                });
            }
        });
    }
}
exports.BasicAuthRoutes = BasicAuthRoutes;
