"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.callTokenEndpoint = exports.getBaseRedirectUrl = exports.parseTokenResponse = void 0;
const tslib_1 = require("tslib");
const wreck_1 = tslib_1.__importDefault(require("@hapi/wreck"));
const querystring_1 = require("querystring");
function parseTokenResponse(payload) {
    const payloadString = payload.toString();
    if (payloadString.trim()[0] === '{') {
        try {
            return JSON.parse(payloadString);
        }
        catch (error) {
            throw Error(`Invalid JSON payload: ${error}`);
        }
    }
    return querystring_1.parse(payloadString);
}
exports.parseTokenResponse = parseTokenResponse;
function getBaseRedirectUrl(config, core) {
    if (config.openid?.base_redirect_url) {
        const baseRedirectUrl = config.openid.base_redirect_url;
        return baseRedirectUrl.endsWith('/') ? baseRedirectUrl.slice(0, -1) : baseRedirectUrl;
    }
    const host = core.http.getServerInfo().hostname;
    const port = core.http.getServerInfo().port;
    const protocol = core.http.getServerInfo().protocol;
    if (core.http.basePath.serverBasePath) {
        return `${protocol}://${host}:${port}${core.http.basePath.serverBasePath}`;
    }
    return `${protocol}://${host}:${port}`;
}
exports.getBaseRedirectUrl = getBaseRedirectUrl;
async function callTokenEndpoint(tokenEndpoint, query) {
    const tokenResponse = await wreck_1.default.post(tokenEndpoint, {
        payload: querystring_1.stringify(query),
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    });
    if (!tokenResponse.res?.statusCode ||
        tokenResponse.res.statusCode < 200 ||
        tokenResponse.res.statusCode > 299) {
        throw new Error(`Failed calling token endpoint: ${tokenResponse.res.statusCode} ${tokenResponse.res.statusMessage}`);
    }
    const tokenPayload = parseTokenResponse(tokenResponse.payload);
    return {
        idToken: tokenPayload.id_token,
        accessToken: tokenPayload.access_token,
        refreshToken: tokenPayload.refresh_token,
        expiresIn: tokenPayload.expires_in,
    };
}
exports.callTokenEndpoint = callTokenEndpoint;
