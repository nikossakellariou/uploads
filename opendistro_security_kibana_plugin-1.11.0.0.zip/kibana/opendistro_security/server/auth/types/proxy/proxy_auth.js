"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProxyAuthentication = void 0;
const lodash_1 = require("lodash");
const routes_1 = require("./routes");
const authentication_type_1 = require("../authentication_type");
const tenant_resolver_1 = require("../../../multitenancy/tenant_resolver");
class ProxyAuthentication extends authentication_type_1.AuthenticationType {
    constructor(config, sessionStorageFactory, router, esClient, coreSetup, logger) {
        super(config, sessionStorageFactory, router, esClient, coreSetup, logger);
        this.type = 'proxy';
        this.authType = 'proxycache';
        this.userHeaderName = this.config.proxycache?.user_header?.toLowerCase() || '';
        this.roleHeaderName = this.config.proxycache?.roles_header?.toLowerCase() || '';
        this.setupRoutes();
    }
    setupRoutes() {
        const routes = new routes_1.ProxyAuthRoutes(this.router, this.config, this.sessionStorageFactory, this.securityClient, this.coreSetup);
        routes.setupRoutes();
    }
    requestIncludesAuthInfo(request) {
        return request.headers[ProxyAuthentication.XFF] && request.headers[this.userHeaderName]
            ? true
            : false;
    }
    getAdditionalAuthHeader(request) {
        const authHeaders = {};
        const customProxyHeader = this.config.proxycache?.proxy_header;
        if (customProxyHeader &&
            !request.headers[customProxyHeader] &&
            this.config.proxycache?.proxy_header_ip) {
            // TODO: check how to get remoteIp from KibanaRequest and add remoteIp to this header
            authHeaders[customProxyHeader] = this.config.proxycache.proxy_header_ip;
        }
        return authHeaders;
    }
    async getCookie(request, authInfo) {
        const cookie = {
            username: authInfo.username,
            credentials: {},
            authType: this.authType,
            isAnonymousAuth: false,
            expiryTime: Date.now() + this.config.cookie.ttl,
        };
        if (this.userHeaderName && request.headers[this.userHeaderName]) {
            cookie.credentials[this.userHeaderName] = request.headers[this.userHeaderName];
        }
        if (this.roleHeaderName && request.headers[this.roleHeaderName]) {
            cookie.credentials[this.roleHeaderName] = request.headers[this.roleHeaderName];
        }
        if (request.headers[ProxyAuthentication.XFF]) {
            cookie.credentials[ProxyAuthentication.XFF] = request.headers[ProxyAuthentication.XFF];
        }
        if (request.headers.authorization) {
            cookie.credentials.authorization = request.headers.authorization;
        }
        // set tenant from cookie if exist
        const browserCookie = await this.sessionStorageFactory.asScoped(request).get();
        if (browserCookie && tenant_resolver_1.isValidTenant(browserCookie.tenant)) {
            cookie.tenant = browserCookie.tenant;
        }
        return cookie;
    }
    async isValidCookie(cookie) {
        return (cookie.authType === this.type &&
            cookie.username &&
            cookie.expiryTime &&
            cookie.credentials[this.userHeaderName]);
    }
    handleUnauthedRequest(request, response, toolkit) {
        const loginEndpoint = this.config.proxycache?.login_endpoint;
        if (loginEndpoint) {
            return toolkit.redirected({
                location: loginEndpoint,
            });
        }
        else {
            return toolkit.notHandled(); // TODO: redirect to error page?
        }
    }
    buildAuthHeaderFromCookie(cookie) {
        const authHeaders = {};
        if (lodash_1.get(cookie.credentials, this.userHeaderName)) {
            authHeaders[this.userHeaderName] = cookie.credentials[this.userHeaderName];
            if (lodash_1.get(cookie.credentials, this.roleHeaderName)) {
                authHeaders[this.roleHeaderName] = cookie.credentials[this.roleHeaderName];
            }
            if (lodash_1.get(cookie.credentials, ProxyAuthentication.XFF)) {
                authHeaders[ProxyAuthentication.XFF] = cookie.credentials[ProxyAuthentication.XFF];
            }
            return authHeaders;
        }
        else if (lodash_1.get(cookie.credentials, 'authorization')) {
            authHeaders.authorization = lodash_1.get(cookie.credentials, 'authorization');
            return authHeaders;
        }
    }
}
exports.ProxyAuthentication = ProxyAuthentication;
ProxyAuthentication.XFF = 'x-forwarded-for';
