"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProxyAuthRoutes = void 0;
const config_schema_1 = require("@kbn/config-schema");
class ProxyAuthRoutes {
    constructor(router, config, sessionStorageFactory, securityClient, coreSetup) {
        this.router = router;
        this.config = config;
        this.sessionStorageFactory = sessionStorageFactory;
        this.securityClient = securityClient;
        this.coreSetup = coreSetup;
    }
    setupRoutes() {
        this.router.get({
            path: `/auth/proxy/login`,
            validate: {
                query: config_schema_1.schema.object({
                    nextUrl: config_schema_1.schema.maybe(config_schema_1.schema.string()),
                }),
            },
            options: {
                // TODO: set to false?
                authRequired: 'optional',
            },
        }, async (context, request, response) => {
            if (request.auth.isAuthenticated) {
                const nextUrl = request.query.nextUrl || `${this.coreSetup.http.basePath.serverBasePath}/app/kibana`;
                response.redirected({
                    headers: {
                        location: nextUrl,
                    },
                });
            }
            const loginEndpoint = this.config.proxycache?.login_endpoint;
            if (loginEndpoint) {
                return response.redirected({
                    headers: {
                        location: loginEndpoint,
                    },
                });
            }
            else {
                return response.badRequest();
            }
        });
        this.router.post({
            path: `/auth/proxy/logout`,
            validate: false,
        }, async (context, request, response) => {
            this.sessionStorageFactory.asScoped(request).clear();
            return response.ok();
        });
    }
}
exports.ProxyAuthRoutes = ProxyAuthRoutes;
