"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAuthenticationHandler = void 0;
const common_1 = require("../../common");
const types_1 = require("./types");
function createAuthentication(ctor, config, sessionStorageFactory, router, esClient, coreSetup, logger) {
    return new ctor(config, sessionStorageFactory, router, esClient, coreSetup, logger);
}
function getAuthenticationHandler(authType, router, config, core, esClient, securitySessionStorageFactory, logger) {
    let authHandlerType;
    switch (authType) {
        case '':
        case 'basicauth':
            authHandlerType = types_1.BasicAuthentication;
            break;
        case common_1.AuthType.JWT:
            authHandlerType = types_1.JwtAuthentication;
            break;
        case common_1.AuthType.OPEN_ID:
            authHandlerType = types_1.OpenIdAuthentication;
            break;
        case common_1.AuthType.SAML:
            authHandlerType = types_1.SamlAuthentication;
            break;
        case common_1.AuthType.PROXY:
            authHandlerType = types_1.ProxyAuthentication;
            break;
        default:
            throw new Error(`Unsupported authentication type: ${authType}`);
    }
    const auth = createAuthentication(authHandlerType, config, securitySessionStorageFactory, router, esClient, core, logger);
    return auth;
}
exports.getAuthenticationHandler = getAuthenticationHandler;
