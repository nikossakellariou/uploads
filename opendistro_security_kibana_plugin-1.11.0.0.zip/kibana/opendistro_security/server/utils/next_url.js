"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.composeNextUrlQeuryParam = void 0;
const lodash_1 = require("lodash");
const url_1 = require("url");
const querystring_1 = require("querystring");
function composeNextUrlQeuryParam(request, basePath) {
    const url = lodash_1.cloneDeep(request.url);
    url.pathname = `${basePath}${url.pathname}`;
    const nextUrl = url_1.format(url);
    return querystring_1.stringify({ nextUrl });
}
exports.composeNextUrlQeuryParam = composeNextUrlQeuryParam;
