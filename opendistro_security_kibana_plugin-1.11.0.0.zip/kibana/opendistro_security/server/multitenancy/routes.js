"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.setupMultitenantRoutes = void 0;
const config_schema_1 = require("@kbn/config-schema");
const html_entities_1 = require("html-entities");
function setupMultitenantRoutes(router, sessionStroageFactory, securityClient) {
    const PREFIX = '/api/v1';
    const entities = new html_entities_1.AllHtmlEntities();
    /**
     * Updates selected tenant.
     */
    router.post({
        path: `${PREFIX}/multitenancy/tenant`,
        validate: {
            body: config_schema_1.schema.object({
                username: config_schema_1.schema.string(),
                tenant: config_schema_1.schema.string(),
            }),
        },
    }, async (context, request, response) => {
        const tenant = request.body.tenant;
        const cookie = await sessionStroageFactory
            .asScoped(request)
            .get();
        if (!cookie) {
            return response.badRequest({
                body: 'Invalid cookie',
            });
        }
        cookie.tenant = tenant;
        sessionStroageFactory.asScoped(request).set(cookie);
        return response.ok({
            body: entities.encode(tenant),
        });
    });
    /**
     * Gets current selected tenant from session.
     */
    router.get({
        path: `${PREFIX}/multitenancy/tenant`,
        validate: false,
    }, async (context, request, response) => {
        const cookie = await sessionStroageFactory.asScoped(request).get();
        if (!cookie) {
            return response.badRequest({
                body: 'Invalid cookie.',
            });
        }
        return response.ok({
            body: entities.encode(cookie.tenant),
        });
    });
    /**
     * Gets multitenant info of current user.
     *
     * Sample response of this API:
     * {
     *   "user_name": "admin",
     *   "not_fail_on_forbidden_enabled": false,
     *   "kibana_mt_enabled": true,
     *   "kibana_index": ".kibana",
     *   "kibana_server_user": "kibanaserver"
     * }
     */
    router.get({
        path: `${PREFIX}/multitenancy/info`,
        validate: false,
    }, async (context, request, response) => {
        try {
            const esResponse = await securityClient.getMultitenancyInfo(request);
            return response.ok({
                body: esResponse,
                headers: {
                    'content-type': 'application/json',
                },
            });
        }
        catch (error) {
            return response.internalError({
                body: error.message,
            });
        }
    });
    router.post({
        // FIXME: Seems this is not being used, confirm and delete if not used anymore
        path: `${PREFIX}/multitenancy/migrate/{tenantindex}`,
        validate: {
            params: config_schema_1.schema.object({
                tenantindex: config_schema_1.schema.string(),
            }),
            query: config_schema_1.schema.object({
                force: config_schema_1.schema.literal('true'),
            }),
        },
    }, async (context, request, response) => {
        return response.ok(); // TODO: implement tenant index migration logic
    });
}
exports.setupMultitenantRoutes = setupMultitenantRoutes;
