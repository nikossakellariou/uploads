"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.OpendistroSecurityPlugin = void 0;
const tslib_1 = require("tslib");
const operators_1 = require("rxjs/operators");
const routes_1 = require("./routes");
const opendistro_security_configuration_plugin_1 = tslib_1.__importDefault(require("./backend/opendistro_security_configuration_plugin"));
const opendistro_security_plugin_1 = tslib_1.__importDefault(require("./backend/opendistro_security_plugin"));
const security_cookie_1 = require("./session/security_cookie");
const opendistro_security_client_1 = require("./backend/opendistro_security_client");
const tenant_index_1 = require("./multitenancy/tenant_index");
const auth_handler_factory_1 = require("./auth/auth_handler_factory");
const routes_2 = require("./multitenancy/routes");
const auth_type_routes_1 = require("./routes/auth_type_routes");
class OpendistroSecurityPlugin {
    constructor(initializerContext) {
        this.initializerContext = initializerContext;
        this.logger = initializerContext.logger.get();
    }
    async setup(core) {
        this.logger.debug('opendistro_security: Setup');
        const config$ = this.initializerContext.config.create();
        const config = await config$.pipe(operators_1.first()).toPromise();
        const router = core.http.createRouter();
        const esClient = core.elasticsearch.legacy.createClient('opendistro_security', {
            plugins: [opendistro_security_configuration_plugin_1.default, opendistro_security_plugin_1.default],
        });
        this.securityClient = new opendistro_security_client_1.SecurityClient(esClient);
        const securitySessionStorageFactory = await core.http.createCookieSessionStorageFactory(security_cookie_1.getSecurityCookieOptions(config));
        // put logger into route handler context, so that we don't need to pass througth parameters
        core.http.registerRouteHandlerContext('security_plugin', (context, request) => {
            return {
                logger: this.logger,
                esClient,
            };
        });
        // setup auth
        const auth = auth_handler_factory_1.getAuthenticationHandler(config.auth.type, router, config, core, esClient, securitySessionStorageFactory, this.logger);
        core.http.registerAuth(auth.authHandler);
        // Register server side APIs
        routes_1.defineRoutes(router);
        auth_type_routes_1.defineAuthTypeRoutes(router, config);
        // set up multi-tenent routes
        if (config.multitenancy?.enabled) {
            routes_2.setupMultitenantRoutes(router, securitySessionStorageFactory, this.securityClient);
        }
        return {
            config$,
            securityConfigClient: esClient,
        };
    }
    // TODO: add more logs
    async start(core) {
        this.logger.debug('opendistro_security: Started');
        const config$ = this.initializerContext.config.create();
        const config = await config$.pipe(operators_1.first()).toPromise();
        if (config.multitenancy?.enabled) {
            const globalConfig$ = this.initializerContext.config.legacy
                .globalConfig$;
            const globalConfig = await globalConfig$.pipe(operators_1.first()).toPromise();
            const kibanaIndex = globalConfig.kibana.index;
            const typeRegistry = core.savedObjects.getTypeRegistry();
            const esClient = core.elasticsearch.legacy.client;
            tenant_index_1.setupIndexTemplate(esClient, kibanaIndex, typeRegistry, this.logger);
            const serializer = core.savedObjects.createSerializer();
            const kibanaVersion = this.initializerContext.env.packageInfo.version;
            tenant_index_1.migrateTenantIndices(kibanaVersion, esClient, this.securityClient, typeRegistry, serializer, this.logger);
        }
        return {
            es: core.elasticsearch.legacy,
        };
    }
    stop() { }
}
exports.OpendistroSecurityPlugin = OpendistroSecurityPlugin;
