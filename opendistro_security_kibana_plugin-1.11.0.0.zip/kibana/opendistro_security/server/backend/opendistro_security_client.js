"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SecurityClient = void 0;
class SecurityClient {
    constructor(esClient) {
        this.esClient = esClient;
    }
    async authenticate(request, credentials) {
        const authHeader = Buffer.from(`${credentials.username}:${credentials.password}`).toString('base64');
        try {
            const esResponse = await this.esClient
                .asScoped(request)
                .callAsCurrentUser('opendistro_security.authinfo', {
                headers: {
                    authorization: `Basic ${authHeader}`,
                },
            });
            return {
                username: credentials.username,
                roles: esResponse.roles,
                backendRoles: esResponse.backend_roles,
                tenants: esResponse.tenants,
                selectedTenant: esResponse.user_requested_tenant,
                credentials,
                proxyCredentials: credentials,
            };
        }
        catch (error) {
            throw new Error(error.message);
        }
    }
    async authenticateWithHeader(request, headerName, headerValue, whitelistedHeadersAndValues = {}, additionalAuthHeaders = {}) {
        try {
            const credentials = {
                headerName,
                headerValue,
            };
            const headers = {};
            if (headerValue) {
                headers[headerName] = headerValue;
            }
            // cannot get config elasticsearch.requestHeadersWhitelist from kibana.yml file in new platfrom
            // meanwhile, do we really need to save all headers in cookie?
            const esResponse = await this.esClient
                .asScoped(request)
                .callAsCurrentUser('opendistro_security.authinfo', {
                headers,
            });
            return {
                username: esResponse.user_name,
                roles: esResponse.roles,
                backendRoles: esResponse.backend_roles,
                tenants: esResponse.teanats,
                selectedTenant: esResponse.user_requested_tenant,
                credentials,
            };
        }
        catch (error) {
            throw new Error(error.message);
        }
    }
    async authenticateWithHeaders(request, additionalAuthHeaders = {}) {
        try {
            const esResponse = await this.esClient
                .asScoped(request)
                .callAsCurrentUser('opendistro_security.authinfo', {
                headers: additionalAuthHeaders,
            });
            return {
                username: esResponse.user_name,
                roles: esResponse.roles,
                backendRoles: esResponse.backend_roles,
                tenants: esResponse.tenants,
                selectedTenant: esResponse.user_requested_tenant,
            };
        }
        catch (error) {
            throw new Error(error.message);
        }
    }
    async authinfo(request, headers = {}) {
        try {
            return await this.esClient
                .asScoped(request)
                .callAsCurrentUser('opendistro_security.authinfo', {
                headers,
            });
        }
        catch (error) {
            throw new Error(error.message);
        }
    }
    // Multi-tenancy APIs
    async getMultitenancyInfo(request) {
        try {
            return await this.esClient
                .asScoped(request)
                .callAsCurrentUser('opendistro_security.multitenancyinfo');
        }
        catch (error) {
            throw new Error(error.message);
        }
    }
    async getTenantInfoWithInternalUser() {
        try {
            return this.esClient.callAsInternalUser('opendistro_security.tenantinfo');
        }
        catch (error) {
            throw new Error(error.message);
        }
    }
    async getTenantInfo(request) {
        try {
            return await this.esClient
                .asScoped(request)
                .callAsCurrentUser('opendistro_security.tenantinfo');
        }
        catch (error) {
            throw new Error(error.message);
        }
    }
    async getSamlHeader(request) {
        try {
            // response is expected to be an error
            await this.esClient.asScoped(request).callAsCurrentUser('opendistro_security.authinfo');
        }
        catch (error) {
            // the error looks like
            // wwwAuthenticateDirective:
            //   '
            //     X-Security-IdP realm="Open Distro Security"
            //     location="https://<your-auth-domain.com>/api/saml2/v1/sso?SAMLRequest=<some-encoded-string>"
            //     requestId="<request_id>"
            //   '
            if (!error.wwwAuthenticateDirective) {
                throw error;
            }
            try {
                const locationRegExp = /location="(.*?)"/;
                const requestIdRegExp = /requestId="(.*?)"/;
                const locationExecArray = locationRegExp.exec(error.wwwAuthenticateDirective);
                const requestExecArray = requestIdRegExp.exec(error.wwwAuthenticateDirective);
                if (locationExecArray && requestExecArray) {
                    return {
                        location: locationExecArray[1],
                        requestId: requestExecArray[1],
                    };
                }
                throw Error('failed parsing SAML config');
            }
            catch (parsingError) {
                console.log(parsingError);
                throw new Error(parsingError);
            }
        }
        throw new Error(`Invalid SAML configuration.`);
    }
    async authToken(requestId, samlResponse, acsEndpoint = undefined) {
        const body = {
            RequestId: requestId,
            SAMLResponse: samlResponse,
            acsEndpoint,
        };
        try {
            return await this.esClient.asScoped().callAsCurrentUser('opendistro_security.authtoken', {
                body,
            });
        }
        catch (error) {
            console.log(error);
            throw new Error('failed to get token');
        }
    }
}
exports.SecurityClient = SecurityClient;
