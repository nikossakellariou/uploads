"use strict";
/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.plugin = exports.config = exports.configSchema = void 0;
const config_schema_1 = require("@kbn/config-schema");
const plugin_1 = require("./plugin");
exports.configSchema = config_schema_1.schema.object({
    enabled: config_schema_1.schema.boolean({ defaultValue: true }),
    allow_client_certificates: config_schema_1.schema.boolean({ defaultValue: false }),
    readonly_mode: config_schema_1.schema.object({
        roles: config_schema_1.schema.arrayOf(config_schema_1.schema.string(), { defaultValue: [] }),
    }),
    clusterPermissions: config_schema_1.schema.object({
        include: config_schema_1.schema.arrayOf(config_schema_1.schema.string(), { defaultValue: [] }),
    }),
    indexPermissions: config_schema_1.schema.object({
        include: config_schema_1.schema.arrayOf(config_schema_1.schema.string(), { defaultValue: [] }),
    }),
    disabledTransportCategories: config_schema_1.schema.object({
        exclude: config_schema_1.schema.arrayOf(config_schema_1.schema.string(), { defaultValue: [] }),
    }),
    disabledRestCategories: config_schema_1.schema.object({
        exclude: config_schema_1.schema.arrayOf(config_schema_1.schema.string(), { defaultValue: [] }),
    }),
    cookie: config_schema_1.schema.object({
        secure: config_schema_1.schema.boolean({ defaultValue: false }),
        name: config_schema_1.schema.string({ defaultValue: 'security_authentication' }),
        password: config_schema_1.schema.string({ defaultValue: 'security_cookie_default_password', minLength: 32 }),
        ttl: config_schema_1.schema.number({ defaultValue: 60 * 60 * 1000 }),
        domain: config_schema_1.schema.nullable(config_schema_1.schema.string()),
        isSameSite: config_schema_1.schema.oneOf([
            config_schema_1.schema.string({
                validate(value) {
                    if (value === 'Strict' || value === 'Lax') {
                        return `Allowed values of 'isSameSite' are ['Strict, 'Lax', true, false]`;
                    }
                },
            }),
            config_schema_1.schema.boolean(),
        ], { defaultValue: true }),
    }),
    session: config_schema_1.schema.object({
        ttl: config_schema_1.schema.number({ defaultValue: 60 * 60 * 1000 }),
        keepalive: config_schema_1.schema.boolean({ defaultValue: true }),
    }),
    auth: config_schema_1.schema.object({
        type: config_schema_1.schema.string({
            defaultValue: '',
            validate(value) {
                if (!['', 'basicauth', 'jwt', 'openid', 'saml', 'proxy', 'kerberos', 'proxycache'].includes(value)) {
                    return `allowed auth.type are ['', 'basicauth', 'jwt', 'openid', 'saml', 'proxy', 'kerberos', 'proxycache']`;
                }
            },
        }),
        anonymous_auth_enabled: config_schema_1.schema.boolean({ defaultValue: false }),
        unauthenticated_routes: config_schema_1.schema.arrayOf(config_schema_1.schema.string(), { defaultValue: ['/api/status'] }),
        forbidden_usernames: config_schema_1.schema.arrayOf(config_schema_1.schema.string(), { defaultValue: [] }),
        logout_url: config_schema_1.schema.string({ defaultValue: '' }),
    }),
    basicauth: config_schema_1.schema.object({
        enabled: config_schema_1.schema.boolean({ defaultValue: true }),
        unauthenticated_routes: config_schema_1.schema.arrayOf(config_schema_1.schema.string(), { defaultValue: ['/api/status'] }),
        forbidden_usernames: config_schema_1.schema.arrayOf(config_schema_1.schema.string(), { defaultValue: [] }),
        header_trumps_session: config_schema_1.schema.boolean({ defaultValue: false }),
        alternative_login: config_schema_1.schema.object({
            headers: config_schema_1.schema.arrayOf(config_schema_1.schema.string(), { defaultValue: [] }),
            show_for_parameter: config_schema_1.schema.string({ defaultValue: '' }),
            valid_redirects: config_schema_1.schema.arrayOf(config_schema_1.schema.string(), { defaultValue: [] }),
            button_text: config_schema_1.schema.string({ defaultValue: 'Login with provider' }),
            buttonstyle: config_schema_1.schema.string({ defaultValue: '' }),
        }),
        loadbalancer_url: config_schema_1.schema.maybe(config_schema_1.schema.string()),
        login: config_schema_1.schema.object({
            title: config_schema_1.schema.string({ defaultValue: 'Please login to Kibana' }),
            subtitle: config_schema_1.schema.string({
                defaultValue: 'If you have forgotten your username or password, please ask your system administrator',
            }),
            showbrandimage: config_schema_1.schema.boolean({ defaultValue: true }),
            brandimage: config_schema_1.schema.string({ defaultValue: '' }),
            buttonstyle: config_schema_1.schema.string({ defaultValue: '' }),
        }),
    }),
    multitenancy: config_schema_1.schema.object({
        enabled: config_schema_1.schema.boolean({ defaultValue: false }),
        show_roles: config_schema_1.schema.boolean({ defaultValue: false }),
        enable_filter: config_schema_1.schema.boolean({ defaultValue: false }),
        debug: config_schema_1.schema.boolean({ defaultValue: false }),
        tenants: config_schema_1.schema.object({
            enable_private: config_schema_1.schema.boolean({ defaultValue: true }),
            enable_global: config_schema_1.schema.boolean({ defaultValue: true }),
            preferred: config_schema_1.schema.arrayOf(config_schema_1.schema.string(), { defaultValue: [] }),
        }),
    }),
    configuration: config_schema_1.schema.object({
        enabled: config_schema_1.schema.boolean({ defaultValue: true }),
    }),
    accountinfo: config_schema_1.schema.object({
        enabled: config_schema_1.schema.boolean({ defaultValue: false }),
    }),
    openid: config_schema_1.schema.maybe(config_schema_1.schema.object({
        connect_url: config_schema_1.schema.maybe(config_schema_1.schema.string()),
        header: config_schema_1.schema.string({ defaultValue: 'Authorization' }),
        // TODO: test if siblingRef() works here
        // client_id is required when auth.type is openid
        client_id: config_schema_1.schema.conditional(config_schema_1.schema.siblingRef('auth.type'), 'openid', config_schema_1.schema.string(), config_schema_1.schema.maybe(config_schema_1.schema.string())),
        client_secret: config_schema_1.schema.string({ defaultValue: '' }),
        scope: config_schema_1.schema.string({ defaultValue: 'openid profile email address phone' }),
        base_redirect_url: config_schema_1.schema.string({ defaultValue: '' }),
        logout_url: config_schema_1.schema.string({ defaultValue: '' }),
        root_ca: config_schema_1.schema.string({ defaultValue: '' }),
        verify_hostnames: config_schema_1.schema.boolean({ defaultValue: true }),
    })),
    proxycache: config_schema_1.schema.maybe(config_schema_1.schema.object({
        // when auth.type is proxycache, user_header, roles_header and proxy_header_ip are required
        user_header: config_schema_1.schema.conditional(config_schema_1.schema.siblingRef('auth.type'), 'proxycache', config_schema_1.schema.string(), config_schema_1.schema.maybe(config_schema_1.schema.string())),
        roles_header: config_schema_1.schema.conditional(config_schema_1.schema.siblingRef('auth.type'), 'proxycache', config_schema_1.schema.string(), config_schema_1.schema.maybe(config_schema_1.schema.string())),
        proxy_header: config_schema_1.schema.maybe(config_schema_1.schema.string({ defaultValue: 'x-forwarded-for' })),
        proxy_header_ip: config_schema_1.schema.conditional(config_schema_1.schema.siblingRef('auth.type'), 'proxycache', config_schema_1.schema.string(), config_schema_1.schema.maybe(config_schema_1.schema.string())),
        login_endpoint: config_schema_1.schema.maybe(config_schema_1.schema.string({ defaultValue: '' })),
    })),
    jwt: config_schema_1.schema.maybe(config_schema_1.schema.object({
        enabled: config_schema_1.schema.boolean({ defaultValue: false }),
        login_endpoint: config_schema_1.schema.maybe(config_schema_1.schema.string()),
        url_param: config_schema_1.schema.string({ defaultValue: 'authorization' }),
        header: config_schema_1.schema.string({ defaultValue: 'Authorization' }),
    })),
    ui: config_schema_1.schema.object({
        basicauth: config_schema_1.schema.object({
            // the login config here is the same as old config `opendistro_security.basicauth.login`
            // Since we are now rendering login page to browser app, so move these config to browser side.
            login: config_schema_1.schema.object({
                title: config_schema_1.schema.string({ defaultValue: 'Please login to Kibana' }),
                subtitle: config_schema_1.schema.string({
                    defaultValue: 'If you have forgotten your username or password, please ask your system administrator',
                }),
                showbrandimage: config_schema_1.schema.boolean({ defaultValue: true }),
                brandimage: config_schema_1.schema.string({ defaultValue: '' }),
                buttonstyle: config_schema_1.schema.string({ defaultValue: '' }),
            }),
        }),
    }),
});
exports.config = {
    exposeToBrowser: {
        enabled: true,
        auth: true,
        ui: true,
        multitenancy: true,
        readonly_mode: true,
        clusterPermissions: true,
        indexPermissions: true,
        disabledTransportCategories: true,
        disabledRestCategories: true,
    },
    schema: exports.configSchema,
    deprecations: ({ rename, unused }) => [
        rename('basicauth.login.title', 'ui.basicauth.login.title'),
        rename('basicauth.login.subtitle', 'ui.basicauth.login.subtitle'),
        rename('basicauth.login.showbrandimage', 'ui.basicauth.login.showbrandimage'),
        rename('basicauth.login.brandimage', 'ui.basicauth.login.brandimage'),
        rename('basicauth.login.buttonstyle', 'ui.basicauth.login.buttonstyle'),
    ],
};
//  This exports static code and TypeScript types,
//  as well as, Kibana Platform `plugin()` initializer.
function plugin(initializerContext) {
    return new plugin_1.OpendistroSecurityPlugin(initializerContext);
}
exports.plugin = plugin;
